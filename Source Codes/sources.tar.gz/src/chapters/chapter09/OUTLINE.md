# Chapter 9: Scaling to 30B+ Models

Working scaffold for the Ch 9 rewrite. The file `src/chapters/chapter09/index.tex` is
still the stale "Response Caching" placeholder from the pre-restructure outline (the
`\label{ch:scaling}` is already correct); this chapter is a full rewrite the way Ch 8 was.
Chapter 8 (`chapter08/index.tex`) is the model for density, structure, and voice.
Drafts in 200--500 word increments; same rules as Ch 7/Ch 8 (the
`book-style-sweep` skill, which is now the sole voice authority, and the memory entries).

**Status (2026-07, updated after the warm-cache drain):** Ch 9's backbone stays
engine/model-centric (VRAM budget + quantization + engine tuning), but the chapter now has a
**genuine control-plane spine**, not just a thin `--engine-args` vehicle. Two iplane PRs
landed on `ch9/` branches (see the `ch9-warm-cache-mountpoints-and-coldstart-sli` inbox
marker): warm-cache model mounts (#190) and a cold-start `storage_tier` SLI (#192). That
loosens the earlier "keep iplane thin by design" stance (memory
`project_engine_vs_controlplane_chapter_balance`), because a real control-plane feature now
exists rather than a forced demo. Split is roughly ~60% engine/model, ~40% control-plane.

### iplane surface state (honest, checked 2026-07)

- **Shipped:** `--engine-args ...` passes arbitrary flags straight through to the vLLM
  entrypoint (`internal/provisioners/runpod/deployer.go` appends `dep.GetEngineArgs()`), so
  `--engine-args --quantization`, `--gpu-memory-utilization`, `--max-model-len` all work as
  pass-through. The control plane owns placement, the engine owns tuning.
- **Shipped:** the VRAM-budget-driven placement surface from Ch 6 (`--class`, `--min-vram-gb`,
  `--sku`, `--gpu-count`) resolves "what card fits this model" against the provider SKU catalog.
- **Shipped (the new control-plane spine):** a warm model cache. `iplane model pin` pre-stages a
  model's weights onto a shared per-region volume (generic `volumecache.Store` behind the v0.1
  `ModelStore` seam, provider-agnostic, NO `CachedStore`/`RunPodVolumeStore` names), and a later
  `deploy` of that `(model, provider, region)` auto-resolves and mounts the volume, redirecting
  `HF_HOME` so the engine reads weights off it instead of re-downloading. The store only MOUNTS;
  populating is the explicit `pin` step, NOT a download-on-resolve. Mounts are provider-scoped
  (`{volume_id, host_path, mount_path, provider}`; a cross-provider mismatch is refused). Plus a
  cold-start `storage_tier` SLI (#192). See the correction marker + `docs/modelstore.md` (iplane).
- **Roadmap only (NOT shipped):** the dedicated `iplane deploy --quantization awq` convenience
  flag, AWQ/GPTQ image-catalog variants, and `--engine-config <yaml>` profiles. No `ch09-final`
  tag is cut yet, though the surface above would fill a real snapshot when it is.

**Consequence for drafting:** the VRAM/quantization/engine-tuning acts draft against
first-principles + web sources. The control-plane portion is now two acts (placement +
warm-cache mounts), the warm-cache act carrying the `storage_tier` SLI as its money panel. The
Capability Snapshot is close to draftable (warm-cache mounts + placement + `--engine-args` +
the SLI); keep it a light stub until a `ch09-final` tag + `capabilities.yaml` entry exist
(drafted ahead with `date: TBD` per `book/CLAUDE.md`).

## Chapter arc (from `master_outline.md` Ch 9 row)

> VRAM budgets in practice, INT4/INT8 quantization in production (callback to Ch 4), engine
> tuning (`gpu_memory_utilization`, `max-model-len`, etc.), and the threshold where one GPU
> stops being enough. Sharding the model across multiple GPUs is Ch 10's lead; Ch 9 closes at
> the single-GPU ceiling that motivates it.

Model size: 8B (Ch 7/8) -> 30B+ (this chapter). Hardware: single professional GPU.

### Boundary with Ch 8 and Ch 10 (keep the seams honest)

- **Ch 8 closed** treating every engine as one opaque KV domain --- one endpoint, one cache,
  the router's unit of selection --- and deferred two things here: "how much cache a 30B model
  leaves for prefixes once its weights and activations are accounted for is Chapter 9"
  (`\S\ref{subsec:ch8-defers}`), and "one engine's cache spread across several GPUs is
  Chapter 10."
- **Ch 9 owns** the KV memory budget at model scale + quantization. It stays inside one GPU:
  one card, one engine, one KV domain.
- **Ch 10 opens** the multi-GPU KV domain (tensor parallelism, pipeline parallelism, NVLink).
  Ch 9's single-GPU ceiling is exactly the force that motivates it.

## Target shape

~20 pages at Ch 7/Ch 8 density: ~7k words, ~6 TikZ/pgfplots diagrams, real
`nvidia-smi` / vLLM startup-log transcripts, a Problems section, and a Capability Snapshot
(stub for now). The VRAM math is the backbone --- concrete and checkable with real model
dims, real card capacities, real bytes-per-param per quant level --- the Ch 9 equivalent of
Ch 8's support-chat token-growth worked example. Synthetic pgfplots panels stand in for
paid-GPU VRAM/throughput figures, captioned illustrative.

## Section plan

### Act 1 --- Where We Left Off / the model got bigger (~10%)

Ch 8 kept the model at 8B and made routing across engines cache-aware. It closed on a
boundary: how much cache a 30B model leaves for prefixes is this chapter's question. Ch 8's
router picked an engine, not a GPU, and never looked inside one. Ch 9 looks inside one, at a
single GPU's VRAM, and asks the question that comes before routing can even start --- does the
model fit, and what is left over for the cache the last chapter spent its whole length trying
to keep warm. The unit of concern drops from the fleet to one card.

The jump from 8B to 30B+ is not linear in cost. At FP16 an 8B model's weights are ~16 GB and
sit on a single 24 GB card with room to spare. A 32B model's weights are ~64 GB at FP16 and do
not fit on any single consumer card, or even an 80 GB datacenter card once the KV cache and
activations are counted. Something has to give, and the two levers are quantization (shrink the
weights) and the KV budget (decide how much context the leftover memory buys). That is the
chapter.

### Act 2 --- The VRAM budget (the backbone, ~30%, engine/model first-principles)

The four components every deployment pays for (per the `book-style-sweep` skill, "Numerical consistency"):

1. **Weights** = `parameters * bytes_per_param`. `bytes_per_param` is set by quantization
   (FP16 = 2, FP8/INT8 = 1, INT4 = 0.5 nominal, ~0.55--0.65 effective with scales/zeros).
   This is the term quantization moves and it dominates at model scale.
2. **KV cache** = `2 * layers * num_kv_heads * head_dim * context * bytes * batch`
   (the 2 is K and V). GQA (num_kv_heads << num_heads) is what keeps this tractable at 30B+.
   This is the term `max-model-len` and batch size move.
3. **Activations** --- ~1--4 GB for 7B--70B, scales with context/model-dim/layers. Must be
   contiguous (cuBLAS GEMM), unlike the paged KV cache.
4. **Overhead** --- ~15% multiplier for CUDA pools, engine overhead, fragmentation.

Worked example (the Ch 9 equivalent of Ch 8's token-growth example): take one anchor 32B
model with real dims (layers, hidden, heads, kv-heads, head_dim from its HF card). Compute
weights at FP16 vs INT4, the KV bytes-per-token, the KV GB at 8k and 32k context, activations,
overhead. Answer "does this fit on 24 GB / 32 GB / 48 GB / 80 GB?" at each quant level. Show
the subtotal before overhead. Use `\pgfmathsetmacro` for every input so the numbers stay in
sync (divide-before-multiply to dodge pgfmath overflow).

Diagrams: (1) stacked-bar VRAM budget, weights/KV/activations/overhead, FP16 vs INT4 side by
side, showing quantization shrinks the weights block and frees KV headroom; (2) "does it fit"
--- the 32B weight block against 24/32/48/80 GB card capacity lines at each quant level.

### Act 3 --- Quantization in production (~15%, Ch 4 callback, tighten in rewrite)

**Drafting note (2026-07, author review):** the drafted quantization section reads
**repetitive** and carries **high AI-tell**. That, not theory depth, is the problem, and theory
depth is fine to keep. Fix in the rewrite: (1) **de-dup** --- the bytes-per-param -> "does it
fit" story is currently restated across the ladder, the AWQ/GPTQ bullet, and the FP8 bullet;
state it once and let each format add only its delta. (2) Run `book-style-sweep` +
`ai-tell-sweep` over the whole section. Still do NOT re-teach Ch 4's algorithms (that is
cross-chapter repetition, separate from the internal repetition above).

Ch 4 (`ch:models`) taught what AWQ/GPTQ/FP8 are and how they work. This section is the
production VRAM/throughput/quality decision, each point made once:

- **The bytes-per-param ladder** and what each buys back in VRAM for the 32B anchor
  (FP16 64 GB -> FP8 32 GB -> INT4 ~18--20 GB). INT4 is what moves 32B from "fits on nothing
  single-card" to "fits on a 24 GB card with KV headroom."
- **AWQ vs GPTQ in production** --- throughput (vLLM Marlin kernels, tokens/sec), quality drop
  (perplexity / benchmark delta for 4-bit at 30B+), when each is preferred. Numbers cited.
- **FP8 as the quality-preserving option** on Hopper/Blackwell --- half the VRAM of FP16, near
  the quality, native hardware support. The "if you have the card, this is the low-risk cut."
- **`kv-cache-dtype fp8`** --- quantize the KV cache too, doubling effective context for a
  small quality cost. Ties Act 3 back to Act 2's KV term.

Diagram: quant ladder (weight size for the 32B anchor at FP16/FP8/INT4). Synthetic pgfplots
panel: AWQ vs GPTQ vs FP16 tokens/sec + quality, captioned illustrative.

### Act 4 --- How the engine partitions VRAM (~15%, engine tuning first-principles)

The knobs that decide how the budget from Act 2 splits, taught as engine knowledge (vLLM docs
cited), not as iplane flags:

- **`gpu_memory_utilization`** (default 0.9) --- the fraction of the card vLLM is allowed to
  use. Weights load first; whatever remains inside the fraction becomes the paged KV block
  pool. Raise it to buy KV room, leave headroom or risk fragmentation OOM.
- **`max-model-len`** --- caps the context the engine reserves KV for. Set it past what the KV
  pool can hold and vLLM refuses to start ("not enough KV cache blocks"). Show the real
  startup-log failure and the fix.
- **`kv-cache-dtype`** --- from Act 3, the KV half of the quantization decision.

Diagram: engine VRAM partition --- total card -> utilization fraction -> weights first, KV pool
second, `max-model-len` a slice of the pool. Real vLLM startup transcript showing the KV-block
budget it computes.

### Act 5 --- Placement driven by the budget (control-plane, ~10%)

The first of two control-plane acts (the second is warm-cache mounts, Act 6); placement itself
stays light. The reader has computed what fits (32B AWQ
~18--20 GB weights + KV headroom -> a 24 GB+ SKU). iplane's requirements language resolves it:

- **Manual path:** run vLLM yourself with `--quantization awq --gpu-memory-utilization 0.92
  --max-model-len 8192`, and separately go shopping for a card with enough VRAM on whatever
  provider, by hand.
- **The iplane move:** `--class medium` / `--min-vram-gb 24` finds the card (Ch 6 provider-SKU
  matching), and `--engine-args ...` passes the same engine flags through in one line. iplane's
  value is finding a GPU that fits + the same deploy/observe surface, not engine tuning. The
  thinness is the point --- the control plane owns placement, the engine owns tuning, and the
  pass-through is one line of operational surface, not a section.

Keep the four-act "manual path hurts" honest: the manual path here is real (shopping for a card
+ hand-passing flags), but the iplane move is genuinely thin, so this act is short. Do not
invent suffering (`book-style-sweep`, "When to break it": the principle dwarfs the tool here).

### Act 6 --- Warm-cache model mounts: the cold-start problem at model scale (control-plane, ~15%)

The genuine control-plane spine of the chapter, and the answer to "there is not much for iplane
to do at model scale." At 30B+ the weights are the operational pain: a 32B is ~19 GB at AWQ and
~65 GB at FP16 (Acts 1--2). Cold-starting a pod means the engine downloads all of that from
HuggingFace before it can serve, and every new replica (Ch 7) pays it again. That download
dominates deploy time and cost at model scale in a way it never did at 8B.

- **The manual path (real pain):** you rent a pod, the engine pulls tens of GB from HF, you
  wait; you scale to a second replica, it pulls the same weights again; you redeploy after a
  config change, it pulls again. Per-pod, per-replica, per-iteration.
- **The iplane move (two steps):** `iplane model pin <model> --provider --region` downloads the
  weights ONCE onto a shared per-region volume (on a throwaway CPU worker; the volume accumulates
  many models). Then a plain `deploy` of that `(model, provider, region)` auto-resolves the pin
  and mounts the volume, redirecting `HF_HOME` so the engine reads weights off disk. Pin once,
  every later deploy is warm, config is the override not the requirement. The mount seam is
  generic (`volumecache.Store`), provider-scoped, and each adapter maps it (RunPod network volume
  vs sshdocker `-v` bind); a cross-provider mount is refused. Declare-intent-resolver-joins, the
  same shape as budget-driven placement. Manual alternative: pre-download + hand-wire mounts per
  provider + track which volume holds what.
- **Show impact (the money panel):** the cold-start `storage_tier` SLI attributes deploy latency
  to storage tier (cold HF download vs warm volume mount), so the reader SEES the warm-vs-cold
  win instead of being told about it. This is the "show impact, not facts" content the chapter
  was missing.

Also the first multi-instance scenario (N pods sharing one cached model), bridging Ch 7's
replicas toward Ch 10's multi-GPU without opening the multi-GPU box.

Diagram: cold-start timeline --- cold pod (rent -> HF download -> serve) vs warm pod (rent ->
mount volume -> serve), with the `storage_tier` SLI panel as the money shot (synthetic until a
paid run captures it, captioned illustrative).

### Act 7 --- The single-GPU ceiling (~10%, motivates Ch 10)

Where one GPU stops being enough. Two ways to hit the ceiling:

- **Weights alone don't fit.** A 70B model at INT4 is ~35--40 GB of weights, past a 24/32 GB
  card and leaving no KV room even on 48 GB. FP16 70B is ~140 GB, past any single card.
- **Weights fit but KV doesn't scale.** A 32B AWQ model fits on 24 GB, but a large context or
  a big concurrent batch runs the KV pool dry --- the exact ceiling Ch 8's `\S\ref{subsec:cache-ceiling}`
  hit from the routing side, now seen as a hard VRAM wall.

Both point at the same move: spread one engine's KV domain across several GPUs. That is tensor
parallelism, and it is Chapter 10 (`ch:multi-gpu`). Ch 9 closes exactly where Ch 8 said it
would --- at the single-GPU ceiling --- and hands the multi-GPU KV domain to Ch 10. Keep the
seam honest: Ch 9 never opens the box; it just shows why the box has to open.

Diagram: single-GPU ceiling --- 70B (and 32B-at-big-context) weight+KV bar exceeding one card,
the overflow motivating a shard across two cards (Ch 10 teaser, don't draw the mechanism).

### Capability Snapshot (light stub, now mostly draftable)

Transcribes the `ch09-final` `capabilities.yaml` entry once a `ch09-final` tag is cut. The
surface is no longer roadmap-only (see "iplane surface state" above): transcribe the warm-cache
model cache (`iplane model pin` + auto-resolved provider-scoped mounts, generic `volumecache`), the cold-start `storage_tier` SLI, the Ch 6
budget-driven placement surface (`--min-vram-gb` / `--class`), and the `--engine-args`
pass-through. The dedicated `--quantization` convenience flag, AWQ/GPTQ image variants, and
`--engine-config` profiles stay roadmap/deferred. Keep it a light stub until the tag + YAML
entry exist (draft ahead with `date: TBD` per `book/CLAUDE.md`). Mark chapter-scope deferrals
(multi-GPU KV domain = Ch 10) as **prose**, not `\item` entries, so `check-snapshots` doesn't
flag them as unexpected capabilities (per `book/CLAUDE.md` Ch 7/8 transcription notes).

## Patterns to name (with `\label{pattern:<slug>}` at first naming)

- **The weights term is fixed at load time; the KV term is what you tune.** Quantization sets
  a floor on VRAM (weights), and everything above that floor is a KV-vs-context-vs-batch
  decision the operator makes. Separates the model-architect knob (Ch 4) from the operator knob.
- **Placement is a control-plane concern; tuning is an engine concern.** iplane finds the card
  the budget needs; the engine flags that split the card ride through as opaque pass-through.
  The chapter's concrete instance of the control plane staying thin (echoes Ch 8's "affinity is
  a property of the traffic, not the deployment").

## Diagrams planned (~6, matching Ch 7/8 density)

1. `diagram_vram_budget_stack` --- stacked bar, four components, FP16 vs INT4.
2. `diagram_does_it_fit` --- 32B weight block vs card-capacity lines at each quant.
3. `diagram_quant_ladder` --- weight size for the 32B anchor at FP16/FP8/INT4.
4. `diagram_engine_partition` --- how vLLM splits the card (utilization -> weights -> KV pool).
5. `diagram_kv_growth` --- KV GB vs context/batch for the 32B model, the pool ceiling.
6. `diagram_single_gpu_ceiling` --- 70B / 32B-at-big-context overflowing one card -> Ch 10.
   Plus a synthetic pgfplots throughput/quality panel (AWQ/GPTQ/FP16), captioned illustrative.

## Sources to cite (fill from research fact-sheet)

- Anchor 32B model HF card (dims, file sizes FP16 vs AWQ vs GPTQ) + one 70B anchor.
- NVIDIA spec pages: RTX 5090 (32 GB), 4090 (24 GB), L40S (48 GB), RTX PRO 6000 Blackwell,
  A100 (40/80 GB), H100 (80 GB), H200. Launch dates + memory bandwidth.
- vLLM docs: `--gpu-memory-utilization`, `--max-model-len`, `--kv-cache-dtype`, `--quantization`,
  Marlin kernels; AWQ + GPTQ papers/docs for the production throughput/quality figures.
- Ch 3 (`ch:hardware-fundamentals`) for card specs already in the book, Ch 4 (`ch:models`) for
  the quantization algorithm callback.
