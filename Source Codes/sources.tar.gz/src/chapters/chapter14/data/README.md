# Committed sweep artifacts for Chapter 14

Copies of the measurement runs the chapter's figures plot, taken from
`inference_plane/docs/data/`. They live here so the book builds without the paired
repo checked out, and so a figure regenerates from data rather than from retyped
coordinates.

**The iplane copy is canonical.** `make check-series` in that repo re-derives every
figure marked `measured` in `docs/data/series.yaml` from the artifact there, not from
these. Refresh these by copying, and never edit them in place: a divergence here would
be invisible to that check, which is exactly the failure mode Chapter 14 spends its
first section on.

Each file carries its provenance in `#` header lines. Read them with
`[col sep=comma, comment chars={\#}]`.

| File | Context | Rate | Status |
| --- | --- | --- | --- |
| `glm52-8k-vast-h200-tp8.csv` | 8k | $32.88/hr, recorded | Six levels, all graded |
| `glm52-32k-vast-h200-tp8.csv` | 32k | $34.0022/hr, recorded | Five levels, sample-targeted |
| `glm52-120k-vast-h200-tp8-ranging.csv` | 120k | inferred, back-solved | Ranging shot, three of four unusable |
