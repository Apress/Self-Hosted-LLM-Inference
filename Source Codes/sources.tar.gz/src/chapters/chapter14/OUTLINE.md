# Chapter 14 working outline

**Status (2026-08-26): complete first draft.** All six acts, 17 pages, four figures and one table.
Builds with zero errors, zero overfull boxes and zero unresolved references.

Both open questions are settled. The title is **What It Costs, and Why Batching Stops Helping**, and
the figures read their committed CSV artifacts directly through `pgfplotstable`, which is the
pipeline Ch 13 deferred. The artifacts live in `data/` with a README saying the iplane copy is
canonical.

Evidence lives in `part4_outline.md` under "Evidence from the capacity audits". This file decides
what the chapter does with it. Three measured runs exist and every headline figure is a macro from
`src/styles/part4-values.tex`, so this chapter can be drafted before the remaining measurements
are taken and the proof will show which numbers are still placeholders.


**Style sweep 2026-08-27.** Passed on every mechanical check. Flagged on the additive one: 11 uses
of "we" and one parenthetical aside across six sections is thin for a chapter this long. Two
`% TODO(friction)` markers added at the spots that most want a real incident, collected by
`make friction`.

---

## The title, settled 2026-08-26

The chapter is called **What It Costs, and Why Batching Stops Helping**. At 8k the curve flattens. At
32k it peaks at concurrency 8 and turns. At 120k it inverts outright. The title names one third of
the result, and the abstract was rewritten on 2026-08-26 to promise two regimes and a test for
telling them apart, so the two currently disagree with each other.

Options, in the order we would recommend them:

1. **What It Costs, and Why Batching Stops Helping.** Keeps the comma register of the part, names
   the finding that actually generalises, and covers all three contexts.
2. **What It Costs, and What Makes It Cost That.** Broader, survives any further measurement, and
   is vaguer than the chapter deserves.
3. **Keep the current title**, and let "flattens" mean the short-context regime the chapter opens
   on. Cheapest, and it under-sells the result.

Open decision 8 in `part4_outline.md`. Nothing else here depends on it, so drafting can start on
acts 1 and 2 while it is settled.

---

## What the chapter has to establish

One claim, in three parts, and each part has a measurement behind it.

1. Cost per token falls as batch grows **while decode dominates**, onto a floor no batch size goes
   below. Measured at 8k, fitted, floor `\PartIVFitEightK`.
2. It stops falling, and then reverses, **because prefill interrupts decode**. Your prefill is
   charged to other people's decode. Measured at 32k, where the inter-token tail multiplies by
   `\PartIVItlPNineFiveJumpThreeTwoK` between concurrency 4 and 8 while the median barely moves.
3. Which regime you are in is decided by context length, and the relationship is proportional.
   Three points, two intervals, exponents 1.00 and 1.13.

The reader leaves able to answer two questions about their own workload: which regime am I in, and
what batch size should I run. The diagnostic for the first is the time-to-first-token share of
latency. The answer to the second walks down as context rises.

---

## The anchor

GLM-5.2 at AWQ-INT4 on 8x H200, tp8, 512 output tokens, three context lengths. Same box, same
harness, same model. The only variable that moves between runs is the prompt length, which is what
makes the comparison worth anything.

| Context | Artifact | Rate | Status |
| --- | --- | --- | --- |
| 8k | `glm52-8k-vast-h200-tp8.csv` | $32.88/hr, recorded | Six levels, all graded |
| 32k | `glm52-32k-vast-h200-tp8.csv` | $34.00/hr, recorded | Five levels, sample-targeted |
| 120k | `glm52-120k-vast-h200-tp8-ranging.csv` | **inferred**, back-solved | Ranging shot, three of four unusable |
| 16k, 64k | none | | **Simulated placeholders**, will print `[SIMULATED]` |

---

## Section plan

Six acts, matching Ch 13's shape because the chapter has the same two-part structure: establish
how we know, then what we found.

### Act 1 - What a cost number has to survive (~18%)

Open on the trap rather than on the answer, because the chapter's authority rests entirely here and
because the failures are more interesting than the successes.

The first sweep deployed correctly, served correctly, and produced nothing publishable. Five faults,
none exotic, all of them the defaults somebody reached for, and together they produced a chart that
looked entirely normal. **An undersized measurement does not look undersized, it looks like data.**

Then the three disciplines that came out of it, in the order they apply. Size the window by sample
count rather than by clock, because a heavy-tailed distribution makes the warm-up's rate a liar.
Grade what came out, so a row says which statistic it can support rather than the run getting a
verdict. And cross-check the row against itself, because a threshold check needs a model of correct
behaviour and only catches what you already thought of, while a cross-check needs no such model.

Close on the two ways an artifact lies about itself: the header that describes the previous method,
and the eighteen provenance fields that record the system exhaustively and forget the invoice.
**The test is whether a stranger can re-derive your number from the file alone.**

### Act 2 - The curve at short context (~18%)

The 8k six-level table, then the fit.

`cost/M = 94.43/B + 25.18`, two parameters against six points, four of them interior and
unconstrained, maximum error 4.2%. The mechanism is not merely consistent with the data, it is
recovered from it, and both halves come out with a number: the amortisable weight read, and a floor
of `\PartIVFitEightK` per million output tokens that no batch size goes below.

Then the beat that makes the chapter more than an arithmetic exercise. **The cheap point and the
usable point are nowhere near each other.** `\PartIVCostFloorEightK` costs a 42-second median and
8.3 tokens a second per user. The rows a person would actually wait for cost three to four times as
much. No operating point is both, and that gap is the economics of serving.

### Act 3 - Where batching stops paying (~24%)

The chapter's centre and the one genuinely new result.

At 32k the curve peaks at `\PartIVPeakBatchThreeTwoK` and turns. Show the inter-token table, because
the whole effect is in it and none of it is in the median: p50 walks gently from 10.8 to 23.5 ms
across a thirtyfold concurrency range and looks tame, while p95 multiplies by
`\PartIVItlPNineFiveJumpThreeTwoK` between concurrency 4 and 8. The engine still generates at full
speed whenever it is generating. What changed is that generation is interrupted.

Time to first token is flat from 1 through 16, which rules out the obvious explanation. Requests are
not waiting longer to start. They are being interrupted once started, and the thing interrupting
them is other requests' prefill.

**Your prefill is charged to other people's decode.** One mechanism, all three contexts. It
generalises past this engine, because any scheduler interleaving prefill with decode has the
property.

Show the three earlier explanations as superseded rather than landing quietly on the right one. The
conclusion survived all three tellings and the cause was wrong twice, which is a better
advertisement for measuring than a clean confirmation.

### Act 4 - The law (~14%)

Three contexts, best measured cost at each, two intervals, exponents 1.00 and 1.13. Cost per token
is proportional to context length.

State the seam plainly. The clean interval is 8k to 32k. The long end leans on a ranging shot whose
price was back-solved from the figure it is supposed to support, so its shape is measured and its
magnitude is reconstructed. That costs the argument nothing, because the claim at 120k is about
direction.

The operator-facing form is the second series and may be worth more than the law: the best batch
size walks down monotonically, `\PartIVPeakBatchEightK` at 8k, `\PartIVPeakBatchThreeTwoK` at 32k,
`\PartIVPeakBatchOneTwoZeroK` at 120k. The physics is smooth. What changes discontinuously is the
advice.

### Act 5 - What it cost to find out (~13%)

The economics of the measurement itself, which the chapter is unusually well placed to price.

The cost-of-not-knowing table: a failure diagnosed at the timeout, the same failure abandoned at
five minutes, a rehearsal on one card, a dry run. Then the row that table was missing, which is what
a *false* abort costs. Our own download guard destroyed a healthy rental at $31.76/hr, having
projected a completion time from a metadata phase that runs at a thousandth of the shard rate.
Every argument for adding a guard is an argument about the disaster it prevents, and nobody prices
the guard firing wrongly.

Rehearse the expensive path on the cheap one. A twelve-cent GPU settled a question about a $43 run,
by measuring rather than reasoning.

### Act 6 - Why you cannot match the API (~13%)

The question the whole book has been walking toward, answerable now rather than arguable.

At short context a crossover exists and can be computed. At long context there is none, because the
curve turns over before it comes near a provider's flat rate. A provider batching thousands of
mixed tenants is not merely enjoying a bigger batch, it is choosing a traffic mix where long
prefills are rare relative to decode work, which is a structural advantage rather than a scale one.

Prefix caching gets priced rather than described. A cached-input tier discounted by ninety percent
is worth almost exactly the context multiplier act 4 measures, which is why providers sell one and
why it is the most valuable thing a long-context self-hoster can build. Chapter~\ref{ch:caching}
built it qualitatively.

Hand off to Ch 15, which takes the ceiling.

---

## Patterns to name

| Pattern | Slug | Act |
| --- | --- | --- |
| An undersized measurement looks like data | `pattern:undersized-looks-like-data` | 1 |
| A cross-check needs no model of correctness | `pattern:cross-check-no-model` | 1 |
| Your prefill is charged to other people's decode | `pattern:prefill-externality` | 3 |
| Cost per token is proportional to context | `pattern:cost-proportional-to-context` | 4 |
| Price the guard, not only what it guards | `pattern:price-the-guard` | 5 |

---

## Diagrams planned

1. **The 8k curve with the fit overlaid** (act 2). Cost per million against batch, six measured
   points and `94.43/B + 25.18` through them. The one figure the chapter cannot do without.
2. **The cheap point against the usable point** (act 2). Cost per million and per-user tokens per
   second on one axis, so the gap is visible rather than asserted.
3. **The inter-token tail** (act 3). p50 and p95 against concurrency at 32k. The median flat, the
   tail exploding. This is the figure that proves the mechanism.
4. **Three curves, three contexts** (act 4). Cost against batch for 8k, 32k and 120k, with the peak
   walking left. Includes the two simulated points, which will carry their markers.
5. **The proportionality** (act 4). Best cost against context on log axes, with the fitted slope.
6. **Optional: where the crossover goes** (act 6). Self-hosted cost against a provider's flat rate,
   per context, showing the crossover existing and then not.

Figures 1, 4 and 5 want `\addplot table` reading the committed CSVs, which is the pipeline decision
Ch 13 deferred. This is where it has to be made.

---

## What is missing, and none of it blocks drafting

- 16k and 64k runs. Placeholders exist and will print `[SIMULATED]` in the proof.
- A publishable 120k sweep. The ranging shot carries the direction; the magnitude is reconstructed.
- The 120k hourly rate, which was never recorded and is back-solved.

---

## Open questions

1. **The title.** See above. Blocks nothing but the spine reads oddly until it is settled.
2. **The figure pipeline.** Three of six figures want to read the CSVs directly. Build it once here,
   or transcribe with provenance comments the way Ch 9 does.
3. **How much methodology act 1 can carry** before the chapter reads as a paper about measurement
   rather than a chapter about cost. Currently 18%, which is already generous.
