# Chapter 10 Research Fact-Sheet: Multi-GPU and Distributed Inference

Backbone argument for the chapter: **the interconnect is the binding constraint, not per-card VRAM.** Every number below is real, dated, and carries a source URL plus an access date. Where a figure is contested or framing-dependent (especially bidirectional vs per-direction bandwidth), the range and the framing are called out explicitly.

All access dates: **2026-07-28** unless noted otherwise.

A recurring framing hazard runs through areas 2 and 3: NVIDIA quotes NVLink and NVSwitch bandwidth as **aggregate bidirectional** (sum of both directions across all links), while PCIe and InfiniBand are usually quoted **per direction per port**. Comparisons below normalize to one framing and say which one. Do not mix them in prose or the "order of magnitude" claim will look either inflated or understated.

---

## 1. 70B weight-size anchor

**Model chosen: Meta Llama 3.3 70B Instruct** (`meta-llama/Llama-3.3-70B-Instruct`). Still the standard, widely-deployed open-weights ~70B dense model as of mid-2026, same architecture family as Llama 3.1 70B, released December 2024.

- **Parameter count: ~70.6B** (HF model card lists "71B params"). Native tensor dtype is **BF16**.
  Source: <https://huggingface.co/meta-llama/Llama-3.3-70B-Instruct> (accessed 2026-07-28)
- **BF16/FP16 weights on disk: 141.12 GB** (F16 reference size, from the widely-mirrored GGUF conversion of the same weights).
  Source: <https://huggingface.co/bartowski/Llama-3.3-70B-Instruct-GGUF> (accessed 2026-07-28)
- **INT4-class quantization (Q4_K_M): 42.52 GB**; Q4_K_S 40.35 GB; Q4_K_L 43.30 GB. Q8_0 (INT8-class) 74.98 GB for reference.
  Source: <https://huggingface.co/bartowski/Llama-3.3-70B-Instruct-GGUF> (accessed 2026-07-28)

**The "won't fit one 80GB card at FP16" claim, made honest.** At BF16 the weights alone are **~141 GB**, which is **~1.76x an 80GB H100/A100 SXM card** and still exceeds a single **141 GB H200** once you add KV cache, activations, and CUDA/runtime overhead (H200 gives 141 GB HBM3e; weights alone would leave essentially zero headroom). So FP16 70B needs at least **two 80GB cards**, and the moment you use two cards the interconnect between them becomes the story. INT4 (~43 GB) *does* fit one 80GB card, which is exactly why the chapter should frame multi-GPU as driven by the FP16/BF16 footprint (and by throughput/KV headroom), not as an unconditional law.

Sanity check on the arithmetic: 70.6e9 params x 2 bytes = ~141.2 GB, matching the 141.12 GB on-disk figure. The rule of thumb "2 GB per billion params at FP16" holds.

---

## 2. Interconnect bandwidth ladder (the core numbers)

This is the spine of the chapter. Figures are given with their framing labeled.

### NVLink, per-GPU (NVIDIA quotes these as aggregate bidirectional per GPU)

- **NVLink 4 (Hopper / H100): 900 GB/s per GPU.** 18 links x 50 GB/s each (25 GB/s per direction per link).
  Sources: <https://www.nvidia.com/en-us/data-center/nvlink/> and <https://naddod.medium.com/nvidia-gb200-interconnect-architecture-analysis-nvlink-infiniband-and-future-trends-91dc6ba49bf3> (accessed 2026-07-28)
- **NVLink 5 (Blackwell / B200, GB200): 1,800 GB/s per GPU.** 18 links x 100 GB/s each. Exactly 2x Hopper.
  Source: <https://www.nvidia.com/en-us/data-center/nvlink/> (accessed 2026-07-28)
- (Forward reference, do not over-rely) **NVLink 6 (Rubin): 3,600 GB/s per GPU** listed on NVIDIA's NVLink page as the next generation. Roadmap, not shipping-at-scale in mid-2026. Source: same NVIDIA page above.

### NVSwitch aggregate (rack/domain fabric)

- **H100 HGX/DGX node: 8 GPUs fully connected via 4 NVSwitch chips**, every GPU sees the full **900 GB/s** to the NVLink domain (all-to-all, not just paired). This is what makes an 8-GPU box behave "as one big GPU."
  Source: <https://www.naddod.com/blog/nvlink-vs-pcie-choosing-the-best-option-for-nvidia-ai-servers> (accessed 2026-07-28)
- **Blackwell NVL72 NVSwitch fabric: 130 TB/s aggregate** across the 72-GPU NVLink domain.
  Source: <https://www.nvidia.com/en-us/data-center/nvlink/> (accessed 2026-07-28)

### PCIe (per-direction, x16)

- **PCIe Gen5 x16: 64 GB/s raw per direction, ~63 GB/s effective** after 128b/130b encoding. Bidirectional aggregate ~128 GB/s.
  Source: <https://pciesimulator.com/pcie-5-0-speed/> (accessed 2026-07-28)
- **PCIe Gen4 x16: ~32 GB/s per direction** (~31.5 GB/s), ~64 GB/s bidirectional aggregate.
  Source: <https://pciesimulator.com/pcie-4-0-speed/> and <https://servermall.com/blog/pcie-gen4-gen5-bandwidth-and-bottlenecks/> (accessed 2026-07-28)

### InfiniBand / RDMA (per-port, per-direction)

- **InfiniBand NDR: 400 Gb/s per port = 50 GB/s per direction.**
  Source: <https://www.naddod.com/blog/infiniband-ndr-the-future-of-high-speed-data-transfer-in-hpc-and-ai> (accessed 2026-07-28)
- **InfiniBand XDR: 800 Gb/s per port = 100 GB/s per direction.** Spec announced by IBTA on **2023-10-05**; NVIDIA Quantum-X800 XDR switches reported shipping in volume as of **December 2025** (secondary source; see caveats).
  Sources: <https://www.infinibandta.org/ibta-unveils-xdr-infiniband-specification-to-enable-the-next-generation-of-ai-and-scientific-computing/> (accessed 2026-07-28), <https://nvidianews.nvidia.com/news/networking-switches-gpu-computing-ai> (accessed 2026-07-28), shipping claim: <https://www.fibermall.com/blog/nvidia-infiniband-switches.htm> (accessed 2026-07-28)

### The order-of-magnitude gap (the load-bearing comparison)

Normalize both sides to **per-direction** to be fair:

| Fabric | Per-direction | vs PCIe Gen5 x16 (63 GB/s) |
|---|---|---|
| NVLink 4 (H100) | 450 GB/s | ~7x |
| NVLink 5 (B200) | 900 GB/s | ~14x |
| InfiniBand XDR | 100 GB/s | ~1.6x |
| InfiniBand NDR | 50 GB/s | ~0.8x |
| PCIe Gen4 x16 | ~32 GB/s | 0.5x |

Or normalize to **aggregate bidirectional** (NVIDIA's native NVLink framing):

- NVLink 5 1,800 GB/s vs PCIe Gen5 128 GB/s = **~14x**
- NVLink 4 900 GB/s vs PCIe Gen5 128 GB/s = **~7x**
- NVLink 4 900 GB/s vs PCIe Gen4 64 GB/s = **~14x**

**Bottom line for prose:** NVLink is a **7x to 14x** step over PCIe depending on generation pairing. The clean "order of magnitude (~10x+)" line is honest specifically for **NVLink 5 over PCIe Gen5** and for **NVLink 4 over PCIe Gen4**. Note also that InfiniBand XDR (100 GB/s/dir) is comparable to PCIe within a node and far below NVLink, which is the technical reason cross-node fabric cannot substitute for intra-node NVLink for tensor parallelism.

---

## 3. TP-on-wrong-fabric throughput loss

Caveat up front: rigorous, primary, apples-to-apples vLLM "NVLink vs PCIe-only, same model, same TP degree" benchmark tables are thin in public sources. The numbers below are real but mostly from vendor/practitioner blogs, so treat them as **directional evidence with ranges**, not canonical figures. Flagged again in the confidence note.

**Mechanism.** Tensor parallelism issues an **all-reduce (or all-gather + reduce-scatter) on every transformer layer**, twice per layer in the standard Megatron-LM sharding (once after the attention block, once after the MLP block). That traffic is on the critical path of every token, so it is both bandwidth-hungry and latency-sensitive. On a PCIe-only fabric the collective serializes over the ~63 GB/s-per-direction link (and often over a shared PCIe root/host bridge), so per-layer communication stops overlapping with compute and starts dominating.

**Reported scaling-efficiency figures (secondary sources, ranges):**

- PCIe-only multi-GPU tensor-parallel scaling efficiency reported around **61–74%** in one practitioner benchmark; the author explicitly notes the test used PCIe only and that NVLink would raise the numbers.
  Source: <https://runaihome.com/blog/multi-gpu-local-ai-nvlink-vs-pcie-2026/> (accessed 2026-07-28)
- A sharper (and more pessimistic, so cite carefully) claim: **8-GPU PCIe training ~20–30% efficiency vs ~75–85% for NVLink/SXM** at 8-way. This is a training-oriented figure and the more GPUs in the TP group, the worse PCIe scales, so it should be quoted as "at 8-way, PCIe collapses" rather than as a general inference number.
  Source: <https://www.spheron.network/blog/h100-nvl-vs-sxm5-vs-pcie-form-factor-guide/> (accessed 2026-07-28)
- Qualitative but consistent: "Without NVLink, the all-reduce operations in tensor parallelism become a severe bottleneck, negating most of the performance gains." NVLink-connected SXM scales most efficiently; PCIe has higher per-layer communication overhead.
  Source: <https://www.spheron.network/blog/vllm-production-deployment-2026/> (accessed 2026-07-28)

**Safe framing for the chapter:** at TP=2 on PCIe the penalty is real but often tolerable (you eat maybe a quarter to a third of your scaling); at TP=4 and especially TP=8 on PCIe it degrades badly, and NVLink/NVSwitch is close to linear where PCIe is not. Give the reader the direction and the mechanism; avoid quoting a single hard percentage as if it were universal.

**Pipeline-parallel bubble cost.** PP splits the model by layer across stages and hands off activations once per stage boundary, so its communication volume is far lower than TP. Its cost is the **pipeline bubble**: idle stages while the pipeline fills and drains. Bubble fraction ~ `(p - 1) / (m + p - 1)` for `p` pipeline stages and `m` microbatches, so it shrinks as you increase in-flight microbatches. This is why PP tolerates slow/cross-node links (InfiniBand, even Ethernet-RDMA) but adds latency and needs enough concurrent work to stay full.
  Source (formula and mechanism, standard Megatron/GPipe result, restated in vLLM guidance): <https://docs.vllm.ai/en/stable/serving/parallelism_scaling/> (accessed 2026-07-28)

---

## 4. Provider SKU examples (and how inconsistently NVLink is documented)

The operational pain the chapter dramatizes: **you often cannot tell the NVLink-equipped SKU from the PCIe-only one before you pay.** SXM/HGX form factor implies NVSwitch full mesh; PCIe form factor implies at best a 2-GPU NVLink bridge (pairs only) and frequently no NVLink at all. Providers document this unevenly.

**Instances that expose full NVLink/NVSwitch between cards:**

- **AWS p5.48xlarge: 8x H100 SXM, 900 GB/s NVSwitch, 3,200 Gbps EFA** networking. p5en.48xlarge: 8x H200, same 900 GB/s NVSwitch, 3,200 Gbps EFA. AWS documents the NVSwitch bandwidth explicitly on the instance page.
  Source: <https://aws.amazon.com/ec2/instance-types/p5/> (accessed 2026-07-28)
- **AWS p4d.24xlarge: 8x A100 40GB** with NVSwitch (previous gen), 600 GB/s NVLink domain. Source: <https://aws.amazon.com/ec2/instance-types/accelerated-computing/> (accessed 2026-07-28)
- **CoreWeave** markets HGX H100/H200 nodes with NVLink/NVSwitch plus InfiniBand between nodes; positions itself explicitly around enterprise fabric. Source: <https://www.gpu.fm/blog/cloud-gpu-providers-comparison-2026> (accessed 2026-07-28)
- **Lambda** offers 8x H100 SXM (NVLink/NVSwitch) nodes and InfiniBand-connected clusters. Source: <https://www.gpu.fm/blog/cloud-gpu-providers-comparison-2026> (accessed 2026-07-28)

**Where PCIe-only / paired-NVLink multi-GPU hides:**

- **H100 PCIe** cards connect at most **in pairs via an NVLink bridge** (GPU1<->GPU2, GPU3<->GPU4), not all-to-all. A 4x or 8x PCIe box therefore is NOT one NVLink domain, even though the listing may just say "4x H100."
  Source: <https://www.naddod.com/blog/nvlink-vs-pcie-choosing-the-best-option-for-nvidia-ai-servers> (accessed 2026-07-28)
- **RunPod / Vast.ai / marketplace-style providers** list cards by count and VRAM (e.g. "2x H100", "4x A6000") and frequently do **not** state whether NVLink is present or whether the GPUs share one PCIe root. RunPod distinguishes "Secure Cloud" vs "Community Cloud" hosts whose topology varies by host. Source: <https://www.runpod.io/articles/guides/top-cloud-gpu-providers> and <https://getdeploying.com/gpus/nvidia-h100> (accessed 2026-07-28)
- The H100 form-factor split itself is the trap: **SXM5 HBM3 ~3.35 TB/s memory bandwidth and full NVSwitch, vs PCIe ~2 TB/s and pair-only NVLink.** Same "H100" name, very different multi-GPU behavior.
  Source: <https://www.hyperstack.cloud/technical-resources/performance-benchmarks/comparing-nvidia-h100-pcie-vs-sxm-performance-use-cases-and-more> (accessed 2026-07-28)

**The documentation-inconsistency point, concretely:** AWS states NVSwitch bandwidth on the SKU page; hyperscaler HGX SKUs are safe by construction. Marketplace and community-cloud listings routinely omit interconnect topology, so identical-looking "Nx H100" offers can be full-mesh NVSwitch or a PCIe box with no NVLink, at different prices, with no field on the listing to tell them apart. That gap is the manual-path pain the control-plane chapter answers.

---

## 5. vLLM distributed-inference specifics

The book treats these as **engine behavior it cites**, deferring the actual deploy-flag mechanics to Ch 12.

- **Flags:** `--tensor-parallel-size` (a.k.a. `-tp`, `tensor_parallel_size` in the `LLM(...)` Python API) and `--pipeline-parallel-size` (`-pp`, `pipeline_parallel_size`).
  Source: <https://docs.vllm.ai/en/stable/serving/parallelism_scaling/> (accessed 2026-07-28)
- **Distributed runtime:** native Python **multiprocessing for single-node**, **Ray for multi-node**. "The default distributed runtimes are Ray for multi-node inference and native Python multiprocessing for single-node inference."
  Source: <https://docs.vllm.ai/en/v0.9.1/serving/distributed_serving.html> (accessed 2026-07-28)
- **Intra-node NVLink vs multi-node guidance (near-verbatim):** "The common practice is to set the tensor parallel size to the number of GPUs in each node, and the pipeline parallel size to the number of nodes." Example: 2 nodes x 8 GPUs -> `--tensor-parallel-size 8 --pipeline-parallel-size 2`.
  Source: <https://docs.vllm.ai/en/stable/serving/parallelism_scaling/> (accessed 2026-07-28)
- **When TP wants NVLink (near-verbatim):** "if the GPUs on the node do not have NVLINK interconnect (e.g. L40S), leverage pipeline parallelism instead of tensor parallelism for higher throughput and lower communication overhead." This is vLLM's own docs saying TP without NVLink is the wrong tool, which is precisely the chapter's thesis.
  Source: <https://docs.vllm.ai/en/stable/serving/parallelism_scaling/> (accessed 2026-07-28)
- The docs also note TP *can* extend across nodes when they are joined by a fast fabric (NVLink or high-rate InfiniBand), but the default recommendation keeps TP within the NVLink island and PP across nodes.
  Source: <https://github.com/vllm-project/vllm/blob/main/docs/serving/parallelism_scaling.md> (accessed 2026-07-28)

---

## 6. TP vs PP communication pattern (concept-level, for accuracy-checking the prose)

Confirmed correct, with nuances the prose must not get wrong:

**Tensor parallelism (TP):**
- Splits the weight matrices **within a layer** across GPUs (Megatron-style: column-parallel then row-parallel), so each GPU holds a slice of every layer.
- Requires a collective (**all-reduce**, or all-gather + reduce-scatter) at **every layer boundary**, on the critical path of every token. Roughly two all-reduces per transformer block.
- **Bandwidth-hungry and latency-sensitive.** Wants **NVLink intra-node**; degrades sharply on PCIe and across nodes.
- Reduces per-GPU weight memory AND per-GPU compute per layer, so it lowers latency for a single request when the fabric can keep up.

**Pipeline parallelism (PP):**
- Puts **different layers (stage groups) on different GPUs**; each GPU holds all of a contiguous subset of layers.
- Communicates only at **stage boundaries** (activations handed forward, gradients backward in training; for inference just the forward activation hand-off), so **far lower bandwidth** per token than TP.
- **Tolerates slower links**: RDMA/InfiniBand, cross-node, even the L40S no-NVLink case above.
- Cost is the **pipeline bubble** (idle stages during fill/drain), amortized by running more concurrent microbatches/requests. It trades latency and scheduling complexity for cheap communication.

**Nuances to keep the prose honest:**
1. TP does not "wait for every GPU at every layer" in a bad-latency sense on NVLink; the all-reduce overlaps with compute *when bandwidth is sufficient*. The failure mode is specifically **insufficient fabric**, not TP itself. State it as "TP is fine on NVLink, pathological on PCIe," not "TP is slow."
2. PP's low bandwidth is not free throughput. Its bubble means a PP-only deployment can leave GPUs idle unless request concurrency (microbatch count) is high, which is why serving stacks combine TP within the node and PP across nodes rather than choosing one.
3. "TP within node, PP across nodes" is the standard heuristic precisely because it maps TP's heavy per-layer traffic onto NVLink and PP's light per-stage traffic onto the slower inter-node fabric. This is the one sentence that ties areas 2, 3, 5, and 6 together.
4. Do not conflate memory savings: both TP and PP reduce per-GPU weight footprint, but only TP reduces per-GPU compute per layer. A reader could wrongly infer PP speeds up a single token; it does not, it enables fitting a bigger model and higher aggregate throughput.

Sources for the concept-level confirmation: <https://docs.vllm.ai/en/stable/serving/parallelism_scaling/> and <https://genmind.ch/posts/Tensor-Parallelism-in-Transformers-A-Hands-On-Guide/> (both accessed 2026-07-28); Megatron-LM sharding is the canonical reference for the two-all-reduces-per-block structure.

---

## Confidence / caveats

- **High confidence (primary sources):** Llama 3.3 70B is 70.6B params / BF16 / 141.12 GB at F16 and ~42.5 GB at Q4_K_M; NVLink 4 = 900 GB/s and NVLink 5 = 1,800 GB/s per GPU (NVIDIA's own NVLink page); NVL72 NVSwitch = 130 TB/s; PCIe Gen5 x16 = 63 GB/s/dir effective, Gen4 = ~32 GB/s/dir; InfiniBand NDR 400 Gb/s, XDR 800 Gb/s (IBTA); AWS p5 = 8x H100 SXM, 900 GB/s NVSwitch, 3,200 Gbps EFA; vLLM flags and the "no NVLink -> use PP" and "TP=GPUs-per-node, PP=nodes" guidance (vLLM docs, near-verbatim).
- **Medium confidence (secondary/practitioner sources, use as ranges, area 3):** the specific TP scaling-efficiency percentages (PCIe ~61–74%; the ~20–30% vs ~75–85% at 8-way split) come from vendor and practitioner blogs, not from a primary vLLM/NVIDIA benchmark table. Quote them as directional with the mechanism, not as canonical numbers. If the chapter wants a hard published number, the honest move is to run a small TP=2 vs TP=2 measurement on the paired repo's hardware and cite that instead.
- **Medium confidence:** the "Quantum-X800 XDR shipping in volume December 2025" claim is from a networking-vendor blog (fibermall), not an NVIDIA press release. The IBTA spec (2023-10-05) and NVIDIA's Quantum-X800 product announcement are primary; the exact volume-availability month is secondary. Safe prose: "XDR (800 Gb/s) is specified and shipping in 2025-2026-era Blackwell clusters."
- **Framing hazard, restate in prose:** NVLink/NVSwitch numbers are aggregate bidirectional; PCIe and InfiniBand numbers are per-direction per-port. The fact-sheet normalizes both ways in area 2; whichever the chapter picks, keep it consistent across the whole comparison or the "order of magnitude" line will look wrong.
- **Not independently verified:** exact H200-headroom claim for fitting 70B BF16 is arithmetic (141 GB weights vs 141 GB HBM3e leaves ~0 for KV/activations), not a benchmarked OOM. Correct in principle; if the prose asserts "won't run on a single H200" it should say "leaves no room for KV cache and activations" rather than implying the weights themselves don't fit.
- **Version drift to watch:** vLLM doc quotes are from the current stable and v0.9.1 docs as of 2026-07; flag names have been stable for a long time but the multiprocessing-vs-Ray default and cross-node TP guidance have moved between minor versions, so re-check against the pinned engine version before publishing.
