# Chapter 10 handoff (full draft complete, pre-commit)

We're drafting Chapter 10 (Multi-GPU and Distributed Inference) of "Inference Is
All You Need" in `/Users/dzshrh/books/inference_is_all_you_need/book`. Read these
first, in order:

- `src/chapters/chapter10/OUTLINE.md` (the plan; status notes at top)
- `src/chapters/chapter10/RESEARCH_FACTSHEET.md` (all numbers, dated + sourced)
- `src/chapters/chapter10/index.tex` (the draft)
- `CLAUDE.md` (mechanics + gotchas) + the `book-style-sweep` skill (voice)
- the `MEMORY.md` index and relevant memories

## State (2026-08-09)

**All six acts plus Problems are drafted.** The chapter builds clean and every page
has been visually verified. 20 pages, ~6.7k words, 7 figures. Style sweep run
(mechanical patterns clean; a handful of rhetorical-payoff and stacked-fragment
fixes applied). `make check-snapshots` passes and does not flag Ch 10, because the
Capability Snapshot is prose with no `\item` entries and no `ch10-final` tag exists.

The chapter is control-plane-centric (alternates from Ch 9). Engine stays an opaque
box. The two control-plane jobs are the spine: (1) networking-aware provisioning
(Act 3), (2) tracking a distributed data plane / pull-to-push (Act 4).

## Done

- Act 1 Where We Left Off
- Act 2 The Multi-GPU KV Domain (diagrams `tp_vs_pp`, `sharded_kv_domain`,
  `interconnect_ladder`; pattern `pattern:interconnect-binding-constraint`)
- Act 3 Networking-Aware Provisioning (diagrams `topology_aware_placement`,
  `tp_throughput`; pattern `pattern:provision-connected-pool`)
- Act 4 Tracking a Distributed Data Plane, four subsections (What a Probe Cannot
  See / The Engine Announces Itself / One Card Down Is Not One Replica Down / The
  Fleet, as Something You Can Look At). Diagram `pull_vs_push`; pattern
  `pattern:push-membership-pull-datapath`
- Act 5 The Distributed Engine in Production (diagram `distributed_fleet`)
- Act 6 Capability Snapshot, prose stub + close handing to Ch 11
- Problems: 5 problems (`prob:ch10-same-sum`, `ch10-choosing-split`,
  `ch10-probe-gap`, `ch10-blast-radius`, `ch10-pool-budget`)
- `references.tex` has 4 bibitems: `llama33hf`, `nvidiaNvlink`, `vllmParallelism`,
  `awsP5`

## Next

1. Optionally run `ai-tell-sweep` as a second independent pass (the
   `book-style-sweep` pass already covered the mechanical rule library and the
   obvious rhetorical tells, but a fresh reader-pass over Acts 4-6 is cheap).
2. Commit. Branch off main; plain-text GitHub refs per `CLAUDE.md`.
3. When iplane 203/204/205 land and `ch10-final` is cut on `release/v0.2`,
   rewrite Act 6 as a real transcription of the `capabilities.yaml` entry
   (`\item[Name (status).]` form) and re-run `make check-snapshots`.

## Honesty posture (load-bearing)

`--needs-nvlink`/`--needs-rdma`, the reporting channel / push agent, and the fleet
verbs are ROADMAP, not shipped. The chapter names them, marks them roadmap in three
places (end of Act 3, end of Act 4, and Act 6's opening paragraph), and rides the
existing hardware-spec-on-Instance seam. NO iplane internals in prose (no locks,
package layouts, gRPC), NO issue numbers in prose.

iplane tracking (reconciled 2026-08-09): epic 211 plus children 203, 204, 205, 212,
213, 214, 215 on `inference-book/inference-plane`, all `[ch10]` + `multi-gpu`. See
`OUTLINE.md` for the per-ticket mapping and for the Ch 8 baseline correction that
went into 204 (Ch 8 pulls `/health`, it does NOT scrape `/metrics`; that scrape is
listed as deferred in `ch08-final`).

## Decisions made

- **Version: Ch 10 STAYS in v0.2** (matches `CLAUDE.md` + iplane `RELEASE.md`).
  Both iplane-side follow-ups are closed; see `OUTLINE.md`.
- **Ch 12 discrepancy:** `chapter12/index.tex` is a stale placeholder titled
  "Multi-Tenant Architecture" (label `ch:multi-tenant`), but both outlines say
  Ch 12 = "70B Deployment" owning the `--tp`/`--pp` deploy flags. Used a SOFT
  forward reference ("a later chapter", "the later chapter that assembles a
  complete 70B deployment") instead of `\ref` to avoid hard-linking a label that
  will change. Part III numbering needs a reconciliation pass.
- **Ch 11 IS hard-referenced.** ~~as `ch:model-routing`~~ **Superseded 2026-08-12:**
  the label is now `ch:capacity` and the title is "Capacity Across Providers".
  Ch 11 was reframed from routing to hardware acquisition, so both Ch 10 refs
  (lines 147 and 307) were reworded onto the capacity framing. The closing
  paragraph now bridges through this chapter's own cross-node deferral, which is
  Ch 11's opening. The "engines it did not provision" thread Act 4's
  self-registration sets up still lands, just under the new frame.

## Build / verify loop (every increment)

- `make refs` once, then `make ch chapter10` TWICE (citations need two passes).
- **`build.sh` deletes `gen/temp_chapter10.log` on exit**, so grep stdout, not the
  log file. And `build.sh` wraps `pdflatex` in `|| true`, so errors are silent.
  Working incantation (run from the book root):

  ```
  make ch chapter10 > /dev/null 2>&1
  make ch chapter10 > /tmp/b.log 2>&1
  awk '/Output written/{n++} n>=1' /tmp/b.log \
    | grep -iE "^! |LaTeX Error|Undefined|Misplaced|Warning: Citation|Warning: Reference"
  ```

  The `awk` matters: `make ch` runs pdflatex twice internally, and the first pass
  always reports undefined citations and refs. Only the output after the first
  `Output written` line is meaningful.
- **Bash cwd persists between tool calls.** A `cd src/chapters` in an earlier grep
  makes the next `make ch` fail with "No rule to make target `ch'". Prefix build
  commands with `cd <book root> &&`.
- Render pages to verify visually: `pdftoppm -f N -l N -r 130 -png
  gen/chapters/chapter10.pdf <scratchpad>/pg`, then Read the PNG. Diagrams
  compiling is not the same as diagrams correct. Both new diagrams this session
  needed a second pass after looking at them.

## Gotchas learned across this chapter

- `index.tex` MUST end with `\input{chapters/chapter10/references}` or all `\cite`
  render as `[?]`.
- Patterns are named INLINE with `\label{pattern:<slug>}` mid-prose. There is NO
  pattern environment.
- pgfplots `xbar` + `symbolic y coords` silently dropped one bar's tick label; use
  numeric y + `ytick={1,2}` + `yticklabels={...}` + `bar shift=0pt`.
- NO em-dash even inside diagram labels (use commas). NO colon-definitions. NO
  semicolons in prose (global rule; two slipped in and were fixed).
- Avoid the banned "X, Y, and the punchline" rule-of-three and stacked short
  punchy sentences. Both showed up in the Act 4 first draft.
- Bandwidth framing hazard: NVLink is aggregate-bidirectional, PCIe/InfiniBand are
  per-direction. Everything is normalized to BOTH-DIRECTIONS; keep it consistent
  (NVLink 900/1800, PCIe Gen5 ~128, the 7-14x gap).
- Diagram `\input` uses figure `[H]`; safe TikZ style names only (see `CLAUDE.md`).
- In a TikZ table-style figure, a multi-line `align=left` node in a middle column
  will run under the next column unless you set an explicit `text width`.
