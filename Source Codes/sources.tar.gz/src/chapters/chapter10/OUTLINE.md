# Chapter 10: Multi-GPU and Distributed Inference

Working scaffold for the Ch 10 draft. Chapter 8 (`chapter08/index.tex`) is the model
for a control-plane-centric chapter's density, structure, and voice, and Chapter 9 is
the immediate predecessor that hands off the single-GPU ceiling this chapter climbs
over. Same rules as Ch 7/8/9 (the `book-style-sweep`
and `ai-tell-sweep` skills, and the memory entries).

**Vocabulary note (2026-08-10):** the topology filter shipped as `--fabric none|intra-node|inter-node` plus `--min-fabric-gbps`, not as the `--needs-nvlink` / `--needs-rdma` pair this scaffold originally sketched. The flag names a property rather than a vendor technology, for the same reason `--min-vram-gb` beats naming a SKU, and it is rejected without `--gpu-count >= 2` since a fabric is meaningless on one card.

**Drafting status (2026-08-09): the full draft is in `index.tex`.** All six acts plus
the Problems section are written, the chapter builds clean, every page is visually
verified, and the style sweep has been run. 20 pages, ~6.7k words, 7 figures, against
the ~20 page / ~7k word / ~6 diagram target below. `make check-snapshots` passes and
does not flag Ch 10, since Act 6 is prose with no `\item` entries. What remains is a
commit, and then the Act 6 rewrite once `ch10-final` is cut. See `HANDOFF.md` for the
per-act inventory, the working build-and-verify incantation, and the gotchas.

Section-by-section, what shipped against the plan below: Act 4 grew four subsections
(`subsec:probe-blind-spots`, `subsec:engine-registration`, `subsec:distributed-failure`,
`subsec:fleet-verbs`) rather than staying one block, and the pull-versus-push framing
was sharpened. Chapter 8's actual position is that the routing signal is *router-side*
state and scraping the engine's `/metrics` was deferred, while the liveness pull is
Chapter 7's `/health` poller, so Act 4 argues against the **probe**, not against a
metrics scrape. All three planned patterns are named. All six planned diagrams exist,
plus the synthetic throughput panel.

**Framing (2026-07):** Ch 10 swings back to **control-plane-centric**, alternating from
Ch 9's engine/model-centric backbone (memory `project_engine_vs_controlplane_chapter_balance`:
chapters alternate; Ch 9 was engine-first like Ch 5, so Ch 10 is control-plane-first
like Ch 8). Rough split: ~30% concept (the multi-GPU KV domain, taught only far enough
to reason about provisioning), ~60% control-plane (networking-aware provisioning +
fleet tracking), ~10% frame and close. The engine stays the opaque box the book has kept
since Ch 8. Tensor parallelism, pipeline parallelism, and prefill/decode disaggregation
are engine internals iplane provisions *for*, never things the book re-implements.

**Drafting posture (decided 2026-07):** draft ahead of the iplane code with honest
roadmap framing, and file iplane tickets so the real shipped spine lands in a parallel
session (like Ch 9's warm-cache spine did before `ch09-final`). Until that work lands
and a `ch10-final` tag is cut, the Capability Snapshot is a heavier stub than Ch 9's:
it names the intended surface and marks it roadmap.

### iplane surface state (honest, checked 2026-07)

- **Shipped foundation this chapter builds on:**
  - PR 156 put a **hardware spec + metadata map on `Instance`** (GPU SKU / VRAM / region
    exposed by the provisioner without proto churn). Interconnect metadata is the natural
    next field on that same seam, not a new surface.
  - Heterogeneous fleets via `ReplicaSpec.replicas` (Ch 7 Beat 3): one deployment already
    pulls replicas from multiple providers, with the homogeneous case as the degenerate
    one-spec form.
  - Multi-replica fan-out + `DEGRADED` aggregate state (Ch 7 Beat 3): the control plane
    already tracks N *independent* replicas. Ch 10's fleet tracking is the *distributed*
    (multi-node, one-engine) case layered on this.
  - Pull-based `/metrics` scrape (Ch 8): the data path reads a thin direct engine signal;
    correctness does not depend on the obs pipeline. Ch 10 is where **push** joins pull.
  - `--gpu-count N` requirements language (Ch 6) already asks for more than one card; what
    it cannot yet ask for is *how those cards are connected*.
- **Roadmap only (NOT shipped; tickets filed this session, see below):**
  - **Interconnect metadata per SKU + a networking-aware provisioning filter**
    (shipped as `--fabric intra-node|inter-node` plus `--min-fabric-gbps`). Declare the
    topology requirement; the control plane resolves it to matching SKUs. Extends the PR-156
    seam.
  - **Push-based engine agent / control-channel registration.** A distributed engine that
    comes up across nodes registers with the control plane and pushes its state; the control
    plane tracks the fleet from registrations instead of scraping every endpoint. The
    pull-to-push move Ch 8 deliberately deferred.
  - **`iplane fleet status` / `iplane fleet drain`** as the operator view of and graceful
    handle on N tracked data planes.
- **Boundary (NOT this chapter):** the `iplane deploy --tp 4 --pp 2` flags are **Ch 12**
  (ROADMAP v0.3 Ch 12 row). This chapter provisions the connected pool and tracks the
  distributed engine; it does not add the TP/PP deploy knobs, and it never opens the TP group.

### Version / branch note (resolved 2026-07)

**Decision: Ch 10 stays in v0.2.** `book/CLAUDE.md` and iplane `RELEASE.md` (v0.2 = Ch 7--10)
win; the iplane `ROADMAP.md` row placing Ch 10 in v0.3 is the one to correct. Consequences:
track iplane 203/204/205 against v0.2, cut `ch10-final` on `release/v0.2`, and fix the
`ROADMAP.md` Ch 10 row to read v0.2.

Both follow-ups are closed (2026-08-08):
- [x] `ROADMAP.md` Ch 10 row moved v0.3 -> v0.2 in `../inference_plane/`, on branch
  `docs/ch10-moves-to-v0.2`. The row is also rewritten to the control-plane reframe below.
  Two v0.3 entries that existed only to serve Ch 10 moved with it: the networking-aware
  provisioning cross-cutting feature and the control-channel protocol-shape open question.
- [x] Issues 203/204/205 tracked to v0.2. **Not** via a milestone: the iplane repo has never
  used milestones, and its convention is a `[chN]` title prefix plus labels (Ch 9's
  190/191/192 carry `scaling-30b` + `P1` + area labels, no milestone). The three issues were
  retitled `[ch10] ...` and given a new `multi-gpu` chapter label plus `control-plane`,
  `provisioning`/`book-blocker`, and P1/P1/P2.

Still open, and a separate question from the Ch 10 move: iplane `ROADMAP.md` lists Ch 11 under
v0.3 while `RELEASE.md`'s v0.3 range starts at Ch 12, so Ch 11 currently belongs to no release
row. Left untouched pending its own decision.

## Chapter arc (from `master_outline.md` Ch 10 row, 2026-07 reframe)

> Ch 9 closed at the single-GPU ceiling, and this chapter grows a deployment onto several
> cards. The angle is control-plane, not engine-internal. iplane rents an RDMA/NVLink-connected
> pool through networking-aware provisioning (`--fabric intra-node`, `--fabric inter-node` select only
> matching SKUs) and hands it to the engine as one deployment, and the push-based engine agent
> lands here, the control plane tracking N distributed data planes through control-channel
> registration, the move Ch 8 deliberately chose pull over. The multi-GPU KV domain (one
> engine's KV cache sharded across cards, logically one cache, physically many) is taught as a
> concept at the quantization altitude, enough to reason about NVLink/RDMA bandwidth as the
> binding constraint, while the engine stays the opaque box the book has kept since Ch 8.
> Tensor parallelism, pipeline parallelism, and the frontier prefill/decode disaggregation
> runtime are pluggable engine concerns iplane provisions *for*, not internals the book
> re-implements. The `--tp`/`--pp` deploy flags surface in Ch 12.

Model scale: 70B (this chapter) versus Ch 9's 32B single-card anchor. Hardware: a
multi-GPU pool, intra-node (NVLink) or multi-node (RDMA/InfiniBand).

### Boundary with Ch 8, Ch 9, Ch 12 (keep the seams honest)

- **Ch 8 closed** treating every engine as one opaque KV domain and deferred two things to
  here: "one engine's cache spread across several GPUs is Chapter 10," and the push-based
  engine agent / control-channel registration (Ch 8 chose pull deliberately). See the
  processed marker `iplane-inbox/.processed/2026-06-29T21-57-03--ch8-ch10-boundary-engine-opaque.md`.
- **Ch 9 closed** at the single-GPU ceiling (`\S\ref{sec:single-gpu-ceiling}`): two failure
  modes, weights alone do not fit (70B) and weights fit but KV does not scale (32B at long
  context or high batch). Both point at spreading one engine's KV domain across several cards.
  Ch 9 named that move as tensor parallelism and this chapter's lead, and it never opened the
  box. This chapter picks up exactly there.
- **Ch 12 owns** the TP/PP-aware deploy flags (`--tp 4 --pp 2`) and the multi-GPU image
  catalog variants. Ch 10 provisions the pool and tracks the engine; Ch 12 tells the engine
  how to shard across it.

## Target shape

~20 pages at Ch 7/8 density: ~7k words, ~6 TikZ/pgfplots diagrams, real interconnect
bandwidth numbers (NVLink vs PCIe vs InfiniBand/RDMA) and real multi-GPU provider SKU
examples, a Problems section, and a Capability Snapshot (heavy stub for now). The backbone
is the **interconnect-as-binding-constraint** argument, the Ch 10 equivalent of Ch 9's VRAM
budget: concrete and checkable with real bandwidth figures and real throughput-loss numbers
for a TP group on the wrong fabric. Synthetic pgfplots panels stand in for paid multi-GPU
run figures, captioned illustrative until a real run replaces them.

## Section plan

### Act 1 --- Where We Left Off / one card is not enough (~10%)

Ch 9 closed at the single-GPU ceiling. Recap the two failure modes in one tight paragraph
(70B weights past any single card; 32B KV pool drained by context times batch), both pointing
at the same move: give the engine several cards joined by a fast interconnect. Then the framing
that governs the whole chapter. This move does not change what the book does with the engine.
The engine still owns *how* it spreads a model across cards. What changes is what the
**control plane** must now do: it can no longer provision one card, it must provision a *set of
cards that can act as one*, and it must track an engine that may span several nodes. Name the
two control-plane jobs the chapter delivers: provision the connected pool (Act 3), track the
distributed data plane (Act 4). The unit of concern rises from one card back to the fleet,
where Ch 8 left it, but now a single member of that fleet can itself be many cards.

### Act 2 --- The multi-GPU KV domain, as a concept (~20%, engine-concept at quantization altitude)

Teach only what the reader needs to make provisioning decisions. Do NOT derive the all-reduce,
do NOT show TP kernel code. Three ideas:

- **Tensor parallelism.** One layer's matrices are split across cards, so every token's forward
  pass touches every card, and the cards exchange activations on every layer (all-reduce /
  all-gather traffic). High bandwidth, latency-sensitive, wants a fast intra-node link
  (NVLink). This is the common case for making a 70B fit and serve.
- **Pipeline parallelism.** Different layers live on different cards; activations are handed
  card-to-card once per stage boundary. Far lower bandwidth, tolerates a slower link, so it can
  cross nodes over RDMA/InfiniBand. The trade is pipeline-bubble latency.
- **The sharded-but-logical KV cache.** The 70B's weights *and* its KV cache both split across
  the TP group. It is logically one cache the router still treats as one endpoint (Ch 8
  discipline intact) and physically many cards.

The payoff line, the one the rest of the chapter rests on: **once a model spans cards, the
interconnect between them becomes the binding constraint, not per-card VRAM.** A TP group on
PCIe instead of NVLink loses a large fraction of its throughput to communication that never
appears on a VRAM budget. Cite real bandwidth numbers (NVLink vs PCIe Gen5 vs InfiniBand) and
a real throughput-loss figure for a TP group on the wrong fabric. This is the "why provisioning
must be topology-aware" setup, not the payoff; keep it at concept altitude.

Diagrams: (1) TP vs PP data-flow --- same model, TP splits within a layer with all-layer
exchange, PP splits across layers with hand-off at boundaries, annotated with which link each
wants. (2) the sharded KV domain --- one logical cache, one endpoint the router sees, physically
spread across four cards.

### Act 3 --- Networking-aware provisioning (control-plane, the lead, ~25%)

The first control-plane job. On one card, provisioning matched a VRAM number to a SKU (Ch 6/9).
At model scale across cards, matching the VRAM *sum* is not enough: two 80 GB cards in different
nodes over PCIe will not run a TP-4 70B at speed even though 160 GB clears the weights. So
provisioning must select for the *interconnect*, not just the VRAM total.

- **The manual path (real pain, and it is real here).** You read each provider's SKU page trying
  to work out which multi-GPU instances actually have NVLink between the cards versus which just
  bolt N cards onto one PCIe root; providers describe this inconsistently or not at all. You
  guess, you deploy, and you learn from throughput whether you got a connected pool or a slow
  one. You cannot tell the good SKU from the bad one before you pay for it.
- **The iplane move.** `--fabric intra-node` / `--fabric inter-node` (plus `--min-fabric-gbps`)
  filter the provider catalog to only SKUs whose cards are connected the way a TP or PP group
  needs. Declare-intent-resolver-joins, the same shape as `--min-vram-gb`: you declare the
  topology requirement, the control plane resolves it against per-SKU interconnect metadata. This
  extends the shipped PR-156 hardware-spec-on-`Instance` seam with one more field, not a new
  surface. The control plane owns "find a connected pool"; the engine owns "shard across it."
- **Honesty.** SHIPPED as of 2026-08 (was roadmap when drafted; no `--fabric` code
  exists; ticket filed this session). Frame per book convention: teach the concept, name the
  shipped-vs-roadmap boundary, and point at the shipped seam it builds on.

Diagram: two candidate SKUs with identical VRAM sums, one NVLink-connected and one PCIe-split,
the provisioning filter selecting the first; a synthetic throughput panel showing the same TP-4
70B on each, captioned illustrative.

### Act 4 --- Tracking N distributed data planes: pull to push (control-plane, ~25%)

The second control-plane job, and the pull-versus-push move Ch 8 deferred. Ch 8 satisfied its
routing needs by *pulling* the engine's `/metrics`, and it chose pull deliberately: the data
path's correctness must not depend on the obs pipeline being up, and pull was enough when the
control plane provisioned every engine and knew each endpoint. Two things at model scale strain
that. A distributed engine comes up *across nodes*, and something has to tell the control plane
the pool exists and which nodes it spans. And scraping grows with the fleet.

- **The move.** A push-based engine agent (a sidecar or the engine itself) registers with the
  control plane over a control channel and pushes its state: health, in-flight, KV utilization,
  the set of nodes it spans. The control plane tracks the fleet from these registrations rather
  than discovering and scraping every endpoint. Pull does not go away for the data-path signal
  Ch 8 relies on; push is added for fleet membership and liveness.
- **Why now and not Ch 8.** Self-registration is how a pool that spans nodes announces itself.
  Single-endpoint engines did not need it; distributed engines do.
- **Fault tolerance folds in here.** A TP group that loses one card loses the *whole engine*,
  unlike N independent replicas where one dying just degrades the deployment to `DEGRADED`
  (Ch 7). So tracking a distributed data plane is a different problem than tracking replicas:
  the control plane must distinguish "a replica degraded" from "a distributed engine lost a card
  and the whole group is down," and a partial-interconnect failure (one link down) can degrade
  throughput without killing the engine, a new observable the fleet view has to surface.
- **The operator surface.** `iplane fleet status` (the view of N tracked data planes, including
  which are single-card and which span nodes) and `iplane fleet drain` (graceful removal). Both
  roadmap, tickets filed this session.

Diagram: pull (Ch 8, control plane scrapes each endpoint it provisioned) versus push (Ch 10,
distributed engines register and stream state up a control channel), with the fleet-status view
as the operator-facing result.

### Act 5 --- The distributed engine in production (~10%)

Tie the two jobs together on one concrete 70B deployment. Provision a TP-4 NVLink pool
(Act 3), the engine shards the 70B across it and comes up as one endpoint the Ch 8 router still
treats as a single KV domain, the engine agent registers it (Act 4), and `iplane fleet status`
shows it as one distributed data plane spanning four cards. Show the router's view is unchanged:
it still routes to an engine, not a GPU, exactly as Ch 8 promised. This is where the chapter's
two control-plane jobs and the Ch 8 routing discipline visibly compose. Keep it short; it is the
"it all fits together" beat, not new machinery.

### Act 6 --- Capability Snapshot (heavy stub) + close

Transcribes the `ch10-final` `capabilities.yaml` entry once the tag is cut. Until then, a heavier
stub than Ch 9's: name the intended surface (interconnect metadata + networking-aware
provisioning filter, push-based engine agent / control-channel registration, `iplane fleet
status` / `fleet drain`) and mark it roadmap, with the shipped PR-156 seam as the foundation.
Keep as **prose**, not `\item` entries (so `make check-snapshots` does not flag them): the
multi-GPU KV domain taught as a concept, TP/PP/PD-disaggregation as engine internals, and the
`--tp`/`--pp` deploy flags deferred to Ch 12. Author the YAML at tag time with `date: TBD` per
`book/CLAUDE.md`. Close by handing off to Ch 11 (routing across heterogeneous backends,
including engines the control plane did not provision).

## Patterns to name (with `\label{pattern:<slug>}` at first naming)

- **Across cards, the interconnect is the binding constraint, not VRAM.** On one card the budget
  is memory (Ch 9). Span a model across cards and the fabric between them decides throughput; a
  VRAM sum that clears the weights can still be the wrong pool. This is the fact that makes
  provisioning topology-aware.
- **Provision the connected pool; the engine shards across it.** The control plane finds a set of
  cards that can act as one (topology-aware SKU match); the engine owns how it spreads weights
  and KV over them. The multi-GPU echo of Ch 9's "placement is control-plane, tuning is engine."
- **Push for membership, pull for the data-path signal.** A distributed engine registers itself so
  the control plane knows the pool exists and spans nodes; the routing-decision signal the data
  path depends on stays a pull (Ch 8), so data-path correctness never rides on the obs pipeline.

## Diagrams planned (~6, matching Ch 7/8 density)

1. `diagram_tp_vs_pp` --- TP splits within a layer (all-layer exchange, wants NVLink) vs PP splits
   across layers (hand-off at boundaries, tolerates RDMA).
2. `diagram_sharded_kv_domain` --- one logical KV cache / one endpoint, physically across four cards.
3. `diagram_interconnect_ladder` --- bandwidth ladder: NVLink vs PCIe Gen5 vs InfiniBand/RDMA, with
   the throughput-loss cost of a TP group on the wrong fabric.
4. `diagram_topology_aware_placement` --- two SKUs, equal VRAM sum, NVLink vs PCIe-split; the filter
   picks the connected one.
5. `diagram_pull_vs_push` --- Ch 8 scrape model vs Ch 10 self-registration / control-channel push.
6. `diagram_distributed_fleet` --- `iplane fleet status` view: single-card engines and a multi-node
   distributed engine side by side, one link down showing degraded-not-dead.
   Plus a synthetic pgfplots panel: TP-4 70B throughput on NVLink vs PCIe, captioned illustrative.

## Sources to cite (fill from research fact-sheet)

- One 70B anchor model HF card (Llama 3.3 70B or current equivalent) for weight sizes at FP16 /
  INT4, tying back to Ch 9's single-GPU ceiling numbers.
- NVIDIA interconnect specs: NVLink / NVSwitch per-GPU bandwidth by generation (Hopper, Blackwell),
  PCIe Gen5 bandwidth, InfiniBand / RDMA (NDR) bandwidth. Real numbers, dated.
- Published TP-scaling / communication-overhead figures: throughput of a TP group on NVLink vs
  PCIe (vLLM or NVIDIA multi-GPU serving benchmarks), pipeline-bubble cost for PP.
- Multi-GPU provider SKU examples: which cloud instances expose NVLink/NVSwitch vs PCIe-only
  multi-GPU, and how inconsistently they document it (the manual-path pain in Act 3).
- vLLM distributed-inference docs: `--tensor-parallel-size`, `--pipeline-parallel-size`, and the
  intra-node-NVLink / multi-node-Ray guidance (cited as engine behavior, deferred as a deploy flag
  to Ch 12).
- Ch 8 (`ch:caching`) for the opaque-KV-domain and pull-based-metrics boundary; Ch 9
  (`\S\ref{sec:single-gpu-ceiling}`) for the ceiling this chapter climbs over; Ch 3
  (`ch:hardware-fundamentals`) for interconnect basics already in the book.

## Parallel iplane work (tickets reconciled against the finished draft, 2026-08-09)

To give this chapter a real shipped spine before `ch10-final` (like Ch 9's warm cache), the
control-plane surface is tracked on `inference-book/inference-plane` under an epic plus six
children, all carrying the `[ch10]` title prefix and the `multi-gpu` label (this repo does not
use milestones; the prefix-plus-label convention matches Ch 9's `scaling-30b`).

- iplane issue 211 --- `[epic]` the whole Ch 10 surface, attack order, and the baseline
  correction below.
- **Job 1, provision the pool.** 203 (interconnect metadata per SKU + the `--fabric` /
  `--min-fabric-gbps` filter, extending the hardware-spec-on-`Instance` seam; Act 3 spine) and
  212 (multi-node pool as one deployment member, which is what makes the fleet view's *span*
  non-degenerate).
- **Job 2, track the data plane.** 204 (push-based engine agent / control-channel registration;
  Act 4 spine), 213 (NVLink/NVSwitch link-state telemetry, the sensor behind the
  degraded-not-dead state), 205 (`iplane fleet status` / `fleet drain`; depends on 204), and
  214 (record which node failed so a replacement pool avoids the bad host).
- **Demo and book.** 215 (walkthrough plus book figures, including the paid NVLink-vs-PCIe A/B
  that would replace the chapter's synthetic throughput panel and its weakest number).

**Baseline correction carried into 204 and the epic.** The original 204 said Ch 8 satisfied its
routing needs by *pulling the engine's `/metrics`*. That is wrong, and the chapter does not say
it. `ch08-final`'s snapshot lists that scrape under **Deferred**; what ships is Ch 7's `/health`
poller plus Ch 8's router-side in-flight counts and hit-rate. So Act 4 argues against the
**probe**, not against a metrics scrape, and the tickets now say so. Related: iplane
`ROADMAP.md`'s Ch 8 row claims the scrape is "now scraped", contradicting the tag snapshot.
Flagged in the epic, not yet resolved, and it needs someone with the commit history.

Two adjacent tickets are cross-linked so the same work is not built twice: 145 (scale-down drain
semantics) is the drain machinery 205 needs, and 189 (engine-signal backchannel for cache-aware
routing) wants 204's transport with a different payload on a much tighter freshness budget.

As each lands, move the matching row of the "iplane surface state" section from roadmap to
shipped, and let the Capability Snapshot firm up.
