# Chapter 8: Stateful Routing and Prefix-Cache Reuse

Working scaffold built from drained `iplane-inbox/` markers targeting `chapter08`. The chapter prose drafts against this outline in 200--500 word increments when drafting time comes; same rules as Ch 7's scaffold (see `feedback_no_iplane_internals_in_prose`, `feedback_no_chat_voice_in_prose`, and the `book-style-sweep` skill).

**Status (2026-07-02):** the backing iplane code is complete. The stateful-routing and prefix-affinity arc landed end to end --- session driver, affinity policy, router-side hit-rate proxy, load-aware override, header-less body-derived key, and the GPU-free walkthrough --- so the chapter drafts against stable commands, flags, config keys, and metric names. What remains is not code. One small paid multi-replica GPU run captures the hit-rate and latency figures (checklist in `examples/07-prefix-affinity/README.md`), and the prose itself is still to be written. Explicitly outside Ch 8: the hosted-API-as-backend provider (Chapter~11), engine-side `gpu_prefix_cache_hit_rate` scraping (deferred), and demo-fidelity driver features such as true asymmetric whale load and context pruning.

## Working title and arc

(from `master_outline.md`)

The router gains real state. Chapter~\ref{ch:routing-queueing} fanned a model out to N replicas behind round-robin, which spreads load evenly and in doing so scatters a multi-turn conversation across every replica --- turn 2 lands on an engine that never saw turn 1 and re-prefills the whole history from cold. The Chapter~\ref{ch:routing-queueing} load balancer and the Chapter~\ref{ch:inference-engines} engine cache work against each other. This chapter resolves that tension with cache-aware routing, a prefix-affinity policy that keeps a conversation on the replica whose prefix is already warm. Engine-side prefix caching --- RadixAttention, vLLM's automatic prefix caching --- is the substrate the policy exploits, not the headline. Cache memory pressure, fairness against a hot replica, and hit-rate measurement are the trade-offs the affinity decision has to manage.

"Sticky routing" is the in-body synonym; the load-balancer analogy is sticky sessions, but driven by cache locality rather than a session cookie. The chapter's repeatable framing is that the router picks an engine, not a GPU --- the engine is the cache boundary, and what happens inside one engine's KV domain is Chapter~10 (Multi-GPU and Distributed Inference)'s subject.

Working model: same 8B class Ch 7 anchored on. Model-size scaling is Ch 9's lead.

## Stable facts (concept-level)

The conceptual invariants the prose must respect from sentence one. Each entry cites its absorbed marker as the audit trail; mechanism details stay in iplane's repo.

### Round-robin defeats the prefix cache; cache-aware routing is the fix

*Absorbed from `2026-06-29T21-57-01--ch8-reframe-prefix-affinity-spine.md` (planning marker, commit `cb2c910`).*

Prefix caching only pays off across replicas if the router cooperates. A single engine that caches a conversation's growing prefix is a Chapter~\ref{ch:inference-engines} fact. The moment a deployment has N replicas behind round-robin, that fact stops holding at the deployment level: round-robin sends each turn to a different engine, so the cache hit-rate across the fleet collapses toward 1/N and time-to-first-token climbs with conversation length. The reader can feel this with the Grafana panels they already built in Chapter~\ref{ch:routing-queueing}.

Cache locality is therefore a routing concern, not an engine-only concern. The chapter's spine is the affinity policy that puts a conversation back together, and the three threads it runs on: the affinity decision itself, load-aware tie-breaking so affinity doesn't pin past a hot replica's capacity, and the hit-rate observability that lets the reader watch round-robin and affinity side by side.

An operator could approximate this by hand --- pin sessions to backends with a consistent-hash directive in nginx keyed on the first tokens of the request body --- but that requires the proxy to parse and hash request bodies, real engineering for a load balancer that was never meant to read application state. The principle the chapter teaches is that *routing decisions should respect cache locality*; cache-aware routing is the shape that principle takes when the router already sits in the data path.

### The router picks an engine, not a GPU; the engine is the cache boundary

*Absorbed from `2026-06-29T21-57-02--router-routes-to-engines-kv-domains.md` (planning marker, commit `cb2c910`).*

The chapter needs one line it can repeat: the router picks an engine, not a GPU. A *KV domain* is the set of GPUs --- one card, or several joined by a memory domain over NVLink or a fast interconnect --- that together hold one KV cache. An *engine* is the process (vLLM, SGLang) that drives one KV domain, manages the GPUs inside it, and presents a single endpoint to whoever calls it. So engine, KV domain, and the replica that backs a deployment are the same object viewed three ways: the replica is the deployment's slot, the engine is the process that fills it, and the KV domain is the memory the engine owns. The router's unit of selection is that engine, and the engine is the cache boundary. This is what makes affinity meaningful at all: there is exactly one place a conversation's prefix can be warm, and routing's job is to keep sending the conversation there.

The line does double duty. It explains why affinity is a routing decision (the engine, not the GPU, is where the cache lives), and it sets the boundary with Chapter~10 (Multi-GPU and Distributed Inference): what happens *inside* one engine's KV domain --- the cache sharded across cards by tensor parallelism --- is deferred to that chapter. Here each engine stays one opaque endpoint, one KV domain, and the chapter never asks the reader to reason about the GPUs inside it. The engine already acts as a small cluster manager over its own cards; that internal management is exactly what lets iplane treat the whole thing as one opaque endpoint and route *across* engines without looking *within* one.

The boundary has a data-path corollary. Ch 8 gets the engine state its routing decisions need by *pulling* the engine's existing metrics on the routing path; it does not put a push-based agent on the pod. A long-lived engine agent that registers back over a control channel is Chapter~10's move, where the control plane starts tracking N data planes directly. Pull is enough for affinity, and it keeps the data path's correctness from depending on an agent being up.

Affinity is a property of the *traffic*, not of the deployment or the engine. A conversation carries its own identity, and that identity is a request-level hint --- the same shape as the tenant and priority hints Chapter~\ref{ch:routing-queueing} introduced. So a whole routing capability lands as one header plus one policy, with no new field on the deployment and no engine change. That is the chapter's concrete instance of the control plane staying thin: routing and queueing policy rides the request, it never accretes onto the runtime artifacts.

### Routing pulls a thin engine signal; it does not run a push agent

*Absorbed from `2026-06-29T21-57-04--engine-metrics-pull-not-push-otel-transform.md` (planning marker, commit `cb2c910`).*

A teaching beat in its own right, the same architectural-truth-telling energy as Chapter~\ref{ch:control-plane-v01}'s deliberately two-panel dashboard. When the router wants to break an affinity tie by load --- which of two warm replicas is less saturated --- the eager design is an agent on each engine pushing its internals to the router. The chapter shows that design and explains why it is resisted. Two reasons. The affinity *decision* needs no engine data at all: the router predicts which replica holds a prefix from its own routing history, it never asks the engine. And the load signal it does want is already sitting on the engine's existing metrics endpoint, so the router *pulls* it rather than standing up a pushing agent.

The distinction that earns its place is two consumers of engine metrics with different latency budgets. Routing decisions read a thin, direct signal on the request hot path, so the data path's correctness never depends on the observability pipeline being up. Hit-rate panels and the rest of the dashboard route through the telemetry pipeline the operator already wired in Chapter~\ref{ch:control-plane-v01}, where a few seconds of lag costs nothing. Normalizing one engine's metric names against another's --- when a second engine shows up speaking a different vocabulary --- is a config-side transform inside that pipeline, not code iplane carries for every engine it might meet. That keeps the pluggable-engine principle intact and the control plane out of the business of memorizing every engine's metric surface. A long-lived push agent registering back over a control channel is Chapter~10's move, not this chapter's.

### The money panel is a router-side affinity hit-rate, honest about being a proxy

*Absorbed from `2026-07-02T14-07-10--shipped-affinity-hit-rate-metric.md` (iplane PR 184).*

The chapter's central panel is a hit-rate, and it pays to be precise about which one. The router measures an affinity hit-rate from its own routing decisions. For each request that carries a session identity, it checks whether the replica it just chose is the one that session last landed on, and counts a hit when they match. Round-robin scatters a session's turns, so this rate sits near 1/N. Affinity pins them, so it climbs toward 1.0. That contrast is the panel that motivates the whole chapter.

What the router measures is routing locality, not the engine's cache. The engine's own prefix-cache hit-rate is the ground truth the reader ultimately cares about, and iplane does not read it in v0.2 because scraping the engine is deferred. The router-side number is a faithful proxy. The two track each other, since a session kept on one replica is a prefix the engine finds warm, and they part ways exactly where the cache runs out of room. That divergence is not a flaw in the panel. It is the memory-pressure story the final act tells. Naming the panel a proxy out loud is the same honesty as Chapter~\ref{ch:control-plane-v01}'s deliberately two-panel dashboard.

Because the affinity signal is about what the router decided rather than what the GPU did, the routing contrast reproduces without renting a GPU. The shipped walkthrough does exactly that, reporting where each session lands on a mock engine. The hit-rate and latency figures the chapter prints sit one step downstream, since they depend on a real KV cache, so they come from one small paid run while the routing behavior reproduces for free.

### Request-header family (shared with Chapter~\ref{ch:routing-queueing})

The session-affinity hint joins the header family Chapter~\ref{ch:routing-queueing} started. All three are request-level traffic properties the router reads, never deployment fields:

- session identity (Ch 8) --- which conversation this request belongs to, so affinity can keep it on one engine.
- tenant (Ch 7) --- which tenant's fair-share lane the request enters.
- priority (Ch 7) --- which priority lane within the tenant.

The teaching point is the symmetry --- each is a property of the traffic, resolved per request, and none of them lives on the `Deployment`. Affinity is the third member, not a new kind of thing.

Session identity has one wrinkle the others do not. Tenant and priority are always asserted by the caller, but a plain OpenAI SDK pointed at the flat endpoint sends no session header at all, and the reader will rightly ask whether affinity works for real clients or only for a driver that cooperates. It works for both. When the header is present the router uses it, and when it is absent the router derives a stable key from the conversation's opening, so a header-less multi-turn chat still pins. The order is explicit header first, derived key second, nothing third. The explicit header is the higher-fidelity signal, since a derived key is a coarse proxy that cannot tell apart two conversations sharing a system prompt, and co-locating those is a deferred refinement.

### Prefix-cache affinity is a routing policy that plugs into Chapter~\ref{ch:routing-queueing}'s seam

*Absorbed from `2026-06-03T10-04-00--routing-policy-seam-for-ch8.md` (iplane PR 148, the interface-only half).*

Chapter~\ref{ch:routing-queueing} picked round-robin as the v0.2 replica-selection default because it required no per-replica state on the router. The principle "the router is in the data path doing replica selection" landed without dragging in cache-state knowledge or persistence. This chapter is what happens when per-replica state --- cache contents --- starts mattering.

The iplane mechanic this chapter introduces is a new routing-policy implementation. Chapter~\ref{ch:routing-queueing} (iplane PR 148) landed the policy seam itself --- the router's per-request replica selection goes through an interface; round-robin is the v0.2 default impl. This chapter's contribution is a prefix-cache-affinity policy that satisfies the same interface, written as one focused piece of code rather than as a router refactor. The router, the deployment registry, the health-check loop, and the metrics all stay unchanged.

This is the chapter's bridge to Chapter~\ref{ch:routing-queueing}. Round-robin is the right v0.2 default; prefix-cache-affinity is what swaps in when ``route to the replica that already has the right cache'' beats ``spread load evenly.''

An operator could prototype prefix-affinity in nginx with a `consistent_hash` directive keyed on the first N tokens of the request body. Possible, but requires nginx to parse the request body --- a Lua module, real engineering effort. The iplane seam lets the policy land with proportional effort. The principle the chapter teaches is *cache locality matters and routing decisions should respect it*; the seam is what makes that principle expressible without a router refactor.

## Act structure

Mirrors `../inference_plane/ROADMAP.md` § *Ch 8 four-act sketch*. Concept-level; the iplane build order stays in the repo.

- **Act 1 --- The workload shifts from requests to conversations.** Ch 7 left one deployment, N replicas, round-robin, and single-shot requests handled fine. Real chat and agentic traffic is multi-turn, every turn resending a prefix that grows. A session-aware workload is the lens, and the question it raises is whether it matters *which* replica answers turn 2.
- **Act 2 --- The manual path, and it hurts.** The reader runs the session workload against the round-robin deployment they already have. The Grafana hit-rate sits near 1/N, TTFT climbs with conversation length, GPUs spend most of their prefill compute redundantly. The diagnosis is that round-robin scatters one conversation's turns across all N replicas, each re-prefilling the whole history from cold. The Ch 7 load balancer and the Ch 5 engine cache are fighting each other, and the reader feels it with the tools they already built.
- **Act 3 --- Cache-aware routing puts the conversation back together.** Prefix-affinity routing keys on a session identity and sends a conversation's turns to the replica that holds its prefix. The router predicts cache residency from its own routing history rather than asking the engine. The toggle is a property of the router, not of any single request. Run `iplane serve --routing-policy prefix_affinity` instead of the default `round_robin`, re-run the identical workload, and watch hit-rate climb toward 1.0 while TTFT flattens. Affinity works because each turn carries its session identity as a request header. A new session places round-robin and then pins, and a pin survives a replica being quarantined or scaled away by transparently re-placing. Two refinements close the act: load-aware tie-breaking, reusing Ch 7's in-flight signal so a hot session doesn't pin past a replica's capacity, and a longest-shared-prefix variant for shared system prompts across distinct sessions. The move stays small --- one routing policy plus one request-level hint, no engine change.
- **Act 4 --- Affinity is not free.** Pure stickiness lets a whale session monopolize its replica, in tension with the per-tenant fair-share Ch 7 enforced. The resolution is a load-aware override, off by default so the chapter can show the saturation problem before flipping the safety valve on. Once a session's pinned replica passes an in-flight threshold, the router spills that turn to the coolest replica but keeps the pin. The detour is temporary, and the session snaps back to its warm replica once load subsides. The spill shows up on the panels the reader already has, because routing a turn off its pinned replica registers as an affinity miss, so the hit-rate dips under overload while per-replica in-flight stays bounded. Cache memory is the second cost --- pack too many concurrent sessions onto one replica and their KV blocks evict each other, shown by raising the session count rather than buying a bigger GPU. Front-pruning a long conversation silently invalidates its cached prefix. The chapter names what it defers: KV memory budgets at 30B (Ch 9) and the engine's multi-GPU KV domain via tensor parallelism (Ch 10). Here the engine stays one opaque endpoint.

## Hands-on: the session driver and the demo trilogy

*Absorbed from `2026-06-29T21-57-05--session-chat-driver-and-demo-07-trilogy.md` (planning marker) and `2026-07-01T23-50-01--shipped-session-load-driver.md` (iplane PR 177, shipped surface).*

The chapter's instrument is a session-mode load driver, and it is a different shape from the open-loop firehose Chapter~\ref{ch:routing-queueing} used. That one was stateless and open-loop: fire requests on a ticker, each a single message with a random prompt, never waiting for a reply. Chapter 8 needs the opposite. Each session is a running conversation that holds its own history, and the loop is closed --- build the next turn from the history so far, send it, wait for the real response, append it, pause to think, repeat. Closed-loop is the part that matters. A real conversation cannot send turn N+1 before turn N comes back, and that constraint is exactly what produces long-lived overlapping sessions whose turns are spread out in time. Without that overlap there is nothing for locality to exploit. Each turn carries the session identity hint, and each conversation's prompt grows turn over turn the way real chat traffic does.

In this book the instrument is `iplane load session`, a sibling of the open-loop `iplane load` from Chapter~\ref{ch:routing-queueing}. You could write the same thing yourself --- a script that opens some number of concurrent conversations, each looping build-turn, send, await, append --- and the lesson would be identical. The reason to reach for `iplane load session` is that it already stamps every request with the session identity the router keys on and reports the latency and hit-rate stats the demo reads back. Two of its knobs carry the teaching. The concurrent-conversation count is the dial the reader turns to find the point where a replica's cache can no longer hold every active conversation, and the turns-per-conversation count is what grows the reusable prefix. The shipped driver synthesizes conversation content deterministically, and replaying a real multi-turn corpus is left to the walkthrough.

The driver is the chapter's single instrument, and the hands-on section runs it as the three-act walkthrough shipped with the chapter. The first two acts change exactly one thing, the routing policy, and the third turns on the safety valve.

- **07a, round-robin scatters.** Run the session workload against the round-robin deployment from Chapter~\ref{ch:routing-queueing}. The walkthrough reports where each session's turns land, and they scatter across every engine. That scatter is round-robin shredding the cache, and adding replicas only spreads a conversation thinner.
- **07b, affinity pins.** Restart the router under `--routing-policy prefix_affinity`, re-run the identical driver, and each session's turns collapse onto one engine. One honesty note the prose owes the reader is how the router knows which conversation a request belongs to. An iplane-aware client asserts it with a session header, and a plain OpenAI SDK that sends no header gets a session key the router infers from the conversation's opening, so affinity works on both paths and only the key's origin differs. The explicit header stays the highest-fidelity option.
- **07c, saturation sheds load.** Turn the load-aware override on and drive enough traffic to saturate a pinned engine. The router spills the overflow to the coolest replica and the scatter climbs part way back, the safety valve trading locality for headroom. What the demo drives is uniform saturation rather than one outsized session, so the prose should name the true whale as the motivating case and saturation-spill as the thing the reader actually watches.

Two measurements live at different altitudes, and keeping them apart is what makes the chapter honest. The walkthrough runs GPU-free on the mock engine and reports *routing*, which engine each session lands on, so the reader can watch scatter collapse under affinity and climb back under saturation in seconds and for nothing. The chapter's money figures are the affinity hit-rate and the time-to-first-token curves diverging between the two policies, and those need a real KV cache, so they come from one small paid run on a few cheap GPUs. The effect is driven by conversation length rather than model size, so the run stays small and cheap. The reader reproduces the behavior for free and trusts the figures because they came from real engines.

The "try it yourself" prompts double as the working-set lesson. Turn the session count up until affinity's advantage narrows, because the replica's cache can no longer hold every active conversation at once. That is where the reader feels the when-to-add-a-replica-versus-buy-more-KV-memory question without the chapter having to lecture it.

## Pattern callouts

The chapter introduces and names (filled as markers drain):

- *Design ahead of need only when the need is clearly visible* --- the routing-policy seam was added in Chapter~\ref{ch:routing-queueing} because this chapter's needs were already on the roadmap. Speculative seams add complexity for hypothetical futures; named-future seams pay back immediately.
- *Routing decisions should respect cache locality* --- the chapter's load-bearing principle. A stateless load balancer optimizes for even spread; once the backends hold warm state, even spread is the wrong objective and the router has to become stateful to do better.

## Absorbed markers

- [x] 2026-06-03T10-04-00--routing-policy-seam-for-ch8.md
- [x] 2026-06-29T21-57-01--ch8-reframe-prefix-affinity-spine.md
- [x] 2026-06-29T21-57-02--router-routes-to-engines-kv-domains.md
- [x] 2026-06-29T21-57-03--ch8-ch10-boundary-engine-opaque.md
- [x] 2026-06-29T21-57-04--engine-metrics-pull-not-push-otel-transform.md
- [x] 2026-06-29T21-57-05--session-chat-driver-and-demo-07-trilogy.md
- [x] 2026-07-01T23-50-01--shipped-session-load-driver.md (iplane PR 177)
- [x] 2026-07-01T23-50-02--shipped-prefix-affinity-policy.md (iplane PR 178)
- [x] 2026-07-02T14-07-10--shipped-affinity-hit-rate-metric.md (iplane PR 184)
- [x] 2026-07-02T14-07-11--shipped-load-aware-override.md (iplane PR 185)
- [x] 2026-07-02T14-07-12--shipped-header-less-body-derived-key.md (iplane PR 186)
- [x] 2026-07-02T14-07-13--shipped-affinity-walkthrough.md (iplane PR 188)
- [x] 2026-07-02T14-07-14--ch8-complete-arc.md (epic #176 closed)
