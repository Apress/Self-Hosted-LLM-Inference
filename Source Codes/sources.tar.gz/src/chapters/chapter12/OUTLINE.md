# Chapter 12: 70B Deployment

Working scaffold for the Ch 12 draft, written alongside Ch 11's 2026-08 reframe so the pair is
coherent. Same rules as Ch 7/8/9/10/11 (the `book-style-sweep` skill, now the sole voice
authority, and the memory entries).

**Anchor changed 2026-08-17: Qwen2.5-72B, not Llama 3.3 70B.** The paid run used
`Qwen/Qwen2.5-72B-Instruct`, since the Llama repo is gated and the run had no token. Re-anchoring
was the better call anyway: it matches the pinned `\modelfamily`, matches Ch 9's Qwen2.5-32B anchor,
matches the 72B that Ch 10 and Ch 11 already reference, and is ungated so any reader can reproduce
the listings without an account.

One consequence to keep in view. Qwen2.5-72B's published context window is 32,768, exactly the
figure Act 1 requires, so the requirement asks for everything the model has and the loop can only
trade downward. The author's call was to accept that and make it the finding rather than lower the
requirement to create artificial headroom.

**A larger capstone model was considered and rejected** on 2026-08-17. Anything above this class is
Ch 16's, which argues the ceiling economically rather than reproducing it, and the chapter title and
`master_outline.md` both say 70B.

**Drafting status (2026-08-17): drafted end to end, two holes by design.** 4,743 words, 17 pages,
five sections plus Problems, three real captures, five problems, all three patterns anchored. Full
book build is clean at zero undefined refs and zero undefined citations.

The two holes are the ones that cannot be filled from a desk.

1. **Act 4 has its method and no measurements.** The paid run has not happened. Its
   `% TODO(friction)` lists exactly what to capture and says to take it from the per-instance join
   rather than the catalog gauge. Everything around the numbers (how spend is measured, what a
   few-hour run cannot tell you about a month, the duty-cycle inversion) is finished prose.
2. **The Capability Snapshot is a stub**, and stays one until `ch12-final` is cut as `v0.3.1`,
   since it transcribes a `capabilities.yaml` entry that does not exist before the tag.

**Two diagrams, and why not three.** Figure `fig:budget-terms` stacks the four claims across the
three plans against what the card holds, which makes the cache-then-weights inversion visible in one
picture. Figure `fig:duty-cycle` prices the pool against the hosted endpoint across every duty cycle
and shows the two lines never meeting. A third, a cycle diagram of the loop itself, was considered
and dropped: the prose already walks that loop linearly and a picture of it would restate rather than
clarify, which is the line `CLAUDE.md` draws for diagrams. Reconsider only if Act 2's opening turns
out to need a visual anchor.

Four `% TODO(friction)` markers total, all pending either the paid run or a capture. Two more are
enrichments rather than gaps: the dated cross-provider search that would enrich §12.2's three
closing moves, and re-capturing the three budget listings against the gated `meta-llama` repo once
`HF_TOKEN` is available (the current captures use an identical-config mirror).

The chapter lives in `src/chapters/chapter12/`, where `index.tex` carries the title,
`\label{ch:70b-deployment}`, both abstracts and `\section{The Requirement, Stated Properly}`. The
tree was renumbered onto the 16-chapter outline on 2026-08-16, so directory numbers and chapter
numbers now agree.

## Version note

**Ch 12 is v0.3, with Ch 11**, per the corrected `RELEASE.md` range (`inference-plane` PR 218).
It closes Part III on `ch12-final`, cut from `release/v0.3`. Ch 11 opens that line.

## What this chapter is (and the trap it has to avoid)

Ch 12 is the **capstone of Part III**: one real 70B deployment that spends everything Ch 10 and
Ch 11 built. The integration is the content. There is no new primitive here, and that is the
point.

**The trap is that a capstone chapter has no argument.** "Putting Part III together" is a table of
contents, not a chapter, and integration chapters fail by becoming a long configuration walkthrough
the reader skims. Ch 12 needs a spine of its own, and the honest one is this: *every choice the
earlier chapters taught in isolation now interacts, and the interactions are where deployments
actually break.*

Concretely, the earlier chapters each optimised one variable while holding the others still:

- Ch 9 sized a model against one card's memory, assuming the card was available.
- Ch 10 acquired a connected pool, assuming a vendor had one.
- Ch 11 found capacity across vendors, assuming you knew what pool you needed.

Put them together for a 70B and the assumptions collide. The quantization choice changes how many
cards you need, which changes which topologies qualify, which changes which vendors can supply it,
which changes the price, which may change the quantization choice. That loop is the chapter.

## Chapter arc (from `master_outline.md` Ch 12 row, 2026-08)

> Putting Part III together. A complete 70B deployment on the v0.3 control plane, using Ch 10's
> topology matching and Ch 11's cross-provider capacity search against a real budget and real
> scarcity. The capstone is the integration, not a new primitive.

## Boundaries

- **No new control-plane surface.** If Ch 12 needs a primitive that does not exist, it belongs in
  Ch 10 or Ch 11 and should be moved there. A capstone that invents machinery is a sign an earlier
  chapter was under-scoped.
- **The engine stays opaque**, as it has since Ch 8. Ch 12 hands a 70B to an engine on a pool it
  provisioned; it does not tune the sharding.
- **Ch 13 owns** production operations: runbooks, SLOs, incident response, autoscaling. Ch 12 gets
  the deployment standing up correctly and hands the keeping-it-running story forward. This seam
  needs watching, because "deploy a 70B properly" drifts into "operate a 70B" very naturally.
- **Ch 16 owns** the ceiling. Ch 12 is 70B on rented multi-GPU capacity, which is the top of what
  this book teaches hands-on. 400B on H100 clusters is argued economically in Ch 16, not
  reproduced.

## Target shape (provisional)

Shorter than Ch 10 and Ch 11, deliberately: ~15 pages, ~5k words, fewer diagrams, because the
teaching load is carried by the earlier chapters and this one spends it. A capstone that runs as
long as the chapters it integrates is usually padding.

This is the chapter that most needs **one real, paid, end-to-end run**, and it should be budgeted
as such. Everything else in Part III can lean on mocks; a 70B capstone whose numbers are synthetic
undermines the whole part. Identify the run early and cost it before drafting.

## Section plan (draft, to be firmed up)

### Act 1 — The requirement, stated properly (~15%)
A concrete 70B serving target: model, context length, expected concurrency, latency tolerance, and
a budget. The chapter's discipline is that the budget is a real constraint, not a footnote. Most
deployment guides state requirements as capabilities; this one states them as money and then holds
itself to it.

Anchored on Llama 3.3 70B Instruct, which Ch 9 already cites and which Ch 9 and Ch 10 both size at
roughly 140 GB in half precision. Context and concurrency are stated as memory reservations rather
than as capabilities, which is the framing Act 2 needs to trade them off. The budget is derived from
the hosted per-token bill it replaces, using Ch 11's published rates, and lands near the crossover
on purpose. See "The budget is a ceiling" below for what that number is doing.

### Act 2 — Working the loop (~30%, the chapter's spine)
The interaction the earlier chapters could not show. Quantization choice against card count against
topology against vendor availability against price, iterated until it closes. Show a first pass
that does not close, and why, before showing one that does. This is the act that makes Ch 12 a
chapter rather than a walkthrough.

### Act 3 — Standing it up (~25%)
The actual deployment on the v0.3 control plane: pin the weights, declare the topology, resolve
capacity across providers, deploy, watch the fleet register, serve. Every verb here is one the
reader already met, which is the point, so keep the prose moving and do not re-explain them.

### Act 4 — What it costs, measured (~20%)
The real numbers from the real run against Act 1's ceiling. Where the estimate was wrong and why.
Cold-start cost at 70B, the warm-cache saving from Ch 9 applied at this scale, and the per-token
cost including the capacity that sat idle. This is the most valuable act for a reader deciding
whether to self-host at all, and it should not be softened.

Measured and projected stay separate throughout, per the subsection below. The idle capacity is the
centre of the act rather than a closing caveat, because the elastic comparison is where the honest
answer lives.

### Act 5 — Capability Snapshot + close Part III (~10%)
**Cannot be drafted until `ch12-final` is cut**, since it transcribes a `capabilities.yaml` entry
that does not exist before the tag. Stays a stub through the rest of the drafting. Closes Part III
and hands to Ch 13, which is about keeping this running rather than getting it up.

## Patterns to name (candidates)

- **The constraints interact.** Optimising each variable alone gives a configuration that does not
  exist at any vendor. Integration is where isolated advice fails.
- **State the budget as a constraint, not a footnote.** A deployment plan that cannot be priced is
  not a plan.
- **A rented bill has a ceiling.** Per-hour capacity costs at most its rate times the hours, which
  is arithmetic you can do before renting. A per-token bill is bounded by traffic, which is the one
  variable you do not control. Added 2026-08-16; it is what makes Act 1's budget an upper bound
  rather than a guess, and it is the thing Act 4 measures the distance to.

## Settled 2026-08-16

**The paid run is on Vast.** Vast satisfies `Deployer` directly now, so a destroy terminates the
contract rather than leaving a VM billing, and it is the cheapest tier, which suits Act 1's budget
discipline. What remains open on the run is the model, the quantization, the card count and the
duration, all of which fall out of Act 2's loop rather than preceding it.

Choosing Vast promotes two vendor-specific bugs into blockers, both in Act 3. Volumes are
machine-scoped so `iplane model pin` does not port (issue 254), and every pre-serving state reports
as "waiting for port" so a 70B cold start is one opaque stall (issue 259).

**Act 2 uses a captured snapshot with a stated as-of date**, from a real cross-provider search
rather than hand-authored numbers. It ages visibly, which is the honest failure mode and the one
Ch 11 already uses for market claims.

**Acts 1 to 3 are drafted before the run; Act 4 after it.** The run is targeted at what those acts
turn out to need, which keeps it to one rental rather than two.

### The budget is a ceiling, and that is the argument

Reframed by the author 2026-08-16, and it is a better spine than the flat monthly comparison the
scaffold originally implied.

The \$1,500 figure is what the deployment costs **saturated**, running the stated load every hour of
the month. Two things follow, and Act 1 should carry both.

First, the ceiling is computable before renting anything. Rented capacity bills per hour at a rate
you know in advance, so the worst case is arithmetic. A hosted per-token endpoint has no such
bound, because its bill scales with traffic, and traffic is the thing you do not control. Success,
abuse and a runaway retry loop all land on the same invoice line. That is an operational property
worth stating plainly rather than an argument for self-hosting, since it cuts against a per-token
bill even when the per-token bill is cheaper.

Second, we never run a month, and neither does the reader necessarily. Per-hour billing is elastic
at hour granularity, so the real question is not which monthly total is smaller but at what duty
cycle renting wins. Below saturation the rented pool keeps billing while the hosted endpoint does
not, which is why Act 4's idle capacity is the centre of that act rather than a caveat on the end
of it. This is the same crossover Ch 11's fifth problem asks the reader to find, met again with
real numbers, and it is what makes scale-to-zero (issue 297, deferred to v1.0) matter rather than
being a nice-to-have.

So the budget does double duty: an upper bound fixed in Act 1 before any money is spent, and the
thing Act 4 measures the distance to.

### Measured against projected, in Act 4

Our run is hours, not a month, so Act 4 reports two clearly separated kinds of number and never
blurs them. **Measured** is what the run actually cost, what the cold start cost inside it, and the
observed TTFT and throughput. **Projected** is what that implies against Act 1's ceiling, with the
assumptions stated.

The join is where a measured number quietly turns synthetic, so the act says what a few-hour run
cannot tell you: preemption frequency, price drift over weeks, whether the duty cycle holds, and
the fact that a cold start is amortised rather than paid hourly. Ch 9 set the precedent by reporting
its 72B cold deploy at about \$4.40 of GPU time against forty cents warm, both real and both small.

## Settled: the Ch 13 seam

Ch 12 ends when the deployment serves correctly under expected load. Everything about what happens
at 3 a.m. is Ch 13. Runbooks, SLOs, incident response and autoscaling are all downstream of that
line, and Act 4's cost measurement is the last thing inside it.

## Working model: the prose specifies the surface

Set 2026-08-16. Each act is drafted against the `iplane` surface it *should* have, and the matching
tickets are filed as the act is written, so the paired repo implements in parallel rather than the
book waiting on it. This is the Tanenbaum pairing running in the direction it was built for.

The line runs between interface and measurement, and it is not negotiable in either direction.

- **Interface can be written ahead.** Command shapes, flag names, output columns, state names and
  the structure of a transcript are all things we are choosing. Writing them down first is
  specifying, not inventing.
- **Measurements cannot.** Timings, costs, TTFT, throughput and anything with a unit come from the
  real run. A drafted transcript carries its numbers as `% TODO(friction)` until the run fills them.

**Drift is now the main risk**, because the prose is the spec. Every ticket has to pin the exact
flag names and output shape the prose commits to, or the repo ships something adjacent and the
chapter is quietly wrong. When they do diverge, the paired repo publishes an `iplane-inbox` marker
and the `drain-iplane-inbox` skill reconciles the chapter. Check the drafted surface against the
code before the act is considered done, not at chapter close.

## Per-act deliverables

Each act ships prose plus its figures and its problems, written with the act rather than retrofitted
at the end.

- **Diagrams** are TikZ or pgfplots in `diagram_*.tex`, `\input` at the point of reference, two to
  four per major section, `[H]` to pin them. Fewer here than in Ch 10 or Ch 11 by design.
- **Problems** accumulate per act toward roughly five for the chapter, matching Ch 11. Each one asks
  the reader to work a decision rather than recall a fact.
- **Patterns** get a `\label{pattern:<slug>}` at first naming, since the Act 5 snapshot and later
  chapters `\S\ref{}` back to them.

## Ticket state (triaged 2026-08-16, against the code rather than the issue text)

Epic is iplane issue 319, labelled `capstone-70b`. Four blockers, one per act that needs one.

- **193 shipped, 2026-08-17.** `iplane model budget` (PR 322) plus the `DescribeModel` RPC behind
  it (PR 321), on top of the arithmetic in PR 317 and the hub read in PR 318. Act 2's two listings
  are real captures against it. Two further tickets came out of drafting and also shipped: **323**
  (PR 328) separates what a card advertises from what it holds, so `--vram-gb 80` resolves to 80
  GiB rather than 80 decimal GB, and **326** (PR 329) makes a deploy read its own engine args back
  and refuse a plan the cards cannot hold.
- **259 shipped** (PR 330). Act 3's watch step is written against the real phase ladder,
  `vast:scheduling` to `vast:image-pull` to `engine:init`, and around the dated incident where one
  status line covered four situations with one of them fatal.

- **254 closed as not planned** (PR 331), and this one changed the chapter rather than unblocking
  it. Vast cannot attach a volume mount at all, and porting `model pin` to it would mean betting a
  deployment on re-renting one specific physical machine out of a marketplace, so it stays
  unsupported deliberately. What shipped is a refusal: a deploy carrying a `model_cache` mount onto
  a provider that cannot attach one now fails up front instead of silently downloading.

  **Two consequences the rest of the chapter has to carry.** There is no warm cache on Vast, so
  every deploy pays the full 70B download and Act 4 reports one cold start rather than the cold/warm
  A/B Ch 9 ran. And the near-miss belongs in the prose, because the old behaviour reported
  `storage_tier=warm` while paying full cold cost, which would have put a warm figure that was
  actually a cold figure into Act 4 with nothing in the data to show it. Act 3 says so.

- **163 shipped** (PR 332) and gives Act 4 its arithmetic. Uptime is now per rented instance from
  when the meter started, a new per-instance rate carries what the provider quoted, and spend is a
  join rather than a projection:

  ```
  sum(instance_uptime_seconds_total * on(instance_id) instance_rate_usd_per_second)
  ```

  Note the `providers.yaml` lookup the original ticket assumed was not used and could not have
  been, since its `gpu_type` vocabulary matches no adapter's SKU string. Do not write Act 4 against
  the catalog gauge; that one prices what you *could* rent, which is a different question.

Two items came back different from how they were carried in. **160** is fixed, under a later
duplicate, and is now closed. **161** is half fixed: Vast and RunPod both terminate their machines,
and only Lambda Labs still orphans the VM, so it no longer touches this chapter.

**289, 292, 297 and 302 stay open on purpose.** Ch 11 §11.6 transcribes them as deferrals, so
closing one means rewriting that section rather than editing it.
