# Chapter 13 working outline

**Status (2026-08-25): complete first draft, plus one drain absorbed into prose.** All six acts,
26 pages, 26 sections.
Builds with zero errors, zero overfull boxes and zero unresolved references or citations.

**Diagrams done 2026-08-24: eight of them, two more than planned.** All render, chapter is 24 pages.

| Figure | Act | Source of its numbers |
| --- | --- | --- |
| 13.1 total against active | 1 | computed from the published config |
| 13.2 where the extra memory goes under each split | 1 | computed, stacked so the identical term shows |
| 13.3 the gate ladder | 2 | the five gates, with what each rejected |
| 13.4 advertised against achieved bandwidth | 2 | two measured transfers |
| 13.5 eight-card availability | 2 | **real data**, 132 scheduled samples over three days |
| 13.6 members against machines | 3 | the two failure rules drawn side by side |
| 13.7 the silent cold start | 4 | proportions illustrative, asymmetry verified in vLLM source |
| 13.8 three readings that disagree | 4 | the hung-collective capture, replaced the transcript |

Figure 13.5 is restricted to post-catalog-fix samples on purpose. Plotting the earlier window beside
them would conflate "supply appeared" with "we became able to see it", which is the error the
surrounding section warns about.

**Absorbed 2026-08-25 directly into prose** (the chapter is drafted, so these did not go to
`part4_outline.md`): a new §13.4.5 on a co-tenant holding memory on a rented card, and a coda to
§13.4.1 on the log-reading instrument that worked perfectly and returned a useless string.

Still outstanding: a full `book-style-sweep` read-through rather than the per-act scans done during
drafting, and the act balance has drifted with the additions. Act 5 is 19% against a planned 15%
and act 4 is now 24% against 20%, while act 6 sits at 6.6% against 10%. Both overruns are material
the chapter wants; act 6 is the one that is genuinely thin. This file is the staging ground, and it goes away section by
section as prose lands in `index.tex`.

The evidence this chapter draws on lives in `part4_outline.md` under "Evidence from the capacity
audits", which now carries 25 entries. This file does not copy them. It decides what the chapter
does with them, which is the harder half, because the chapter has considerably more material than
it can hold.

---

## The title, settled 2026-08-24

**Serving a Frontier Model, and What the Market Will Sell You.**

The old title was *Serving a Trillion-Parameter Model* and its abstract promised "renting a genuine
multi-node fabric when no single machine will do." Neither survived August. Kimi K3 has no route,
since nothing above 81 GB a card has appeared at eight wide and no vendor sells a cross-node fabric
self-service, which Lambda's published schema settles for its own part with 24 paths, no cluster
path under any spelling, and a launch call carrying no quantity field. What we serve is GLM-5.2 at
753B on eight H200s, and it fit comfortably.

The new title matches Part IV's own comma register and promises exactly what the chapter delivers.
It also makes the qualification arc the point rather than an apology for a missing capture. The
trillion-parameter model becomes the ceiling Chapter~\ref{ch:ceiling} measures.

Both abstracts in `index.tex` were rewritten to match, and they stay byte-identical to each other.

## The chapter's force

At 8B a model just runs. Chapter~\ref{ch:70b-deployment} made memory a gate at 70B, and the budget
arithmetic was the whole story. At 753B the arithmetic is the easy part and **everything that used
to be a detail becomes a gate.** The kernels gate you, because the model's attention does not
compile below Hopper. The published build gates you, because the four-bit weights are somebody
else's repository and each build picks a silicon floor. The datacenter gates you, because a volume
and the cards have to be in the same one. The host's link gates you, because achieved throughput
runs five to eight times below the advertised number and download time dominates the hourly rate.
And the market gates you, because the shape you want is intermittently available and the fabric
above it is not sold at all.

Acquisition stops being shopping and becomes qualification. That is the chapter.

The second half is that once the thing is running you cannot see what it is doing, and at these
rates not seeing is expensive. Both halves are on the record with receipts, which is the part no
other book has.

---

## Stable facts this chapter is drafted against

Cross-references point at the evidence entries in `part4_outline.md` rather than restating them.

| Fact | Entry |
| --- | --- |
| GLM-5.2 attention kernels are Hopper and up, so the cheapest eight-card boxes cannot serve it at any price | "The cheapest eight-card box cannot run the model's attention" |
| `zai-org/GLM-5.2` is unquantized, so a four-bit run needs a third party's build, and each build constrains the silicon | "The four-bit weights are somebody else's repository" |
| Advertised bandwidth overstates achieved by 5-8x, and total run cost inverts the price ranking | "Advertised bandwidth is a filter, achieved throughput is the plan" |
| Expert ranks hold whole experts plus a full copy of everything else, so EP costs more per card than TP | "Expert parallelism leaves most of the model uncut" |
| No engine takes an expert degree as a flag, so it is translated on the way out | same entry |
| A member is a set of machines. Across members a partial result is a service, within a member it is nothing | "A member is a set of machines" |
| Nobody sells a cross-node fabric self-service; Lambda's schema has no cluster path | "The fabric gap moved from iplane to the market" |
| The engine emits nothing during a 474 GB download and streams a progress bar for the shorter phase | "The engine will not narrate its own cold start" |
| Eight cards at 86% utilisation with a flat disk is a hung collective, not a slow download | "Eight GPUs at 86%, doing nothing at all" |
| Destroy stops the engine, Terminate releases the rental, and they coincide only on image-native providers | "Destroy releases the container, Terminate releases the rental" |

**Anchor.** GLM-5.2 at AWQ-INT4, 753B total and 41.8B active, 474.2 GB of weights, on 8x H200 at
$32.88/hr, tp8. Real, rented, and it served. Every worked example threads that anchor.

---

## What belongs to other chapters

The single most useful thing this file does. Ch 13 currently attracts material that is not its own.

**Goes to Ch 14 (cost):** the measured curve and its fit, the grading discipline (p95 / p50 /
nothing) and the five faults that made the first sweep unpublishable, the cost of not knowing,
rehearsing the expensive path on a one-GPU box, and the buffering-proxy retraction. All of it is
measurement methodology, and Ch 14 is the measurement chapter.

**Goes to Ch 15 (ceiling):** the ceiling arithmetic, the market wall above one node, and the
build-only-what-can-be-tried rule that the failure record argues for.

**Stays in Ch 13:** acquisition, the third split, the build choice, cold start, observability, what
breaks, teardown.

**Held, not applied:** four markers asked for forward references into Ch 9, Ch 10 and Ch 11. Part
IV's rule is that previous chapters stay closed, so nothing was back-ported. Open decision 6 in
`part4_outline.md` decides them together, and Ch 13 should know the answer before drafting because
it leans on all three.

---

## Section plan

Six acts. The four-act pattern assumes one principle and one iplane move, and this chapter pairs
acquisition with serving, so it runs closer to Ch 10's shape.

### Act 1 - What changes at this size (~15%) --- DRAFTED 2026-08-24

Open on the arithmetic that stops mattering. A sparse model's memory scales with total parameters
while its throughput scales with active ones, which Chapter~\ref{ch:how-llms-work} already taught as a
fact about architecture, and here it becomes the number that decides a rental. Carry that into the
third split, which is where the chapter's first real surprise lives: expert parallelism costs
*more* memory per card than the tensor split it superficially resembles, because it replicates
what it does not shard.

**Verified figures, 2026-08-24.** Recomputed from the published config rather than taken from the
marker, which did not survive checking. At four bits on eight cards, tp=8 wants 47.08 GB a card and
tp=1/ep=8 wants 55.35, a difference of 8.26 GB. The difference widens with precision, to 16.53 GB
at fp8 and 33.06 at fp16. The replicated part is the attention, the embeddings and the dense
layers, which come to 18.9B of the model's 753B parameters, so seven extra copies of 2.5% of the
model is where the whole penalty comes from. Do not write that expert parallelism leaves most of
the model uncut, because by parameter count it shards 97.5% of it.

Close on divisibility, briefly, since a degree that does not divide the expert count leaves one
card holding more than the budget priced.

### Act 2 - Acquisition as qualification (~25%) --- DRAFTED 2026-08-24

The manual path, and the chapter's strongest act because every gate cost us something real.

Run the gates in the order they actually bite, which is not the order anyone shops in. Can the
silicon execute the model's kernels at all, which no price table shows. Which published build
exists, and what silicon floor it carries. Where the capacity is, and whether that datacenter will
hold a volume. What the host's link actually delivers, as opposed to what it advertises. Only then,
price.

Two artifacts carry this act. The four-build table is the acquisition decision in one view. The
price-inversion table is the most persuasive thing Part IV has produced, because the cheapest
sticker price is nearly the worst total cost and the reason is arithmetic rather than judgment.

The incident to tell plainly: we booked eight A100s at $10.67/hr and spent thirty-five minutes
downloading weights the cards could never have served. Every number in the analysis behind that
booking was correct. The frame was missing a constraint, and no amount of further price research
would have found it, because it was not a fact about price.

Sampling rather than checking closes the act. Capacity at eight cards moves within the hour, so the
useful artifact is a time series and not a snapshot, and that is a difference in kind from
Chapter~\ref{ch:capacity}'s catalogue sort. It also carries a caution we earned: our own sampler
missed the H200 we went on to rent, so a filter that is wrong makes the market look empty.

### Act 3 - Getting it serving (~15%) --- DRAFTED 2026-08-24

The iplane move, kept short, because the point is that it is short.

The deploy is one command and the interesting part is the translation. No engine accepts an expert
degree, so asking for eight-wide expert parallelism at tp=1 really means asking for a data-parallel
size and a flag, and an operator who cannot see that translation cannot check it. The dry run
prints it.

Multi-node belongs here and it is a qualification failure rather than a demo. The control plane can
hold a member that spans machines, and a member that loses a node hands the whole span back rather
than sitting on N-1 live rentals. What it cannot do is buy one. The refusal names its own reason,
and a tool that says why it cannot help is worth quoting.

State the boundary plainly, because a reader will otherwise expect too much: we rent the span, the
engine assembles across it, and whether four machines become one engine is a matter of the engine
arguments you pass.

### Act 4 - Watching something you cannot see (~20%) --- DRAFTED 2026-08-24

The chapter's centre, and the act that justifies the whole Part IV detour.

Open on the silent hour. The engine hands its downloader a disabled progress bar, so a container
pulling 474 GB emits nothing at all until the fetch completes, while the shorter load phase streams
a progress bar the whole way. Two deploys spent an hour each in that silence and were killed by a
timeout, and the post-mortems said the host was slow, which was inferred from elapsed time and
never measured. One of them was not slow. It was hung.

That sets up the two rules, and both generalise well past GPUs.

**Instrument the effect, not the actor.** Bytes landing on a disk are an effect. A log line is an
actor's account of itself, and actors can be silent, wrong, or dead. The phase split follows from
it, since weights only ever accumulate, so a growing directory means fetching and a static one
means the fetch is done.

**Prefer the observation with the fewest preconditions.** A reading that needs a network path, a
credential, a running agent and a correctly recorded address has four ways to become silence, and
silence is indistinguishable from healthy.

Then the best failure story we have. Eight cards at 86.5% utilisation, 0.188 GB on a 900 GB disk,
last log line 23 minutes stale at the collective completing. Busy cards, flat disk, silent engine,
and every signal read alone says healthy. Utilisation measures effort rather than progress, and
telling the two apart means watching something that should be changing rather than something that
is merely high. Worth noting that a single-card deploy has no collective to hang in, so this
failure is a property of the parallelism.

### Act 5 - Five ways a system that spends money goes quiet (~15%) --- DRAFTED 2026-08-24

**The framing rule for this act, settled 2026-08-24.** Every failure is written as the symptom a
builder would see, not as a bug we had. The test is not "could a reader hit this", which still puts
our tooling at the centre. It is "what would anyone building this observe", which puts the reader
there instead. Our own version stays in `part4_outline.md` for provenance and does not reach the
page. Applied to the ten failures on record, nearly all of them survive, and the two that do not
were the two nobody would have cared about.

Lead with the shape rather than the anecdotes. None of these was findable by reading code, they
surfaced from attempts to spend a few dollars, and four of the five are invisible in the direction
that costs money. Sort by how each presents, because the invisibility is what transfers.

1. **A search that finds nothing looks like a broken market.** A capacity query matching nothing
   returns an empty answer rather than an error, which on a market where supply moves hourly is an
   ordinary Tuesday. Code that treats empty as exceptional falls over on a normal day. Worse, two
   paths asking "what can I rent" disagreed, so one reported no capacity while the other listed two
   rentable boxes at that same moment.
2. **The window between committed and recorded.** The call that rents sits a few lines below the
   call that searches. A crash on the search side costs nothing. The same crash a moment later
   leaves a machine rented whose identifier was never written down. Anywhere money is spent through
   a third party's API, that window is the most dangerous code in the system.
3. **A rental that failed recorded no cost at all.** It dropped out of the spend series rather than
   appearing as zero, so there was no anomaly in a graph to catch, just one fewer line than there
   should have been. The failures that hid this way were the expensive ones.
4. **A filter that is wrong makes the market look empty.** One vendor labels a card in decimal and
   another in binary, so a memory floor computed for one convention silently matches nothing under
   the other. We are still living with this one, since it is why our own sampler missed the H200 we
   went on to rent.
5. **A status check that discards a definitive answer.** It asked the provider, received a 404, and
   threw it away, so machines from an old session sat listed as active at $0.44/hr each, in exactly
   the listing you check after a crash.

Two carry their own principle and get named.

**Absent is not zero.** Three unrelated readings made the same mistake, and each time collapsing
"no reading" into "zero" invented a fault or hid one. A fabricated zero looks like a confident
measurement, which is what makes it worse than an obvious gap.

**A guard must not share a fate with the thing it guards.** The heartbeat story is the centrepiece
because the signal was true the whole time. The script really was alive. Treating a proxy for
health as health is the mistake, and every layer worked exactly as designed while a $54/hr box
billed with nothing able to drive it.

Teardown closes the act, since stopping the workload and releasing the capacity are separate
operations that only look like one where the unit of compute and the unit of billing coincide. Our
records said terminated while the machine ran, which is the cleanest case of a theme worth stating
once: our records are not evidence about somebody else's system.

### Act 6 - What this enables, and the handoff (~10%) --- DRAFTED 2026-08-24

It serves. The next question is what it costs, and Chapter~\ref{ch:cost-curve} measures it.

No Capability Snapshot until Part IV's tag is cut. See `CLAUDE.md` on drafted-is-not-closed.

---

## Patterns to name

Each gets `\label{pattern:<slug>}` at first naming, so the snapshot and later chapters can point
back.

| Pattern | Slug | Act |
| --- | --- | --- |
| Qualification before price | `pattern:qualify-before-price` | 2 |
| Filter on advertised, plan on achieved | `pattern:plan-on-achieved` | 2 |
| Instrument the effect, not the actor | `pattern:instrument-the-effect` | 4 |
| Fewest preconditions | `pattern:fewest-preconditions` | 4 |
| Utilisation measures effort, not progress | `pattern:effort-not-progress` | 4 |
| Absent is not zero | `pattern:absent-is-not-zero` | 5 |
| A guard must not share a fate | `pattern:guard-outlives-charge` | 5 |

---

## Diagrams planned

Five or six, matching Ch 10's density. All are `diagram_*.tex` inline, none exist yet.

1. **The gate ladder** (act 2). Kernels, build, datacenter, link, price, in the order they bite,
   with what each one rejected on the GLM run. Replaces a bulleted list.
2. **The price inversion** (act 2). Total run cost against hourly rate for three hosts, showing the
   cheapest sticker price landing worst. Data is in the evidence entry.
3. **Where the weights sit under each split** (act 1). TP slices every matrix, EP holds whole
   experts and replicates the rest. This is the one that makes the memory result obvious.
4. **The cold start, silent and chatty** (act 4). A timeline with the download phase dark and the
   load phase instrumented, against the phases we can now derive from outside.
5. **Three readings that disagree** (act 4). Utilisation, disk, and last log line on one axis for
   the hung collective. The contradiction is the teaching moment.
6. **Optional: supply over time at eight cards** (act 2), from the sample log. The only Part IV
   figure we can produce without renting anything.

---

## What is in hand and what is missing

**In hand.** Everything acts 1 through 5 need. Ten distinct failures with receipts, the four-build
table, the price inversion, the EP arithmetic, a real cold-start trace, and the GLM deploy itself.

**Missing, and none of it blocks drafting.**

- A multi-node capture. There will not be one until somebody sells a fabric, and act 3 is written
  around that rather than waiting on it.
- Anything at all on K3. Marked as the gap, per the roadmap's rule that K3 upgrades the evidence
  and never carries the argument.
- The unexplained stall time at high concurrency. Ch 14's problem rather than this chapter's, but
  the diagnosis may produce act 4 material.

**Mechanical, before drafting.** `references.tex` is a nine-line stub. No `diagram_*.tex` exists.
The book has no `\addplot table` precedent, so figures 2 and 6 either get a data-file pipeline
built once or get transcribed with a provenance comment the way Ch 9 does it.

---

## Absorbed markers

Every marker below is archived in `iplane-inbox/.processed/` and its content lives in
`part4_outline.md`. Listed here so the chapter's provenance is reconstructable.

- [x] `2026-08-18T19-45-00--staging-pays-only-on-a-slow-host`
- [x] `2026-08-21T22-10-00--expert-parallelism-is-the-third-split`
- [x] `2026-08-21T22-12-00--glm-52-needs-hopper-and-the-cheap-tier-cannot-serve-it`
- [x] `2026-08-21T22-14-00--the-model-is-not-a-four-bit-repo`
- [x] `2026-08-21T22-16-00--b300-makes-the-frontier-model-single-node` (contradicted by later sampling)
- [x] `2026-08-21T22-18-00--nobody-sells-a-cross-node-fabric-through-an-api`
- [x] `2026-08-21T22-20-00--a-member-is-a-set-of-machines`
- [x] `2026-08-21T22-22-00--a-warm-cache-is-datacenter-bound`
- [x] `2026-08-21T22-26-00--what-breaks-five-defects-with-receipts`
- [x] `2026-08-21T22-28-00--capacity-is-perishable-and-now-sampled`
- [x] `2026-08-23T22-29-25--advertised-bandwidth-is-not-achieved-throughput`
- [x] `2026-08-23T22-29-25--the-engine-will-not-narrate-its-own-cold-start`
- [x] `2026-08-23T22-29-59--observability-that-needs-a-credential-is-not-observability`
- [x] `2026-08-23T22-29-59--utilisation-is-not-progress`
- [x] `2026-08-23T22-30-32--a-phase-you-cannot-attribute-cannot-be-debugged`
- [x] `2026-08-23T22-30-32--absent-is-not-zero`
- [x] `2026-08-24T15-23-47--destroy-releases-the-container-terminate-releases-the-rental`

---

## Open questions

1. ~~**The title and spine.**~~ Settled 2026-08-24, see above.
2. ~~**Forward references into closed chapters.**~~ Settled 2026-08-24: **errors only.** A closed
   chapter is edited where Part IV proved a claim false, never where Part IV merely went further.
   Under that rule three of the four held items need no edit at all, because Ch 9's warm cache,
   Ch 10's two splits and Ch 11's price sorting are matters of scope rather than error. The one
   remaining candidate is the no-self-service-fabric claim in Ch 10 and Ch 11, and it waits on
   verifying Nebius against its published API. We have that claim from a marker only, and Lambda's
   schema just demonstrated how badly a hand-run probe misleads, so editing shipped prose on
   unverified evidence would be the worst of both worlds.
3. **How much of the failure record the chapter can carry** before it turns into a war-story
   collection. Ten is too many. Act 5 currently plans five plus two named principles, and the rest
   stay in `part4_outline.md` as material for Ch 15's argument.
4. **Whether act 4 or act 2 leads.** Acquisition is the chronological order and observability is
   the better chapter. Worth trying act 4 first in a draft before committing.
