# Chapter 7: Routing, Queueing, and the Control Plane in the Data Path

Working scaffold built from drained `iplane-inbox/` markers. The chapter prose drafts against this outline in 200--500 word increments. As sections land in `index.tex`, they get migrated out of this file. When the chapter closes on `ch07-final`, the residual stable facts crystallize into the `book/CLAUDE.md` analogue of the Ch 6 stable-facts block.

This scaffold absorbs markers at the **concept layer**, not the iplane-implementation layer. See the `feedback_no_iplane_internals_in_prose` memory and the `book-style-sweep` skill --- the chapter teaches principles (why queue, why scheduler, why long-lived control plane); iplane mechanics live in the repo's design docs. The positive companion: when describing what iplane does *for* the operator, name the manual alternative ("you could do this with cron jobs, a shell-script `pods.txt`, nginx, calendar reminders...") so the chapter teaches the *principle* even while showing the tool.

## Working title and arc

(from `master_outline.md`)

Ch 6 left iplane out of the inference data path on purpose. This chapter is where it gets back in. The router becomes the chokepoint that sees every request; the queue is where multi-tenant fairness and priority lanes get enforced; the scheduler picks what runs next given the engine's batcher window. The chapter closes by fanning the same model out to multiple replicas, the seam Ch 8 picks up. Continuous batching stays where it belongs --- on the GPU, inside the engine from Ch 5.

Working model: 8B class (the pinned `qwen3.5-8b` from Ch 6). Model-size scaling is Ch 9's lead and stays out of scope here.

## Stable facts (concept-level)

The conceptual invariants the prose must respect from sentence one. Each entry cites its absorbed marker as the audit trail; mechanism details stay in iplane's repo.

### The control plane and data plane are conceptually separate, even when co-located

*Absorbed from `2026-06-02T10-01-00--cpdp1-architectural-constraint.md` (iplane PR 110).*

Even when iplane hosts both planes in one process (the v0.2 daemon), the boundary between them is well-defined. The chapter teaches this as a standard distributed-systems point --- a router that's part of a single-process daemon today is conceptually no different from a router that lives behind a wire later. The same architecture extends to per-cluster routers, edge proxies, and distributed deployments without rewriting the request path. iplane enforces the separation as a project constraint; readers studying the implementation can see how in `inference_plane/CONSTRAINTS.md`.

### The control plane becomes long-lived and stateful

*Absorbed from `2026-06-02T10-02-00--daemon-state-ownership-and-stores-tier.md` (iplane PRs 109, 113, 114).*

Ch 6's demos brought up a pod, ran a query, and tore it down --- fine for a self-contained example, but every demo paid the bringup cost. An operator running these by hand from Ch 7 onward would track deployment state in a notebook or a shell-script `pods.txt`, and let the file be the source of truth across demos; that mental model is exactly what the chapter teaches, just with a tool taking on the bookkeeping. We let iplane do it: the daemon runs continuously and owns deployment state across restarts. This enables three things the chapter leans on. Multiple demos share one running deployment without per-demo bringup cost. The idle-TTL reaper (next subsection) protects the operator's wallet without operator discipline. And the queue's continuity across demos is what makes multi-tenant fairness observable in the first place --- fairness needs more than one request and more than one tenant talking to the same backend over time. iplane implements this with a long-lived daemon; the implementation details live in the repo's design docs.

### iplane is now the chokepoint in the inference data path

*Absorbed from `2026-06-02T10-03-00--router-in-data-path.md` (iplane PRs 115, 117, 118, 119, 120, 121).*

This is the chapter's central shift from Ch 6. Ch 6 chose to keep iplane out of the data path; Ch 7 reverses that. An operator could put nginx, Caddy, or a custom Go forwarder between the client and the engine --- any reverse proxy with header pass-through and SSE support would do, and the principle the chapter teaches is the same regardless. We use iplane as the proxy because the deployments are already registered with it and because the metrics and traces it emits chain into the rest of the chapter's observability story. A thin reverse proxy in iplane sits between the client and the engine, and every inference request flows through it. The shift is what makes the rest of the chapter possible --- multi-tenant fairness, priority lanes, observability, A/B routing, and replica fan-out are all consequences of the router being in the path.

Operators see two URL shapes. The default is flat --- `POST /v1/chat/completions` with `model` in the body --- so operators paste `base_url=http://<iplane>/v1` into any OpenAI-compatible client and it just works. The escape hatch is explicit dispatch --- `POST /v1/<deploy-id>/v1/chat/completions` --- for debugging and A/B routing. The simple thing is the default; the explicit thing is one path segment away.

Streaming responses pass through the proxy without special-case code because the reverse proxy auto-flushes when the engine's `Content-Type` is event-stream, and client-disconnect propagates upstream the same way. The same passthrough logic carries trace context end-to-end --- a single trace tree spans client → router → engine because the propagator runs through the router on every request.

The chapter's observability beat lives here. Request rate, latency histograms, and completion-token throughput now emit from the router (their natural point of measurement), which restores the panels Ch 6 PR 52 honestly removed when it admitted iplane was not seeing requests. The "remember those panels we removed?" callback is the chapter's most satisfying narrative beat.

### Idle-TTL reaping protects the operator's wallet without operator discipline

*Absorbed from `2026-06-02T10-04-00--idle-ttl-reaper-touch-pin.md` (iplane PRs 123, 125).*

Long-lived control planes accumulate state, and a control plane that accumulates running pods will leak them. The simplest leak-protection mechanism is idle-TTL reaping --- destroy a deployment after no activity for N seconds. An operator running pods by hand could implement this with a cron job, a shell timer, or a calendar reminder; the discipline works for one pod and breaks down once the operator is juggling several at once. We let iplane do the reaping: the daemon sweeps its deployments on an interval, identifies anything idle past its TTL, and tears it down. The cost guard becomes a property of the tool, not of the operator's attention.

The deeper design lesson is that **activity must be explicit, not implicit**. An operator wiring this up by hand might be tempted to count any RPC against the deployment as activity --- but a read-only `describe` query that resets the TTL clock would be surprising; operators would discover that "looking" extends "owning." Whether iplane writes the rule or you do, the principle is the same: when designing an activity signal, ask whether a read-only query resetting the clock would surprise the operator. If yes, force the writer to be explicit.

Two operator affordances compose with the reaper. The pin (`--no-idle-destroy` at deploy time) marks a deployment as the shared anchor that demos and load tests dial --- it skips reaping entirely. `iplane deployment touch <id>` is the manual extension verb for the in-between case where a deployment is not pinned but the operator wants to keep it warm without driving traffic. The pattern --- named anchor + extension verb + automatic reap --- is the principle the chapter teaches; iplane is the shape it takes here.

One honest gap: the chapter notes that daemon downtime currently counts against the idle clock. If the daemon crashes for two hours, every deployment's age computes as two hours longer when it restarts, which can trigger false reaps. v0.2 ships this as a documented limitation; v0.3 fixes it. Same honest-tradeoff energy as Ch 6 PR 52's dashboard-removal story.

### Backpressure is a first-class signal: bounded queue plus 503

*Absorbed from `2026-06-02T10-06-00--queue-scheduler-priority-tenant.md` (iplane PRs 128, 130, 131, 133).*

The chapter's first formal model. The router optionally puts a bounded waiting room in front of the engine; when the queue fills, the router returns 503 with `Retry-After: 1` to the caller. This is the textbook M/M/k/N response to a finite-capacity queueing system --- k servicers, N total positions, requests refused beyond N. The chapter teaches the principle in queueing-theory vocabulary (Kendall notation, Little's law) that maps directly to any operator's prior experience with bounded buffers.

An operator could implement the same shape with nginx's `limit_req` module, HAProxy queueing, or Envoy's load-balancing-with-queue --- and the principle is the same regardless of where the queue lives. We build the queue into iplane because it sits next to the deployment registry and because the scheduler that drains it needs to see the priority and tenant headers iplane already extracts. Putting it elsewhere would mean duplicating header extraction and synchronizing with deployment state across the boundary.

The unbounded alternative is the trap. Under sustained overload, queue length grows, latencies grow, callers time out, and the system collapses into thrashing. Bounded says "no" early. The 503 is honest backpressure --- it tells the caller "the system is full; retry in 1 second" instead of pretending and failing slowly.

### iplane abstractions stop at the proxy boundary

*Absorbed from the same marker (PRs 130, 131).*

Tenant identity and priority class are iplane concepts. Engines are not. When the router forwards a request, it strips `X-IPlane-Tenant` and `X-IPlane-Priority` headers before reaching the engine. Engines see raw OpenAI-API requests --- no tenant, no priority. The architectural rule the chapter teaches: control-plane abstractions that the engine does not consume MUST NOT leak through the proxy.

The reasoning is twofold. Engine-side metric cardinality stays bounded --- letting tenant or priority into engine-side metrics would multiply the label space by tenant count and priority count, both of which grow over time. And engines stay free of policy concerns --- once an engine sees tenant identity, it becomes tempting to branch engine logic on it (per-tenant token limits, per-tenant model choice), which puts iplane policy upstream *and* downstream of the engine. Keeping engines policy-blind is what makes the proxy boundary a real abstraction line.

Correlation across the boundary continues via `trace_id` alone --- the tracing seam Beat 1 established carries through. Operators who later add real auth in Part V swap the header-based tenant assertion for token validation without changing where the boundary lives.

### Priority is a property of the request, not the deployment

*Absorbed from the same marker (PRs 131, 133).*

A request carries its priority class (`X-IPlane-Priority: INTERACTIVE` or `BATCH`); the deployment that serves the request has no priority field. This is the architecturally correct shape, and the chapter teaches it as a "first design was wrong; review caught the leak" beat. An earlier design had a `Deployment.default_priority` field for per-deployment fallback. The reasoning was operator convenience --- set the priority once at deploy time, don't make every client pass a header. Review found the leak: the engine inside the deployment is priority-blind (it does continuous batching on whatever requests it gets, with no notion of importance), so per-deployment priority would have put routing policy onto the runtime artifact. The router is the sole priority decision point.

The scheduler's strict-priority dispatch is the deliberate v0.2 choice. Interactive requests cut ahead of batch requests; batch can starve under sustained interactive load --- which is the chapter narrative, not a bug. Operators deploying in production where batch is real work want weighted-round-robin or aging variants, which the chapter mentions as v0.3 follow-ups so readers know "strict priority is the principle; aging is the production sharpening."

The router's per-deployment in-flight cap mirrors the engine's `max-num-seqs` from Chapter \ref{ch:engines}. Both bound concurrency; neither knows about the other; they cooperate by each enforcing their own ceiling. When one engine's `max-num-seqs` becomes the throughput limit, the answer is fan-out --- more engines, not bigger engines. This is the seam to Beat 3.

### Fair-share within a priority lane is per-tenant weighted dispatch

*Absorbed from `2026-06-02T10-07-00--fair-share-queue-observability.md` (iplane PR 134).*

Strict priority handles ordering *between* lanes (interactive cuts batch). Fair-share handles ordering *within* a lane *across tenants*. Each tenant gets its own bounded sub-queue inside a lane; the scheduler picks one tenant per dispatch via a weighted lottery --- collect tenants with non-empty sub-queues, sum their weights, pick a uniformly-random integer in `[0, total)`, dispatch from the tenant whose cumulative-weight interval contains it. Under sustained saturation, the dispatch ratio converges to the configured weight ratio.

An operator could build the same shape on top of a weighted priority-queue library, a K8s `ResourceQuota` at the deployment level, or per-API-key rate-limit middleware --- the principle the chapter teaches is "under saturation, configured weights converge to dispatch ratios," and any implementation that satisfies that property would do. We use iplane's in-process lottery because it sits next to the priority and tenant headers the router already extracts; the dispatch decision is one read away from the data it needs.

Why lottery, not deficit-round-robin (DRR)? Both converge to the same long-run ratio under saturation. Lottery is stateless --- no per-tenant credit counters or cursor management. DRR is deterministic per-request, which matters in some production settings (predictable ordering for debugging). The chapter presents both and picks lottery for its simplicity; operators who need deterministic ordering can swap to DRR without changing the principle.

Per-tenant capacity is the isolation property worth a callout. Each sub-queue is its own bounded buffer; one tenant's burst cannot squeeze others out --- if alice's interactive sub-queue is full, bob's interactive sub-queue still accepts requests. The cost is total lane memory of N_tenants × capacity, which the operator pays for the isolation. Shared-lane capacity (the unbounded alternative) would let one tenant's burst saturate the lane and 503 everyone else.

### Three observability signals answer three different questions about one queue cell

*Absorbed from the same marker (PRs 134, 135).*

A single per-(deploy_id, tenant_id, priority) queue cell emits three observability signals, each answering a different operator question:

- *How deep is the queue right now?* --- a **gauge** observed synchronously on every push and pop, surfaced as a live dashboard panel. Answers "is the queue building up at this instant?"
- *What's the p95 wait time for this cell?* --- a **histogram** observed at pop, capturing the distribution from sub-second to "saturated batch" ranges. Answers "what's the typical wait operators see for this tenant in this lane?"
- *Why did this specific request take so long?* --- a **span attribute** on the router span, set after dequeue. Answers "the customer says request X was slow; how much of that was queueing?"

The framing generalizes beyond queues: aggregates (gauges, histograms) belong on metrics; per-request answers belong on traces. The chapter teaches this as the general split between metrics and tracing.

An operator could collect any of these signals manually --- a custom Prometheus exporter scraping a queue-length endpoint, an OTel SDK instrumented directly in their client, a shell loop logging timestamps. The chapter teaches the three-questions frame; iplane wires up one concrete shape of it. The Grafana panels (queue depth per deploy / tenant / class; queue wait p95 per class) are the dashboard payoff for Beat 2 --- the "show the curves" moment.

One small architecturally clean choice the chapter mentions: the scheduler emits the signals via a small observer interface rather than calling the metrics package directly. The scheduler stays pure orchestration; the metrics wiring lives at the router boundary. This is the chapter's example of decoupling cross-cutting concerns --- one of the easier design lessons to land because the alternative (metrics calls scattered through scheduling logic) is something readers have seen go wrong.

### A deployment is a stable name with N possibly-changing engines behind it

*Absorbed from `2026-06-03T10-00-00--multi-replica-deployment-model.md` (iplane PRs 137, 139, 144, 146).*

Beat 3's central architectural move. A deployment grows from a single engine to a set of replicas behind one stable deployment ID. The URL the client speaks to (`POST /v1/<deploy-id>/...`) is unchanged whether one engine or seventeen sit behind it. The chapter teaches this as the indirection moment that pays off Beats 1 and 2 --- at N=1 the router and the queue looked like overhead; at N>1 the indirection becomes the way "one name, N engines" stays invisible to clients.

An operator could express the same shape by hand --- a list of pods in a notebook, a bash loop that hits the provider's API N times, a shell-script `pods.txt` recording the healthy subset. The manual path works for N=2 and breaks down at N=5 the moment one spawn fails partway and the operator has to reason about which slots they own versus which the provider does. iplane absorbs the bookkeeping. The deployment ID is the name the operator holds; the backing set is what the control plane manages.

Partial failure is a first-class outcome. At N=1 provisioning either works or it does not. At N=5, "3-of-5 healthy" is meaningfully different from "0-of-5", and the control plane has to treat them differently. The DEGRADED aggregate state is the chapter's answer --- it tells the operator "this deployment is serving, but not at full capacity yet." The reconciliation question (when does a deployment self-heal? what triggers a retry of a failed slot?) is honest-tradeoff material; v0.2 ships with the gap acknowledged, v0.3 closes it.

### The scale verb is the operator's primary surface for changing capacity

*Absorbed from the same marker (iplane PR 146).*

`iplane deployment scale <id> <N>` is the operator's verb for changing a deployment's size. One verb, one ID, one new count. Pairs cleanly with Ch 6's `iplane up` flagship --- Ch 6 gave the operator one verb to bring up one deployment; Beat 3 adds one verb to change its size. The deployment ID is the through-line; the operator never has to know more than that to grow capacity.

Scale-up is the v0.2 lead. Scale-down is honestly absent --- asking iplane to scale down a deployment returns "not implemented today," because the in-flight-request-handling design (when do you drain a replica? what about long-running streams?) was deferred to v0.3 after design work. This is the same honest-tradeoff voice as Beat 2's "batch can starve" and Ch 6 PR 52's panel removal. The chapter names the gap rather than papering over it.

### The router fans requests across replicas via round-robin

*Absorbed from `2026-06-03T10-01-00--router-fan-out-across-replicas.md` (iplane PR 140).*

When a deployment has N healthy replicas, the router picks one per request via round-robin and skips any replica the health checker has quarantined. At N=1 the behavior is observably identical to Beat 1's --- the router picks "that one replica" every time. At N>1 the cursor advances on each request and load spreads across the set.

An operator could express the same shape with any reverse proxy that supports a backend pool --- nginx `upstream` blocks, HAProxy's `balance roundrobin`, Envoy's round-robin policy. The principle the chapter teaches is "per-request replica selection with health-aware skipping," and any of those tools satisfies it. We build the selection into iplane because the deployment registry, the health checker, and the request path are already next to each other. Pushing selection into nginx would mean synchronizing its upstream block to iplane's deployment state on every reconcile --- a second source of truth for the same fact.

Round-robin is the v0.2 default by deliberate choice. The router consults no per-replica utilization, no queue depth, no model state; the cursor advances mechanically, modulo the count of healthy slots. The argument for choosing round-robin first is that it requires no per-replica state on the router. The principle "the router is in the data path doing replica selection" lands without dragging in observability or persistence questions. Smarter policies (least-connections, p99-aware, prefix-cache-affinity) are deferred. The router's replica-selection logic lives behind a routing-policy interface; round-robin is the v0.2 default impl, and Chapter~\ref{ch:caching} swaps in prefix-cache-affinity when cache locality becomes the lead concern.

The composition with health is the chapter's payoff. The router skips quarantined replicas without the operator having to tell it which ones to skip. The healthy subset is the load-balancing pool, and it changes shape over time as the health checker observes the engines. The DEGRADED state from the previous marker becomes operationally visible here. A 3-of-5 deployment serves traffic on three replicas; the router does not need to be reconfigured when the fourth replica recovers.

### Per-replica health: observe, label, react

*Absorbed from `2026-06-03T10-02-00--per-replica-health-and-observability.md` (iplane PR 141).*

Beat 3's operational-maturity moment. With N replicas behind a deployment, sooner or later one of them stops answering, and the control plane has to decide what happens next. The shape is a feedback loop --- observe each replica's health, label the unhealthy ones, react in the router. Each step is small; together they distinguish a toy from a control plane.

Observation happens on an interval. A background poller probes each replica's `/health` endpoint --- the same contract the engine exposed in Chapter~\ref{ch:inference-engines} --- on a configurable cadence. A failed probe quarantines the slot; a recovered probe brings it back. Production setups eventually distinguish liveness ("the process is up") from readiness ("the process is ready to serve traffic"); v0.2 collapses these into one probe and v0.3 sharpens.

Labeling is declarative. The health checker does not push a "this replica is bad" event to the router; it writes to the set of unhealthy slots, and the router reads that set on every selection. This is the same shape the deployment registry uses --- state is the source of truth, behavior reads state. Pushing events would mean coupling the health checker's lifecycle to the router's; reading state lets each side evolve independently.

Reaction is passive on the data path. When a replica goes unhealthy, the router stops sending new requests to it. It does not drop in-flight requests --- whatever was already on its way to that replica completes or fails on the engine's error. The aggressive alternative actively cancels in-flight requests when a replica falls over. The chapter picks passive for v0.2 for the same reason it picked strict priority in Beat 2 --- bounded failure mode (worst case is one request gets the engine's error), no question of "which N in-flight requests do we abort," and the simpler primitive teaches the principle without dragging in cancellation semantics. The aggressive variant is named as v0.3 work.

An operator could write the probe loop themselves --- a cron job, a bash script that curls each pod's `/health`, a column somewhere that gets toggled by the script. They would also need to write the metric exporter, the Grafana panels, and the rule that says "skip the unhealthy ones on the next route decision." We let iplane do it because it is the one process that already knows about all the replicas, can probe them on a known cadence, and is in the data path to react to its own decisions.

### Per-replica observability and decision visibility

*Absorbed from the same marker (iplane PR 142).*

Beat 1 restored basic visibility --- the dashboard panels Ch 6 honestly removed came back. Beat 3 restores decision visibility. Two new router-side metrics make the per-replica behavior observable.

A per-replica in-flight gauge keyed by (deployment, replica) answers "is the load spread roughly evenly across slots?" With round-robin selection under sustained traffic, the gauge should look flat across slots. Spikes or imbalance reveal something wrong with the selection cursor or with a specific replica.

A routing-decisions counter keyed by (deployment, replica, outcome) --- where outcome is `forwarded` or `skipped_unhealthy` --- answers "did the health checker's labeling actually change behavior?" Every `skipped_unhealthy` increment is a request that wanted slot K but the router redirected because slot K was unhealthy at selection time. The counter is the only place the operator sees the feedback loop closing.

Both metrics live on the router. The same split from \S\ref{subsec:queue-observability} holds --- aggregate panels say "the system is fanning out cleanly"; an individual trace shows which replica handled the request and why. The chapter calls this the second restoration. Beat 1 brought basic visibility back; Beat 3 brings decision visibility back too.

### Heterogeneous fleets: one deployment, replicas from many providers

*Absorbed from `2026-06-03T10-03-00--heterogeneous-fleets-via-replicaspec.md` (iplane PRs 148, 149).*

Beat 3's differentiator. Without this, multi-replica is "iplane does what k8s does --- scales replicas on one cluster." With it, the chapter has a structural answer to a real operator problem. Capacity is not homogeneous in reality --- RunPod has one inventory; Vast has a marketplace with bid pricing; Lambda Labs has a fixed catalog with regional availability. A deployment that can pull from all three is a deployment that survives a regional outage, a price spike, or a capacity crunch on any single provider.

The operator's mental model stays simple. A repeated `--add-replica <provider>:<class>` flag on `iplane deployment scale` adds replicas of different shapes to the same deployment ID; `iplane deployment scale llama-8b --add-replica runpod:small --add-replica vast:small --add-replica lambdalabs:small` produces a single deployment with three replicas, one on each provider. Operations on it look like operations on any deployment --- one ID, one scale verb, the same DEGRADED bookkeeping if a replica goes unhealthy.

The wire shape has one teachable subtlety. Earlier versions of the API had two distinct request shapes --- a homogeneous one (`--replicas 3` on one provider) and a heterogeneous one (a list of specs). Review caught the wrong seam. Two shapes for one concept leaks the operator's usage pattern into the protocol. The unified design has one shape. Every request is a list of per-replica specs, and the homogeneous case is the degenerate length-one form. This is the same correction shape as Beat 2's `default_priority` rollback --- the naive design looked obvious until it had to share a wire with the more-general case.

The honest cost matters enough to call out. Heterogeneity is an availability feature, not a performance feature. The router still picks one replica per request via round-robin (per the previous stable fact), and the replicas do not talk to each other. A deployment that mixes RunPod + Vast + Lambda has three independent KV caches; round-robin across them does not preserve cache locality, so prefix-cache benefits land per replica, not across the deployment. Chapter~\ref{ch:caching} returns to this when prefix-cache-affinity routing becomes the answer.

An operator could express the same shape by hand --- launch a RunPod pod, launch a Vast bid, launch a Lambda Labs instance, register all three in an nginx `upstream` block, remember which provider owns which IP when one of them dies and the bill needs reconciling. The principle the chapter teaches is the *unified naming* --- the operator says "deployment llama-8b" and stops caring which provider answers. The control plane absorbs the provider diversity into the same shape as the homogeneous case.

### The provider catalog grows; the Provisioner abstraction holds

*Absorbed from `2026-06-03T10-05-00--multi-cloud-provider-catalog.md` (iplane PRs 152, 153, 154, 155).*

Chapter~\ref{ch:control-plane-v01} introduced the Provisioner abstraction with one production provider (RunPod) and asked the reader to take it on faith that the interface would absorb a second cloud cleanly. This beat cashes that check. Vast.ai and Lambda Labs land as two new provider packages; no interface changes were needed; the existing CLI verbs, the demos, and the deployment scaling all work against three providers with one env var.

Two provider shapes show up. Vast is a marketplace --- search for offers matching a resource spec, take an on-demand one or place a bid. Lambda Labs is a fixed catalog --- pick a SKU from a known list, place the order. Both satisfy the same provisioning shape because the wire-level differences (where the search step lives, how regions are exposed, how reliability scores get filtered) live inside each provider's package. The chapter's payoff is the abstraction holding shape across two genuinely different APIs without bending either to look like the other.

The probe-first methodology is worth a sidebar. Vast was implemented speculatively first --- read the docs, write the client, find out at integration-test time that the search endpoint expected POST not GET, that the query parameter needed wrapping, that the GPU name uses spaces instead of underscores. Lambda Labs was probed first --- curl the API, see how it actually responds, then write the Go client. Lambda Labs's integration worked on first commit. The engineering principle the chapter teaches is that documentation is hopeful; the wire is honest. When integrating with an unfamiliar wire contract, curl the API before writing the client.

`IPLANE_PROVIDER` is a small operator-ergonomics win. The env var sets the default provider for every CLI verb and demo; operators previously had to pass `--provider runpod` (or the relevant flag) on every invocation. When unset, the default stays RunPod, preserving Chapter~\ref{ch:control-plane-v01}'s behavior. Per-provider API-key env vars (`RUNPOD_API_KEY`, `VAST_API_KEY`, `LAMBDA_API_KEY`) follow the same shape. Adding a fourth provider in the future means writing one new provider package and registering one new API-key entry --- the CLI and demos pick it up automatically.

An operator running these by hand would maintain three provider-specific scripts --- a RunPod shell wrapper, a Vast curl recipe, a Lambda Labs CLI call. Each script encodes its own auth shape, its own search-vs-catalog pattern, its own state-file format for tracking spawned instances. The principle the chapter teaches is the *unification under the Provisioner abstraction* --- adding a third provider is a few hundred lines of one new package, not a refactor of the control plane. Chapter~\ref{ch:control-plane-v01}'s design earns its keep here.

## Act structure

Filled as remaining markers drain. The three beats from `master_outline.md` map roughly:

- **Act 1** --- The data-path problem. Why Ch 6's "iplane out of the data path" invariant cannot survive multi-tenant workloads. Sets up the router and motivates the shift to a long-lived control plane.
- **Act 2** --- Beat 1: the router primitive. Opens with the conceptual claim that control plane and data plane are separable even when co-located. Teaches the two URL shapes (flat for OpenAI-SDK compat, deploy-id for explicit dispatch) and the streaming-through-a-thin-proxy lesson. Lights up the request-rate / latency / token-throughput panels Ch 6 PR 52 honestly removed --- the chapter's first "remember those?" structural callback. Closes with a short interlude on lifecycle hygiene: now that the daemon is long-lived and the router emits activity, idle-TTL reaping protects the operator's wallet without operator discipline, and the explicit-activity-signals lesson generalizes beyond TTLs.
- **Act 3** --- Beat 2: queue and scheduler. Opens with backpressure as the chapter's first formal model --- bounded queue, M/M/k/N, the 503 + Retry-After contract with overloaded clients. Teaches tenant assertion (operator-asserted via header today, real auth in Part V) and priority lanes (INTERACTIVE / BATCH) as iplane-side abstractions that stop at the proxy boundary --- engines stay policy-blind. The scheduler's strict-priority dispatch makes "interactive cuts ahead of batch" the chapter narrative; batch starvation under interactive saturation is the point, with weighted-RR and aging as v0.3 follow-ups. Within a lane, fair-share lands via per-tenant sub-queues and weighted lottery --- the dispatch ratio under saturation converges to the configured tenant weights. Closes with the three-observability-signals frame (gauge, histogram, span attribute) for the queue cell, then ties the router's per-deployment in-flight cap to Ch 5's `max-num-seqs` and points forward to Beat 3 fan-out as the answer when one engine becomes the throughput limit. Beat 2's live walk lands at Demo 05 (two parallel `iplane load` clients against one deployment), where the queue depth and wait-p95 panels diverge in real time and the chapter's narrative claims become visually undeniable.
- **Act 4** --- Beat 3: replicas as fan-out. Opens with the indirection moment --- one stable deployment name, N possibly-changing engines behind it --- that pays off Beats 1 and 2. Teaches `iplane deployment scale` as the operator's primary surface for changing capacity; the DEGRADED aggregate state as the v0.2 answer to partial provisioning failure; scale-down deferred to v0.3 after drain-and-destroy design. The router fans out across the healthy replicas via round-robin (default chosen for its lack of per-replica state), composing with the partial-failure model so the operator never has to tell the router which replicas to skip. A per-replica health checker closes the operational-maturity loop --- observe via probes, label declaratively, react passively in the router --- and per-replica metrics restore decision visibility on top of Beat 1's basic visibility. Heterogeneous fleets across providers (RunPod, Vast, Lambda Labs under one deployment ID) are the chapter's differentiator beat, with a unified API shape that lets the homogeneous case be a degenerate form. The multi-cloud provider catalog makes the differentiator concrete --- RunPod, Vast, and Lambda Labs land as new packages without interface changes, with marketplace and fixed-catalog provider shapes both satisfying Ch 6's Provisioner contract. Beat 3's live walk lands at Demo 06 (scale 1 → 2 → 3 against the same deployment), where the throughput curve renders the plateau-at-1, near-linear-at-3 headline shape. Closes on the seam to Ch 8's prefix-cache-across-replicas.

## Demos

The chapter's hands-on spine. One demo per beat; all three share a single `iplane serve` daemon and a single registered deployment via the detect-and-reuse pattern.

### Demo 04 --- Router in path (Beat 1 closer)

*Absorbed from `2026-06-02T10-05-00--demo-04-router-in-path.md` (iplane PR 127).*

Lives at `examples/04-router-in-path/`. The reader runs `iplane serve` once, then the demo attaches as a client, detects an existing running deployment (or creates a new pinned one), and exercises both URL shapes against it: a sanity `GET /v1/<deploy-id>/v1/models` through the deploy-id URL, then a chat round-trip through the flat URL. The dashboard panels populate from the load step; a trace shows the chain from client through router to engine. The recorded transcript at `RUN.md` is the read-only path for readers who don't want to spend the few cents the live run costs on RunPod.

Narrative moments worth highlighting in the chapter prose:

- The two-URL-shape toggle exercised against the same deployment, making the design choice tangible.
- The dashboard light-up --- the visible payoff of "iplane is now in the data path," paying off the Ch 6 PR 52 callback.
- Detect-and-reuse as the seam that lets demos 4, 5, 6 share one deployment. Without it, every demo pays bringup cost; with it, the reproduction story is "bring up the daemon and the deployment once; everything else attaches to them."

Don't re-document the demo steps in chapter prose --- point at the README and walk only the moments worth narrating.

### Demo 05 --- Fair queueing under two-client load (Beat 2 closer)

*Absorbed from `2026-06-02T10-08-00--iplane-load-flags-demo-05.md` (iplane PR 136).*

Lives at `examples/05-fair-queueing/`. Reuses the deployment from Demo 04. Two parallel `iplane load` processes hit the same deployment with different priority and tenant headers --- the default profile is `alice/interactive/5rps` vs `bob/batch/20rps`. Bob hammers harder, but alice's traffic is INTERACTIVE class, so strict priority cuts her requests in ahead of his. Fair-share-within-a-lane is not exercised here (only one tenant per class); Demo 05 isolates the between-lane priority story.

Three panels and one trace make the design tangible:

1. *Queue depth panel* --- bob's batch lane grows; alice's interactive lane stays near zero.
2. *Queue wait p95 panel* --- alice sub-100ms; bob climbs to seconds.
3. *JSON summaries from `iplane load --output json`* --- alice's `latency_p95_ms` bounded; bob's not. Same story as the wait-p95 panel, read straight from the load tool.
4. *A Tempo trace filtered to batch traffic* --- open one and point at the `iplane.queue.wait_ms` span attribute. The trace is the per-request explanation of the aggregate p95 panel.

`iplane load` is the chapter's benchmark tool from this demo onward. It carries `--target` (deploy-id URL), `--priority`, `--tenant`, `--stream`, `--output json`. An operator could substitute `wrk`, `hey`, `k6`, `locust`, or a curl-in-a-loop --- the chapter teaches the workflow (assert priority and tenant client-side, hit the router, observe what diverges), not the tool. iplane load is the version that already understands the chapter's URL shapes and headers, so it stays out of the way of what the demo is teaching.

The README's "if the gap does not appear" troubleshooting section is worth lifting as a callout. Each named failure mode points at one real misconfiguration with a one-line fix. This is operator-friendly demo design --- rather than hide failure modes, name them with diagnoses.

### Demo 06 --- Multi-replica throughput curve (Beat 3 closer)

*Absorbed from `2026-06-03T10-06-00--demo-06-multi-replica-throughput-curve.md` (iplane PR 157).*

Lives at `examples/06-multi-replica/`. Reuses the deployment from Demos 04 and 05 --- the operator runs Demo 04 once to bring up the pinned deployment, then 05 and 06 attach to it. The script drives the same deployment through `iplane deployment scale 1 → 2 → 3` while `iplane load` snapshots throughput between each step. The headline shape is **plateau at 1, near-linear at 3** --- the chapter's payoff for everything Beat 3 introduces.

Three operational details deserve callouts in the chapter prose.

The script does a belt-and-suspenders healthy-count check after each scale. The CLI's `iplane deployment scale --wait` already blocks until terminal aggregate state, but the script also polls `iplane deployment describe -o json` for the healthy-replica count before taking the next snapshot. A partially-failed scale-up (3-of-4 healthy) would otherwise contaminate the next snapshot. The principle is *demos should self-document* --- readers see both layers and learn what the CLI flag does and what the operator-level check looks like.

The script has a saturation detector. At replicas=1, if `actual_rps / target_rps >= 0.95`, one replica is not being pressed at the configured DEMO_RPS --- the scale-up will not reveal headroom because there is not any. The script prints a hint suggesting the operator bump DEMO_RPS. The principle is *demos should self-diagnose when their assumptions are violated*. Same energy as the probe-first sidebar from the multi-cloud beat.

The mock backend caveat is worth a one-paragraph honest disclaimer. The mock completes requests in microseconds, so per-replica ceiling is tens of thousands of RPS and the scale-up does not bind. The script runs cleanly against mock (proving the plumbing --- scale verb, router fan-out, healthy-count poll), but the throughput-curve story only renders against `engine: vllm`. The chapter should be explicit so readers on a CPU-only laptop see expected behavior, not a confused result.

Each row of the output table pays off one of Beat 3's stable facts. At one replica, the engine is the bottleneck (Beat 2's bounded-queue model holds). Scaling to two pays off the indirection (router fans out, queue drops). At three, the curve approaches the target rate, and the control plane has absorbed what would have been a manual N-pod fleet.

## Pattern callouts

The chapter introduces and names (filled as markers drain):

- *Thin primitives over custom forwarders* --- use well-tested standard tools rather than rebuilding them. The router stays small because the proxy primitive does the wire work.
- *Operator-visible URL shape with an explicit-dispatch escape hatch* --- the default URL teaches the simple model; the explicit URL is one path segment away. Generalizes to many CLI and API designs.
- *Explicit activity signals over implicit ones* --- when designing a freshness or activity indicator, the writer must declare it. Read-only access does not extend the lease. Generalizes beyond TTLs to cache freshness, session timeouts, and lock leases.
- *Detect-and-reuse over recreate* --- when multiple demos or scripts target the same logical resource, check for an existing one before creating a new one. Keeps the reproduction story coherent and amortizes bringup cost across runs.
- *Bounded buffers and early refusal over unbounded queueing* --- backpressure as a first-class signal beats latency growth and cascading timeouts. Generalizes to any service with finite capacity downstream.
- *Abstractions stop at the proxy boundary* --- control-plane concepts the downstream service doesn't consume must not leak through. Keeps the downstream policy-free and metric-cardinality-bounded.
- *Request-level policy over per-resource policy* --- when policy is a property of "what's being asked for," put it on the request, not the resource. The resource stays policy-blind and reusable across policies.
- *Within-lane fairness via stateless lottery, not deficit accounting* --- same long-run convergence with less state. The chapter's example of choosing the simpler algorithm when the simpler one suffices.
- *Per-tenant capacity over shared-lane capacity* --- buy isolation with bounded extra memory. One bursty tenant cannot squeeze others out.
- *Three observability signals for one cell* --- gauge for now, histogram for distribution, span attribute for individual request. Match each to a distinct operator question.
- *Name expected failure modes with their fixes* --- operator-friendly demo design surfaces the three or four ways a demo can quietly look wrong, each with a one-line diagnosis. Generalizes to runbooks, README troubleshooting sections, and walkthroughs.
- *Stable name, changing backing* --- operators name the abstraction, not the instances; the control plane absorbs the bookkeeping of which slots are healthy. Generalizes to DNS, service discovery, and load balancer pools.
- *Partial success as a first-class outcome* --- at N>1, all-or-nothing semantics force operators into manual recovery for problems the control plane should absorb. DEGRADED names the in-between.
- *Default to least state* --- when picking a default mechanism, the one with the least operational state often makes the best teaching default; the principle stays visible. Smarter alternatives can swap in once the principle has landed.
- *Build policy where the inputs already are* --- when a decision needs multiple pieces of state, put the decision next to that state. Avoids a second source of truth that has to be kept synchronized.
- *Declarative state over event push* --- write to state; let consumers read it on demand. Avoids coupling lifecycles; sources of truth stay singular. Same shape as the deployment registry plus the unhealthy set.
- *Passive failure handling over active cancellation* --- when a downstream goes bad, stop sending new traffic; do not try to abort in-flight work. Bounded failure mode beats the cancellation-semantics morass.
- *One shape for everything; the simple case is a degenerate instance* --- when an API could split into a simple form and a general form, prefer the general form and let the simple form be the degenerate case (a list of length one, etc.). Saves a wire split that would leak usage patterns into the protocol.
- *Probe before you code* --- when integrating with an unfamiliar wire contract, curl the API before writing the client. Documentation describes the API the vendor wishes they shipped; the wire describes the API they actually shipped. Saves a debug cycle compared to speculative-then-debug.
- *Demos should self-diagnose when their assumptions are violated* --- a demo that silently produces flat output when its preconditions are not met confuses the reader. Build the self-check into the script and print a hint when the assumption fails. Generalizes to walkthroughs, benchmarks, and regression suites.

## Absorbed markers

- [x] 2026-06-02T10-00-00--capabilities-yaml-format.md *(absorbed: Ch 6 gets a full §6.13 Capability Snapshot, Ch 7's §7.6 carries a forward-looking convention note that fills in at `ch07-final` tag time; `\snapshottable{tag}` macro skipped in favour of hand-transcribed renders, `make check-snapshots` lint deferred to TODO.md)*
- [x] 2026-06-02T10-01-00--cpdp1-architectural-constraint.md
- [x] 2026-06-02T10-02-00--daemon-state-ownership-and-stores-tier.md
- [x] 2026-06-02T10-03-00--router-in-data-path.md
- [x] 2026-06-02T10-04-00--idle-ttl-reaper-touch-pin.md
- [x] 2026-06-02T10-05-00--demo-04-router-in-path.md
- [x] 2026-06-02T10-06-00--queue-scheduler-priority-tenant.md
- [x] 2026-06-02T10-07-00--fair-share-queue-observability.md
- [x] 2026-06-02T10-08-00--iplane-load-flags-demo-05.md
- [x] 2026-06-03T10-00-00--multi-replica-deployment-model.md
- [x] 2026-06-03T10-01-00--router-fan-out-across-replicas.md
- [x] 2026-06-03T10-02-00--per-replica-health-and-observability.md
- [x] 2026-06-03T10-03-00--heterogeneous-fleets-via-replicaspec.md
- [x] 2026-06-03T10-04-00--routing-policy-seam-for-ch8.md *(primary absorption in `chapter08/OUTLINE.md`; Ch 7 gets the cross-reference cleanup in the round-robin entry)*
- [x] 2026-06-03T10-05-00--multi-cloud-provider-catalog.md
- [x] 2026-06-03T10-06-00--demo-06-multi-replica-throughput-curve.md
- [ ] 2026-08-11T07-13-24--an-instrument-that-reports-success-without-measuring.md *(routed to `chapter06/OUTLINE.md` §2, since Ch 6 introduces readiness polling and this was an SSH-reachability probe. Ch 7's hook is the weaker one: §\ref{subsec:per-replica-health} polls `/health` and treats a pass as evidence, which is the same trust the marker says has to be earned. If the Ch 6 absorption lands well, one sentence here is enough. Deferred with the trio until Ch 6/7 get their voice pass)*
- [ ] 2026-08-11T18-30-00--i-do-not-know-has-to-be-a-value.md *(routed to `chapter06/OUTLINE.md` §3, which the publisher says is one section with the marker above rather than two. Relevant here because a quarantine decision is a reading like any other: a probe that cannot say "I could not tell" makes an unreachable replica and a sick replica the same event. Deferred with the trio)*
