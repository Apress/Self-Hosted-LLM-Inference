# Chapter 11: Capacity Across Providers

Working scaffold for the Ch 11 draft. Chapter 8 (`chapter08/index.tex`) is the model for a
control-plane-centric chapter's density, structure, and voice. Chapter 10 is the immediate
predecessor and the source of the fleet the router now has to choose between. Same rules as
Ch 7/8/9/10 (the `book-style-sweep` skill, now the sole voice authority, and the
memory entries).

**Drafting status (2026-08-12): skeleton in place, no prose.** `index.tex` is a correct shell
with the title, the label, drafted abstracts, and six empty act sections carrying their notes as
comments. Everything below the abstracts is still to write.

## Source-file reconciliation (done 2026-08-12)

Resolved, recorded so nobody goes looking for a problem that no longer exists.

The stale body is gone. `index.tex` was 295 lines of pre-restructure 30B material (`The 30B
Challenge`, `KV Cache Management`, `vLLM Optimization`, `Control Plane v0.2`) under a header
comment reading "Chapter 10: 30B Model Optimization". That content lives, properly written, in
`chapter09/`. It was replaced rather than edited.

**The label is now `ch:capacity`.** `ch:model-routing` no longer described the chapter. All six
external references moved in the same pass, and two of them needed rewording rather than a rename
because they promised material the reframe removed: `chapter06/index.tex:581` said Ch 11 "adds
workload-aware routing across deployments" (that is Ch 16's now), and the `prob:ch06-multi-model`
preview promised "the full version with cost-aware routing" (repointed at Ch 7's router). Ch 10's
closing paragraph was rewritten off the old mixed-fleet framing and onto capacity.

Do **not** confuse this with `chapter15/index.tex`, a separate 122-line stale stub titled
"Model Routing and Selection" (`\label{ch:routing}`) that `book.tex` includes as "Cost
Tracking", while `master_outline.md` says Ch 15 is Authentication and API Keys. Two
half-routing stubs exist; `chapter11/` is the live one because the cross-references point at
it. Sorting out `chapter15/` is Part V's problem, not this chapter's.

## Version / branch note (resolved 2026-08-09)

**Ch 11 is v0.3, with Ch 12.** This was genuinely unassigned until now, not merely undecided.
`RELEASE.md` mapped v0.3 to Ch 12–15, so the range started one chapter too late and Ch 11
belonged to no version at all. Corrected in `inference-plane` PR 218; `ROADMAP.md` and
`master_outline.md` already agreed on Ch 11–12. Consequences: Ch 11 closes on `ch11-final`
cut from `release/v0.3`, and it is the **first chapter on the v0.3 line**, so that branch has
to be opened before the tag (v0.2's `release/v0.2` line was opened the same way).

Note the precedence reversal, because it will come up again: for the Ch 10 move `RELEASE.md`
was right and `ROADMAP.md` wrong; for the v0.3/v1.0 ranges it was the other way round.
`ROADMAP.md` is now stated to be canonical for the mapping.

## What this chapter is about (reframed 2026-08-09)

**The through-line is hardware acquisition, not model semantics.** Ch 10 named the pattern
outright (`pattern:provision-connected-pool`): "The control plane provisions the connected pool,
and the engine shards across it." iplane's job is to make sure the engine has the hardware it
needs. What the engine does with that hardware is the engine's business.

An earlier version of this outline framed Ch 11 as routing requests across models by difficulty
and cost, deciding what an answer is worth. That was the wrong side of the line. Asking the
control plane to judge what a prompt needs is the same class of move as router-orchestrated
prefill/decode disaggregation, which this book explicitly declines. Different mechanism, same
boundary violation. It also would have made this the book's third routing chapter after Ch 7 and
Ch 8, which is the surest way to read as repetition.

**What follows Ch 10 cleanly is capacity.** Ch 10 rents one connected pool from one vendor.
Ch 11 is what happens when one vendor cannot supply it. The pool is out of stock in the region
you need, or priced badly today, or reclaimed underneath you mid-serve. So:

- **Cross-provider search.** A topology requirement resolved against several catalogs at once,
  rather than one. Ch 10 filters offerings within a provider; Ch 11 filters across them.
- **Price as a placement input.** Not a report you read afterwards. The same pool at two vendors
  is the same capability at different money, and the resolver should know that.
- **Capacity that disappears.** Spot and preemption make "the hardware went away" an ordinary
  event. Draining and re-placing a deployment becomes routine rather than incident response.
- **Failing across hardware classes.** Ch 7 quarantines a sick replica and routes to an
  identical one. Here the fallback may be different hardware at a different price, so degradation
  is a decision rather than a reflex.

The transferable lesson, which is the filter this book applies: once capacity is something you
rent from a market rather than something you own, placement becomes a continuous decision instead
of a one-time one.

**What moved out.** Workload- and quality-aware model routing (small model for short prompts,
large for hard) is now an advanced-book topic, named in Ch 16 alongside P/D disaggregation. It is
a good subject. It is just not this book's, because it asks the control plane to reason about
what a model is for.

## Chapter arc (from `master_outline.md` Ch 11 row, 2026-08 reframe)

> Ch 10 rents one connected pool from one vendor. This chapter is what happens when one vendor
> cannot supply it: the pool you need is out of stock, priced badly, or reclaimed underneath you.
> Cross-provider capacity search resolves a topology requirement against several catalogs at once;
> price becomes a placement input rather than a report; spot and preemption make capacity
> something that disappears while you are using it, so draining and re-placing a deployment
> becomes routine rather than exceptional. Rests on the separation the control plane has kept
> since Ch 6, that provisioning capacity and serving traffic are different jobs, which is also
> what lets the fleet include engines the control plane never provisioned. Health-aware routing
> extends Ch 7's per-replica quarantine to the case where the fallback is not an identical replica
> but different hardware at a different price. The engine stays opaque throughout: this chapter
> changes where the hardware comes from, never what the engine does with it.

## What the resolver actually does today (read from code, 2026-08-12)

Read this before drafting any act. The gap this chapter closes is **narrower and more precise**
than the rest of this outline assumed, and knowing that makes the acts sharper rather than
smaller.

**The search is exactly one catalog wide, and the operator picks which one.** `Spec.provider` is
required, `CreateInstance` resolves it by map lookup (`internal/provisioners/service.go:246`), and
an unknown name is an `InvalidArgument`. No code path lets the resolver choose a vendor.

**Inside one adapter the resolution is already real.** `MatchSKUs(reqs)` filters the static catalog
on VRAM / disk / RAM floors, drops families that could never carry the requested fabric, **sorts
ascending by price**, and caps at `MaxSKUsPerRequest = 5`. Catalogs are small (roughly 18 RunPod,
19 Vast, ~10 Lambda).

**Re-checked 2026-08-15: the three copies are gone.** The hoist #266 asked for has landed. All
three adapters now project their own rows onto `skucatalog.Entry` and delegate to
`skucatalog.Match(entries, reqs, mode)`; no adapter-local sort survives. The package doc names
Ch 11 as half its rationale, since one algorithm over N catalogs is exactly what #280 needs.
**The issue is still OPEN even though the code is done** — worth closing or re-scoping before
Act 3's tickets get filed on top of it.

The `FabricMode` enum on that shared resolver is Act 2's comparability wrinkle written into the
type system: `FabricDeclared` (RunPod, Lambda) treats the catalog as the last word and drops a
bridge-capable card as UNKNOWN, `FabricPrefilter` (Vast) drops only what could never satisfy and
lets the per-offer reading decide. Act 2's prose already matches this; no rewrite needed.

**A real drift story landed with it, and it is usable.** The package doc records that RunPod
learned during the 72B cold-start work that `min_disk_gb` must not filter the catalog, while Vast
kept filtering on it for another two chapters (#281, fixed in #282 at `d80dda2`). That is genuine,
dated, checkable friction about parallel copies drifting, which is the sort of thing the voice
wants and the sort of thing that must not be invented. Candidate for Act 3's design-choices
material or a `generalize, do not parallel-ship` aside.

Two consequences that change the acts:

- **Price ranking is not new, so Act 3 must not pretend it is.** `sort.SliceStable(...
  PriceUSDPerHour ...)` has been there all along. The act is that price stops being *comparable*
  once candidates come from different vendors, and stops being a single number at all once one
  vendor charges per token. #194 is the cross-catalog version of something the single-catalog
  version already does.
- **Heterogeneous fleets are already expressible, just not discoverable.** `ReplicaSpec.provider`
  is documented "Required" (`protos/provisioner/v1/types.proto:731`), so one deployment already
  draws replicas from RunPod, Vast, and an external engine at once. The operator *declares* that
  mix. Nothing searches for it. **Act 2 is therefore not introducing heterogeneous fleets, it is
  introducing finding one.**

**The comparability wrinkle Act 2 needs.** Vast treats fabric as a pre-filter rather than a
decision, because a Vast SKU is a set of live offers from independent hosts, so the catalog only
drops families that *could never* satisfy and the reading on the picked offer decides. RunPod's SKU
is roughly a catalog entry, so its match is one-stage. "The same offering at two vendors" is not a
well-formed notion until something defines it. This is what makes Act 2 real content rather than a
fan-out loop, and it is the same observation #260 made from the demo side.

**The one-sentence framing for the whole chapter.** Every widening here comes from removing one
required field, and the consequences of removing it are the chapter.

## iplane surface state (honest, checked 2026-08-09)

- **Shipped foundation this chapter builds on:**
  - **The `external` (non-owning) provider** — shipped in Ch 8 (PR 183) as the GPU-free demo
    harness. Registers a RUNNING deployment pointing at engines the operator runs themselves,
    with no provisioning and no lifecycle ownership. This is already the "route to something
    iplane did not create" primitive; Ch 8 used it as scaffolding, and Ch 11 is where it
    becomes the point.
  - **The routing-policy seam** (PR 148, Ch 7) with two implementations behind it
    (`round_robin`, `prefix_affinity`). Ch 11's policies are the third and fourth users of a
    seam that has now paid for itself twice.
  - **Heterogeneous fleets via `ReplicaSpec.replicas`** (Ch 7 Beat 3) — one deployment already
    draws replicas from several providers, so "not all backends are alike" is partly modeled.
  - **Per-replica health checking and quarantine** (PR 141) — the health-aware third of the
    chapter's remit largely exists already; check before writing it up as new.
### Ticket state (filed 2026-08-12, label `cross-provider`)

The working model for this chapter is file-what-the-act-needs, draft the act, revise the tickets
or absorb whatever drifted, then move to the next act. So this list is deliberately not the whole
chapter's ticket set. Acts 4 and 5 get theirs when drafting reaches them.

| # | What | State |
| --- | --- | --- |
| 279 | `[epic][ch11]` Capacity across providers | epic, tracks the below |
| 280 | Resolve one requirement against several catalogs at once | filed, P1, Act 2's headline |
| 194 | Cost-aware placement, cheapest-fit ranking | **pre-existing**, rescoped from `[ch9]` to `[ch11]`. Act 3. Its scale-to-zero-fast-wake half is explicitly not this chapter |
| 260 | Inspect provider candidates without renting one | **pre-existing**, raised P2 to P1. Act 2 cannot be demoed honestly without it |
| 266 | Hoist the SKU resolver out of the three adapters | **done in code, issue still open** (checked 2026-08-15). `internal/provisioners/skucatalog` now carries the algorithm and all three adapters delegate. Close or re-scope it |
| 182 | HostedAPI: `external` plus outbound auth plus per-token cost | **pre-existing**, Act 3's other half. Generalize `external`, do not ship a sibling |
| 145 | Scale-down drain semantics and in-flight handling | **pre-existing**, the drain primitive Act 4's migration reuses |

**The lesson from filing these.** Three of the four things that looked like new work already existed
under other chapter labels, and one of them (194) had a note saying its book treatment belonged in a
later cost chapter. Check the open list before filing, because this repo's backlog is where earlier
chapters put things they deliberately did not do.

Still unfiled, on purpose, until the drafting reaches them:

- **Spot / preemption handling** (Act 4). Named as a v0.3 cross-cutting feature in `ROADMAP.md`:
  cost-aware deployment on spot with graceful preemption, re-provision on a new instance, drain
  in-flight, cut over. #194's own text already anticipates it as a follow-on.
- **Migration primitives** (Act 4/5). Also a v0.3 cross-cutting row: move a deployment between
  providers, drain-and-re-provision, `iplane deploy migrate --to <instance>`. Builds on #145.

- **Open design question carried from `ROADMAP.md`:** cross-provider warm cache. Ch 9 deferred
  `S3Store`/`GCSStore` object-store staging precisely because a pinned volume is scoped to one
  provider and one region. Moving a deployment across providers makes that deferral bite, so
  `docs/design/0004-cross-provider-warm-cache.md` becomes load-bearing here rather than optional.

### Deferrals inherited from earlier chapters (checked against `capabilities.yaml`, 2026-08-12)

Three entries carry `moved_to: v0.3`, which means they land inside this chapter's acts rather
than merely near them. Naming them here so they are not discovered mid-draft.

| From | Capability | Lands in |
| --- | --- | --- |
| `ch09-final` | `S3Store` / `GCSStore` object-store staging. A pin is provider-scoped, so it buys nothing across providers or regions. Per-provider volume-create matrix worked out in `docs/design/0004-cross-provider-warm-cache.md`. | Act 4, and it is the reason re-placing elsewhere costs more than it looks |
| `ch09-final` | Remote `--service-url` pin. `iplane model pin` is in-process only. | Act 4, minor, mention only if the drain story needs it |
| `ch10-final` | Failed-node attribution. Recording which node took a member down so a replacement pool avoids that host. Identity plumbing ships; acting on it at placement time does not. | Act 5, where the fallback is chosen rather than reflexive |

`ch10-final`'s cross-node pool provisioning deferral is the fourth, and it is Act 1's opening
rather than an inherited chore. See the Act 1 section.

## Boundaries (keep the seams honest)

- **Ch 7 owns** the queue, fairness, and fan-out across replicas of one deployment. Ch 11 does
  not re-teach queueing.
- **Ch 8 owns** cache-locality routing and the engine-as-opaque-KV-domain stance. Ch 11 keeps
  that stance completely: it changes where hardware comes from, never what the engine does with it.
- **Ch 9 owns** the warm cache. Ch 11 inherits its provider-scoped limitation as a real problem.
- **Ch 10 owns** topology matching within a provider and the registration channel that tracks the
  fleet. Ch 11 widens the search across providers; it does not redo the topology concept.
- **Ch 12 owns** putting Part III together for a 70B deployment. Ch 11 supplies the capacity
  mechanics; it should not turn into a deployment guide.
- **Ch 15 owns** client-facing auth. The outbound auth in issue 182 is iplane to provider, not
  client to iplane. Say so once so the two do not get conflated.
- **Ch 16 (advanced-book map) owns** the topics this chapter deliberately sheds: workload- and
  quality-aware model routing, and router-orchestrated prefill/decode disaggregation. Both are
  control-plane-reasons-about-model-semantics moves, which is the line this book does not cross.

## Chapter-balance note

Ch 10 is control-plane-centric and Ch 11 is too. Under the old model-selection framing that was
a real risk, and the mitigation was to lean an act into model knowledge. Under the capacity
framing the answer is different and better: the non-iplane system concept this chapter teaches is
**the economics and failure behaviour of rented capacity**, which is transferable to anyone
running on cloud infrastructure and owes nothing to iplane. Spot preemption, price as a placement
input, and drain-and-re-place are systems concepts first and iplane features second.

The filter from memory `project_engine_vs_controlplane_chapter_balance` is "teaches a non-iplane
system concept?" and capacity economics passes it cleanly. Keep the manual-versus-iplane frame
throughout: you could shop three provider consoles by hand, keep a spreadsheet of prices, and set
a calendar reminder to check whether your spot instance survived the night. The principle would be
identical.

## Target shape (provisional)

~20 pages at Ch 7/8/10 density: ~7k words, ~6 diagrams, a Problems section, and a Capability
Snapshot. Hardware: several providers, at least one spot or preemptible pool, and at least one
capacity source iplane does not own.

**Demo-cost warning, and it is a real risk.** Ch 10 stayed reproducible because `external` plus
`iplane mock-engine` run GPU-free. Cross-provider price search and preemption are harder to fake
convincingly, and a preemption demo that never actually gets preempted teaches nothing. Settle
early which acts can run against a mock catalog with synthetic prices and which genuinely need
accounts at two or three vendors. If preemption cannot be demonstrated honestly on a budget, say
so in the chapter rather than staging it.

## Section plan (draft, to be firmed up)

### Act 1 — The requirement you can state and cannot fill (~10%)

**Open on Ch 10's cross-node deferral.** This is the strongest bridge available and it is already
written into `ch10-final`'s Capability Snapshot, so it costs nothing to pick up. `--fabric
inter-node` is expressible and gets rejected at validation rather than falling through to "no
matching SKU", which would read as capacity an operator could wait out. The blocker is market
segmentation rather than engineering. No provider in the commodity rental tier exposes a
cross-node pool through an API. Those clusters exist and are advertised at thousands of gigabits,
and they are ordered through a web console. Hyperscalers do sell coherent multi-machine capacity
programmatically through placement groups and capacity reservations, so reaching that tier needs
an adapter Ch 10 did not write.

The generalisation is the act's job: **a requirement one vendor cannot fill is not the same as a
requirement that cannot be filled.** Ch 10 ended with a working topology filter and an implied
assumption underneath it, that a pool you can describe is a pool you can rent. That assumption is
where this chapter starts.

Then the ordinary cases, which are more common than the exotic one and make the same point. The
eight-card pool is out of stock in the region you need, or it exists at three vendors at three
prices, or you had one and it went away.

Note the framing order. One vendor is a single point of **supply**, and the argument for going
multi-provider is availability first and price second. Leading with price makes this sound like a
procurement chapter, which would undersell it and would also make Act 3 redundant.

### Act 2 — Resolving a requirement against several catalogs (~25%)
The search widened. Ch 10 filtered offerings inside one provider; here the same topology
requirement resolves against several at once. What makes offerings comparable across vendors and
what does not, and why price cannot be the only ranking key once regions, egress, and warm-cache
locality differ. Manual path: three browser tabs and a spreadsheet.

### Act 3 — Price as a placement input (~20%)
Cost stops being something you read afterwards and becomes something the resolver ranks on. The
per-hour versus per-token distinction lands here, because a hosted API is a capacity source whose
price is shaped differently, and that breaks the comparability of every cost number the book has
used so far. Reconciling the two units is real content.

### Act 4 — Capacity that disappears (~25%, the chapter's spine)

**Drafted 2026-08-15, and the code changed what the act could claim.** Read before extending it.

- **The drain ships.** Quarantine then wait, two-minute default, and the number is justified by
  token generation rather than by HTTP convention. The graceful part is deliberately split from
  the release, which is what lets fleet drain and scale-down share one path. Preemption is a third
  caller of that same path and the only one that does not choose its moment.
- **The trigger does not ship, and it is worse than "not wired yet".** iplane cannot rent an
  interruptible machine at all. No verb, no requirement field, and the one provider whose API has
  the flag is never sent it (it appears once in the tree, on a wire struct, unset). There is also
  no reclaim-notice path and no re-place-on-preemption.
- **The cost model is further along than the acquisition path**, which is a genuinely funny and
  usable asymmetry. A variable-spot billing mode already exists and reports the current quoted
  rate rather than pretending a fluctuating rate is fixed. We can account for spot capacity we
  cannot buy.
- **Demo question, settled by the code rather than by budget.** There is no preemption walkthrough
  because there is nothing to preempt, not because a reclaim is expensive to wait for. Drafted as
  a plain statement, per the outline's own instruction not to stage one. A timer-based fake would
  teach the drain (already covered) while implying a trigger that does not exist.
- **Ch 9's warm cache bites, and the findings are measured** (design doc 0004, probed live
  2026-07-28/29). Mounting a volume is already provider-agnostic. Creating and staging one is an
  optional capability that exactly one vendor implements. On a second, persistent storage exists
  but cannot be created through the API at all, so it is a dashboard operation. On a marketplace
  the host disk is mostly ephemeral, so there is nothing durable to pin to. That makes re-placing
  cost the cold start again on the worst possible occasion.
- Names `pattern:place-continuously-not-once`.

**Still to write in Act 4:** a figure (Acts 3 and 4 are both figureless, against the two-to-four
per major section convention), and the tickets. Spot acquisition, reclaim-notice handling, and
migration verbs are all still unfiled, which is correct under the file-what-the-act-needs model
now that the act is drafted and its gaps are precise.

Spot and preemption. The hardware going away becomes an ordinary event rather than an incident,
which changes the control plane's job from placing once to placing continuously. Drain, re-place,
cut over. This is where Ch 10's fleet tracking pays off, because you cannot drain what you cannot
see, and where Ch 9's provider-scoped warm cache bites, because the new pool is somewhere the
pinned volume is not.

### Act 5 — Failing across hardware classes (~10%)

**Drafted 2026-08-15.** Checked Ch 7 first, as this section instructed. Ch 7 §per-replica-health
already covers observe / label / react in full, so Act 5 names that loop in one sentence and
spends its length on the three things that are actually new:

- **The survivor may not be a twin.** Ch 7's fallback was another identical replica, so the only
  cost was a little capacity. Across vendors the survivor can be a different card class at a
  different price in a different region, and moving onto it can mean paying Ch 9's cold start
  because the weights are staged elsewhere. Degradation becomes a priced decision somebody has to
  have made in advance.
- **Backends do not emit the same signals** (absorbs the `backends-differ-in-what-they-can-admit`
  marker). The design work sits where a signal is missing rather than where it says a backend is
  sick.
- **The trap, and it is the best thing in the act.** Inferring death from slowness is exactly
  wrong when slow is the normal case: a cold start pulls an image and then weights and genuinely
  runs to many minutes, so a liveness rule tuned to a web service's patience kills a healthy
  deployment mid-load and re-places it somewhere that does the same thing again.
- **Failed-node attribution**, the `ch10-final` deferral. The identity is plumbed and placement
  does not read it, so the same bad host can be rented twice running. Named as an open gap.

Deliberately **not** re-run here: the silence-is-not-evidence argument and the asymmetric-cost
rule, both spent at length in Act 2 §11.2.2. Act 5 cites §11.2.2 and raises the stakes from money
to killed work, which is the promise §11.2.2 makes when it forward-refs this section.

Ch 7 quarantines a sick replica and routes to an identical one. Check what that already covers
before writing this as new. The genuinely new part is when the fallback is not identical: different
GPU class, different price, different region. Degradation becomes a decision with a cost attached.

### Act 6 — Capability Snapshot + close

**Drafted 2026-08-15, and it is deliberately not the usual shape.** There is no `ch11-final` tag
and no `release/v0.3` branch, so `capabilities.yaml` has no entry to transcribe. Rather than leave
the section empty or invent an entry for a tag that does not exist (which the chapter itself argues
against doing), it carries the parts that do not depend on a tag:

- **What already runs** (read-only capacity inspection, price ranking within a catalog, graceful
  drain and whole-member release). Worth stating plainly, because a chapter this much about gaps
  can otherwise read as though nothing works.
- **What the chapter names and does not have** (cross-catalog resolution, reclaimable-capacity
  acquisition, re-placement after a drain, and the open sizing-vs-silent-vendor question).
- **The four patterns**, all with live `\S\ref{}` back-links.
- The hand-off to Ch 12.

`make check-snapshots` does not complain, since it iterates YAML entries and there is none for
ch11. When the tag is cut, the capability list gets transcribed above the patterns block and the
opening sentence gains the tag name exactly once, glossed with its release, per the convention.

### Tickets filed while drafting (2026-08-15)

Per the file-what-the-act-needs model, now that Acts 4 and 5 are written and their gaps are
precise:

| # | What | Note |
| --- | --- | --- |
| 288 | Acquire reclaimable (spot/interruptible) capacity | Blocks the rest of Act 4. Requirement shaped as a property, not a vendor's noun, the way `--fabric` avoided `--needs-nvlink` |
| 289 | Reclaim notice to re-placement, wired onto the existing drain | Depends on 288. Notes that a reclaim deadline is shorter than a cold start, so the replacement probably has to start before the drain |
| 290 | `iplane deployment migrate` between providers | The no-deadline sibling of 289, and the tractable one to build first. Was a `ROADMAP.md` row that had never been filed |

Rescoped rather than duplicated, per the lesson from the last round of filing:

- **#214** (failed-node attribution) commented, asking for `[ch10]` to `[ch11]`. Act 5 uses it.
- **#260** (inspect candidates without renting) commented: done in code, `iplane capacity` ships,
  same state #266 was in. The cross-catalog half is #280.

### Section coverage (the every-section-needs-both rule)

| Section | Figure | Runnable |
| --- | --- | --- |
| 11.1 | refusal capture + single-point-of-supply | `iplane instance create` (real) |
| 11.2 | widened search, catalog shapes, silence ranking, capacity run | `iplane capacity` (real, live 2026-08-15) |
| 11.3 | price-units panel | `deployment deploy --provider external` (real), `--provider hosted` (fails) |
| 11.4 | reclaim path | `iplane fleet drain` (real), `--interruptible` (real rejection) |
| 11.5 | watch capture, cold-start timeline | `iplane deployment watch` (real) |

Stub until `ch11-final` is cut from `release/v0.3`. Hand off to Ch 12, which spends this chapter's
mechanics on one real 70B deployment.

## Patterns to name (candidates, `\label{pattern:<slug>}` at first naming)

- **One vendor is a single point of supply.** The availability argument for multi-provider, which
  is not primarily about price.
- **Price is a placement input, not a report.** Cost belongs in the resolver, not the postmortem.
- **Place continuously, not once.** Rented capacity can be reclaimed, so placement is an ongoing
  decision and draining is a routine operation rather than incident response.
- **Generalize, do not parallel-ship.** Issue 182's own instruction: HostedAPI is `external` plus
  auth plus price, so widen the existing provider rather than adding a sibling. A repo-shaped
  observation with a general point about seams.

## Absorbed from the iplane inbox

**What a missing fact licenses depends on what kind of fact it is** (2026-08-15, PRs 282/284,
marker `what-silence-means-depends-on-the-kind-of-fact`). Applied into Act 2 §11.2.2, drafted
2026-08-15. Sharpens `pattern:silence-is-not-evidence` rather than contradicting it: fail-closed
is right for facts that *bound the thing rented* (VRAM, interconnect) and is a live bug for facts
*ordered alongside it* (disk, system RAM, usually card count), where a catalog row carries a
typical default and not a ceiling. Named as `pattern:bounds-it-or-ordered-with-it`. Carries the
measured cost (a 100 GB disk ask skipping the 80 GB tier, roughly \$1.20/hr to \$2.30/hr, and the
150 GB a 72B at FP8 needs matching nothing at all) and the open trade-off, since a requirement
that cannot filter a silent vendor is silently unenforced on that vendor. Deliberately **not**
framed as a refactor, per the marker's own caution.

Note the drain order. This was taken out of FIFO because it is the only marker naming
`chapters: [chapter11]`, and its stated dependency (absence has to be a value, marker
`i-do-not-know-has-to-be-a-value`) is already satisfied in the book by Ch 10's fabric provenance
and §11.2.2's opening. That marker is still queued for its own placement decision.


**What unit does this provider actually rent** (2026-08-11, PR 252, marker
`modelling-a-provider-as-the-wrong-kind-of-thing`). The marker's own placement is Ch 6, beside the
capability pattern, and it is recorded in full in `chapter06/OUTLINE.md` §1. **Only the price half
belongs here, and only in Act 3.** A vendor was integrated on a wrong answer to a question nobody
asked out loud, because it rents containers and had been modelled as renting machines. Act 3 asks
the same question with money attached. A commodity provider rents an hour of a machine, a
marketplace rents an hour of somebody else's machine, and a hosted API rents tokens and no machine
at all. The unit decides whether two prices can be compared before any arithmetic happens, which
is why the per-hour versus per-token reconciliation is the act's real content rather than a
footnote. Take the question, leave the cascade-of-five-bugs anecdote to Ch 6, and do not re-teach
the capability seam here.

**Backends differ in what they can admit** (2026-08-10). A worked example of non-uniform backend
capability, which is this chapter's subject seen from the operations side rather than the price side.
When one control plane spans several backends, the capabilities are not uniform, and the interesting
design work is what happens where a capability is *missing*. Two rules fall out, both general:

- The absence of a signal is absence of information, never evidence. Same discipline the fabric
  provenance tiers need in Ch 10, arriving from a different direction.
- The costs of the two mistakes are asymmetric. Failing to notice a dead workload wastes a timeout;
  wrongly declaring a live one dead kills work that was fine. Where costs are lopsided, the default
  belongs on the cheap side.

The trap worth naming: the temptation is to infer death from slowness, which is exactly wrong when
slow is the normal case, since a large image pull genuinely takes many minutes. Fits Act 5
(failing across hardware classes), where the fallback is different hardware rather than an identical
replica.

## Open questions to settle before drafting

1. **Demo budget.** Which acts run on a mock catalog with synthetic prices, and which need real
   accounts at two or three vendors? Can preemption be shown honestly without waiting on a real
   reclaim? This shapes the acts more than anything else here.
2. **Does Ch 11 open `release/v0.3`,** and is that branch cut before or after drafting starts?
   Ch 11 is the first chapter on that line.
3. **Cross-provider warm cache.** Ch 9 deferred object-store staging to v0.3. Does Ch 11 pull it
   in, given Act 4 moves deployments between providers, or does the chapter name the gap and
   leave it to Ch 12?
4. **Ticket the spine** so it can land in parallel the way Ch 9's warm cache and Ch 10's
   203/204/205 did: cross-provider capacity resolution, spot/preemption, migration verbs. All
   `[ch11]` titles plus labels.
