# Chapter 15 working outline

**Status (2026-08-26): complete first draft.** The book's closing chapter. Five acts, 10 pages,
zero errors, zero overfull boxes, zero unresolved references.

Open question 1 was answered in the drafting: act 3 references the failure record as a single
collected paragraph and does not re-tell any incident, so the chapter does not become a clip show.
Open question 2 is still the author's, since act 4 says "a second book" without naming one.

Everything it needs already exists. No measurement is outstanding, because the chapter's job is to
say where the boundaries are, and Part IV spent three chapters finding them.


**Style sweep 2026-08-27.** Clean on every mechanical check and **fails the additive one**, which is
the only check the style skill says not to skip. Two uses of "we" and no parenthetical aside across
five sections, and nothing admitted as annoying. It reads as competent, accurate and airless, which
is the failure mode readers register as machine-written even when nothing else is wrong.

Five `% TODO(friction)` markers are in place at the spots that most want a real story, collected by
`make friction`. They cannot be filled without the author: the strongest one asks whether there is a
capability that got built and never exercised before the build-only-what-can-be-tried rule existed,
since Part IV's failures are all things that broke on contact and this rule is about things that
never made contact at all.

---

## What this chapter is for

Naming the boundary. Three boundaries, in fact, and they are different kinds of thing, which is
the structure.

1. **A hardware ceiling.** How large a model can you serve on something rentable, and what is
   immediately above it.
2. **An economic ceiling.** Past what point does renting stop making sense, and the answer depends
   on context length in a way the outline did not anticipate.
3. **A ceiling on what is worth building.** The build-only-what-can-be-tried rule, which the whole
   of Part IV is evidence for.

Then the map of what a second book would cover, and a close.

The abstract was corrected on 2026-08-26. It promised a sustained traffic level that turns the
arithmetic back in your favour, which exists at short context and does not exist at long, and
saying so is most of what Ch 14 bought.

---

## Section plan

Five acts, and the chapter should be shorter than the two before it. It is a closing argument
rather than an investigation.

### Act 1 - The ceiling in hardware (~22%)

What one rentable machine holds, honestly, with the instrument's own blind spot in view.

Eight cards is where commodity supply stops. Above that the market segments, and Ch 13 showed a
published schema with no cluster path in it and a launch call with no quantity field. Nobody who
will sell you a machine by the second will sell you two wired together.

So the ceiling is eight cards times whatever the largest card holds, which is a number that moves.
Be careful here: our own sampler could not see above 81 GB for weeks because it asked one memory
floor against a verb that returns the cheapest few offers. The honest statement is bounded by what
we could observe, and the chapter should say so rather than assert a number the instrument was
incapable of finding.

The arithmetic that survives regardless: the largest open-weight models need more than eight of
anything currently rentable, at four bits, and the gap is not large. That is the interesting part.
The ceiling is not far above the floor, and it moves upward faster than models grow, which is a
better closing observation than a fixed number.

### Act 2 - The ceiling in economics (~24%)

Ch 14 gives this act its content and the answer is sharper than the plan expected.

At short context the crossover exists and is computable. Take the floor, take a provider's price,
and the concurrency you need to sustain is arithmetic. State it as a method rather than a number,
because the number ages and the method does not.

At long context there is no crossover, because the curve turns over before it approaches a
provider's flat rate. No amount of traffic fixes it. That is the strongest single claim Part IV
produced and it belongs here rather than in Ch 14, because Ch 14 measured it and this chapter is
where it becomes advice.

The three questions that decide it for a real deployment: how long are your prompts, how much
concurrency can you actually sustain, and how much of your traffic shares a prefix. The third is
where prefix caching earns the chapter's strongest recommendation, because it is worth the context
multiplier itself and every other lever is worth a factor of four.

### Act 3 - The ceiling on what is worth building (~20%)

The build-only-what-can-be-tried rule, stated once and evidenced by the whole of Part IV.

A capability the control plane cannot exercise against a real provider does not get built. Part IV
is the argument: every defect that mattered was invisible until real money met real hardware, and
the ones that cost the most were invisible in the direction that costs money. Five defects from an
attempt to spend six dollars. A guard that destroyed a healthy rental. A cross-check with a hole in
it that exempted the one row that needed checking. A sampler that could not see the tier it was
built to watch.

The rule's real content is about what a demo is for. A capability with no way to be exercised is a
design document that compiles, and the book has spent fifteen chapters arguing that the difference
matters.

Pair with the manual-versus-tool framing one last time. You could have done all of this with shell
scripts and a text file. The principle would be identical. What a control plane buys is that the
things which fail quietly fail somewhere you can see them.

### Act 4 - What a second book covers (~22%)

The advanced map, from `master_outline.md`, and each item gets one clause on why this book could
not do it rather than a list of names.

- Router-orchestrated prefill and decode disaggregation. Ch 14 measured why it matters: separate
  the two and the externality goes away. This book kept the engine an opaque box, and this is the
  first thing that requires opening it.
- Workload- and quality-aware model routing.
- Speculative decoding and draft models.
- Multi-adapter LoRA serving.
- Multi-region capacity.
- Engine-image streaming and warm pools.

The disaggregation item is the one to lead with, because Ch 14 just produced the number that
justifies it, and a reader who understood the externality already knows why the next book starts
there.

### Act 5 - Close (~12%)

Short. What the reader can now do that they could not at Chapter 1, stated as capability rather
than as summary. The book's own rule turned on itself: everything here was tried, most of it broke
at least once, and the parts that broke are the parts worth having read.

No Capability Snapshot, since Part IV has no tag yet.

---

## Numbers this chapter cites

All through registry macros, so promoting a placeholder is one edit.
`\PartIVFitEightK` for the floor, `\PartIVCostFloorEightK` / `ThreeTwoK` / `OneTwoZeroK` for the
three measured points, `\PartIVPeakBatchEightK` / `ThreeTwoK` / `OneTwoZeroK` for the batch series.

Hardware figures are stated with their provenance and their uncertainty, per Ch 13's sampler
lesson. No number here should be quoted more confidently than the instrument that produced it.

---

## Open questions

1. **How much of the failure record act 3 re-tells.** Ch 13 already has the five defects and Ch 14
   has the guard. Act 3 should reference rather than repeat, or the chapter turns into a clip show.
2. **Whether act 4 names the second book.** The outline calls it "a second, more advanced book",
   which is a commitment of a kind. Author's call.
