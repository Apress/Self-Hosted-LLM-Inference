# Chapter 6: deferred absorptions

Ch 6 is drafted, so this is not a chapter scaffold. It is a holding file for material the iplane
inbox routed here that should **not** be written into `index.tex` yet.

**Why deferred, and why that reason expired the same day (2026-08-15).** These were held back
because Ch 6 was still in the superseded "you"-only register, and drafting new beats in the
current voice on top of old-voice prose makes the seam hard to find later. That was the right call
at the time and it stopped being true within the hour: `2fd5126` rewrote Ch 1 to Ch 9 in the
author's voice, taking Ch 6 from 0 authorial mentions to 82 and Ch 7 from 2 to 56.

**So the blocker is gone and these are drafting-ready.** What remains is a placement judgement
rather than a sequencing one, which is what the publisher asked for when it filed all three as
`placement: undecided`. Nothing here has been written into `index.tex` yet.

Ch 6's *stable architectural facts* live in `book/CLAUDE.md` under "Chapter 6 v0.1 stable facts",
not here. This file holds only pending absorptions.

---

## 1. The capability seam held; it could not save us from modelling the thing wrong

Marker `2026-08-11T07-13-23--modelling-a-provider-as-the-wrong-kind-of-thing`, iplane PR 252.
Publisher filed it `placement: undecided`; routed here because §\ref{subsec:provider-capabilities}
is where the chapter introduces `pattern:capability-discovery`, and the `Deployer` capability
already contrasts image-native providers against drive-Docker-over-SSH ones.

**Concept.** A provider was integrated on a wrong answer to a question nobody asked out loud:
what is the unit this vendor actually rents? It rents containers, taking an image and a startup
command. It had been integrated as though it rented machines, so the path rented a box, logged in,
installed a container runtime, and ran the workload inside it. Every step is sensible against a
machine and none of it is sensible against a container, and the last step is a container runtime
inside a container, which the platform will not grant the privileges for.

**Why it belongs beside the capability pattern, which is the payoff and the limit at once.**
Because adapters opt into behaviours and the control plane dispatches on what they satisfy, the
fix was a rewrite of one adapter rather than a change to the control plane. That is the seam
earning the ceremony it otherwise looks like. The less comfortable half is the one worth printing:
a capability interface says what an adapter *can* do and cannot say whether anything has ever
asked it to. An adapter that compiles, carries a full catalog, and exposes options can still never
have completed the operation you care about.

**The reader-facing question**, which is cheap to answer up front and expensive to discover:
before integrating anything, ask what unit it rents. A machine, a container, a function, a hosted
endpoint. The answer decides which capabilities are even meaningful.

**Optional and honest.** The wrong model never announced itself. It surfaced as a queue of five
ordinary-looking bugs (login wait too short, key never registered, readiness check never
implemented, the rent-a-machine path never called, container runtime uninstallable), each a
genuine defect with a correct fix. About half stopped applying the moment the provider was
re-integrated as a container platform, because they were repairs to a road that should not have
existed. The other half still matter for the vendor that genuinely does rent machines. Use this
only if the section can carry it without turning into a war-story digest.

**Cross-chapter note.** The same question drives Ch 11 Act 3 from the price side, since a hosted
API rents tokens rather than hours. Recorded in `chapter11/OUTLINE.md`; do not write it twice.

---

## 2. Confirm an instrument can fail before believing that it passed

Marker `2026-08-11T07-13-24--an-instrument-that-reports-success-without-measuring`, iplane PR 250.
Routed here because Ch 6 is where readiness polling is introduced (the SSH-readiness waiter and
`instance wait`); Ch 7 §\ref{subsec:per-replica-health} is the second, weaker hook.

**Concept.** A reachability probe took a host and a port, ignored both, and returned success. It
satisfied its type, sat on the correct path, and was called at the right moments. It reported
every address in the world as reachable, instantly. The damage was not a missing feature. Callers
treated a passing probe as evidence, so the wait-for-reachable step returned immediately against
machines that were not up, and the real failure surfaced minutes later somewhere else. That
produced three wrong diagnoses in sequence, each built out of fabricated readings.

**The measurement, once the probe was real** (poll from the moment of rent): the rent call returns
at ~2s, the endpoint is published at ~3s, and the port does not accept until ~273s. So the stub
was wrong for roughly four and a half minutes of every rental. There was never any gap between
"the port accepts" and "the session establishes", which means the middle theory about the
provider's proxy accepting and dropping connections was an artifact of measuring with a broken
instrument.

**The rule.** An instrument that cannot fail is not an instrument. Before believing what a check
says, confirm it is capable of saying no.

**Why it is more than a testing tip.** A stub passes type checking, appears in a call graph, and
satisfies any test written around the happy path. The only test that catches it is one requiring a
negative result: one case needs a live listener to succeed, the other needs a closed port to fail.

**Existing thread to join.** The book already runs this family twice. Ch 9 has a timestamp that
read like a container-start signal and was not, producing a clean and believable zero for a phase
never measured. Ch 10 has a field from the single-machine era read as authoritative after the
system learned to hold several, producing a clean and believable success for a teardown that
released nothing. This is the third and the most distilled, and its distinguishing feature is how
it was caught: the first two fell to arithmetic that did not add up and to a bill, and this one
only fell when somebody finally asked whether the instrument worked.

---

## 3. "I do not know" has to be a value the instrument can return

Marker `2026-08-11T18-30-00--i-do-not-know-has-to-be-a-value`, iplane PR 274. The publisher marks
it a follow-up to §2 above, and says the two are one section rather than two. Treat them that way:
§2 supplies the anecdote, §3 supplies the reason it deserves a section instead of a footnote.

**The distinction, which is the useful part.** These look like one bug and are two. The stub probe
**never measured**; its body was hollow, it fails in every case, and it survived only because
nobody read it closely. The second instance **did measure**, correctly, nearly always. A watchdog
existed to destroy rented machines on a deadline so a run that died between renting and releasing
would not bill forever, and its lister collapsed every error into "no instances". Unreachable API
and empty account produced identical output, so at the deadline the sweep concluded there was
nothing to destroy and exited satisfied while a machine billed for another 52 minutes. The trigger
was a laptop resuming from sleep, one failed read at exactly the wrong moment. Code review does
not catch that, because the code is not wrong so much as insufficiently expressive.

**Why it is systematic rather than bad luck.** The same error and the same fix turned up five
times in one codebase in unrelated components. Three collapsed "I do not know" into a confident
answer and were wrong: the reachability probe into success, the cost watchdog into "nothing is
running", and an A/B comparator into "the arms were configured differently". Two kept it distinct
and were right: the interconnect sensor carries an availability flag separating "no reading" from
"zero links up", and the fabric requirement resolves to unknown rather than none when a zero
reading cannot be trusted.

**The argument, and it is stronger than "pay attention".** The two that got it right did not get
lucky. The fabric requirement *inherited* the rule, which had been written down two days earlier
when the fabric catalog was built, so the later work adding "must not have a fast link" applied a
decision already recorded in the package it was editing rather than rediscovering it. The
interconnect sensor got there because the question was fresh, having been asked hours before. The
three failures are all places where no such rule was written down anywhere. A rule written down
once held on a component built two days later by someone re-deriving it from the earlier decision.
That is the case for naming it in print rather than leaving it to care.

**The general form.** Any value that can be absent needs three states rather than two, and the
third is the one that gets dropped: absent, present-and-zero, present-and-nonzero. Collapse the
first two and you either invent faults everywhere the sensor is missing or hide them everywhere it
is.

**Reader-facing check.** For every reading this system takes, what does it return when it cannot
take it, and is that distinguishable from a real answer?

**Framing caution.** The marker offers "the implementation learned this first, on a different
component, and the chapter articulated it later" as an honest framing. Half of that is usable and
half is not. The *system's* history (the rule was written down for the fabric catalog first, and
components built after it inherited it while components built without it repeated the mistake) is
exactly the kind of history the voice wants. The *manuscript's* history (which chapter articulated
what, and when) is the draft-history meta-prose the style skill bans. Keep the first, drop the
second.

**Already spent downstream, do not double-spend.** Two pieces of this have landed elsewhere and
should not be re-taught here. Ch 11 §11.2.2 carries `pattern:silence-is-not-evidence` and, since
the 2026-08-15 drain, `pattern:bounds-it-or-ordered-with-it`, which is the follow-on move about
what absence *licenses* once you have the third state. The asymmetric-cost argument (wrongly
reporting "clean" bills indefinitely while wrongly reporting "something is running" costs one
unnecessary look, so where costs are lopsided the default belongs on the cheap side) is also
already in Ch 11 §11.2.2 and is queued for Ch 11 Act 5. If Ch 6 wants it, it needs the watchdog's
version of the asymmetry, not a second telling of the resolver's.
